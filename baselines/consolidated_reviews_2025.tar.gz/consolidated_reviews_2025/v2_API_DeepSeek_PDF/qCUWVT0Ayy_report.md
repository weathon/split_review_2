## Summary
This paper presents LayoutNUWA, a method that reformulates graphic layout generation as a code generation task. The core idea is to encode layout elements (category, position, size) as masked HTML code snippets using `<rect>` tags with named attributes, then fine-tune a large language model (LLaMA2-7B or CodeLLaMA-7B) to complete the masked positions. The approach, called Code Instruct Tuning (CIT), consists of three modules: Code Initialization (quantization + HTML template construction with masks), Code Completion (LLM fine-tuning on the masked code), and Code Rendering (direct SVG visualization of completed HTML). The method supports multiple conditional generation tasks (category→size+position, category+size→position, and completion) and can be trained in domain-specific or domain-agnostic settings.

The paper reports strong results on three datasets: Rico (mobile UI, 66K+ layouts), PubLayNet (documents, 360K+ layouts), and Magazine (low-resource, ~4K layouts). On the Magazine dataset, LayoutNUWA achieves FID improvements of 50%+ over the best baseline (LayoutDM). On Rico and PubLayNet, the method achieves leading or near-leading results across most tasks. Ablation studies confirm the importance of the code template structure and instruction tuning.

**Core strengths:** The code-as-representation idea is conceptually interesting — it makes layout element attributes explicit through named HTML fields, directly visualizes outputs, and aligns with LLM pre-training distributions. The multi-task training with element-order permutation is a reasonable solution to the ordering issue in autoregressive layout generation. The domain-agnostic training demonstrates that a single LLM can handle multiple layout domains with appropriate prompting.

**Core weaknesses:** (1) Performance gains are confounded with backbone scaling (7B LLM vs. small diffusion models) and not adequately decomposed. (2) The "first model" and "state-of-the-art" claims are unverifiable without external literature search and should be bounded. (3) The joint loss formulation has notational ambiguities that hinder reproducibility. (4) The qualitative evaluation is underdeveloped despite extensive figures. (5) The practical computational cost (64 V100 GPUs) is not discussed as a limitation. (6) Domain confusion analysis reveals that textual domain prompts are often overridden by template priors, a significant limitation that is relegated to the appendix.

**Novelty assessment (deferred):** Due to Retrieval-Disabled Mode, external literature verification was not performed. Novelty conclusions for the three contribution claims are deferred for manual verification. The core conceptual novelty — reformulating layout generation as code generation — appears plausible as a framing contribution, but the extent of overlap with prior structured-representation approaches (e.g., BLT's bidirectional transformer, LayoutGPT's LLM prompting) cannot be assessed without retrieval.

## Strengths
**1. Novel conceptual framing.** The reformulation of layout generation as a code generation task is a fresh perspective on a problem traditionally treated as numerical optimization. Converting layout tuples to structured HTML with named attributes (`data-category`, `x`, `y`, `width`, `height`) makes the semantic role of each numerical value explicit, which is a genuine representational improvement over position-dependent raw tuples.

**2. Clean end-to-end pipeline.** The CI→CC→CR pipeline is well-structured and directly interpretable: numerical conditions → masked HTML → LLM completion → rendered layout. The use of SVG-capable HTML as the output format means that generated layouts can be visualized without any post-processing, which is a practical advantage for prototyping and debugging.

**3. Multi-task and domain-agnostic training.** The joint training across three conditional tasks (C→S+P, C+S→P, Completion) within a single model is a practical contribution. The element-order permutation strategy thoughtfully addresses the ordering ambiguity problem in autoregressive layout generation. The fact that a single fine-tuned LLM can handle multiple layout domains (mobile UI, documents, magazines) with different canvas sizes and element categories is a nontrivial demonstration of generalization.

**4. Strong empirical results on low-resource setting.** The most compelling empirical finding is on the Magazine dataset, where LayoutNUWA achieves FID of 8.79 (C→S+P) vs. LayoutDM's 19.21 — a substantial improvement. This suggests that the LLM's pre-trained knowledge is particularly valuable when training data is limited (~4K layouts), which is a realistic practical scenario.

**5. Informative ablation study.** The ablation in Tables 3 and 4 systematically decomposes the CIT components: template vs. instruction-only vs. numerical-only tuning. The head-to-head comparison of code format vs. numerical format using the same 7B backbone (Table 4) is the most informative experiment in the paper, as it isolates the effect of code representation from the effect of model scale.

**6. Honest limitations section.** The appendix includes a dedicated limitations section that acknowledges known AR weaknesses (slow generation, error propagation) and domain confusion, which is more transparent than most papers in this area.

## Weaknesses
**1. Confounded performance attribution (Major).** The paper attributes the 50%+ FID improvement to the code representation, but the gains are confounded with model scale (7B LLM vs. small diffusion backbones), the autoregressive formulation, and the HTML template structure. A controlled decomposition (Table 4) partially addresses this by comparing numerical vs. code format on the same 7B backbone, showing ~46% improvement from the code format. However, the main text narrative in Section 4.2 conflates three factors without quantitative decomposition. The paper never compares against equivalently scaled autoregressive baselines trained on numerical coordinates, making it impossible to isolate the contribution of the code format alone.

**2. Unverifiable priority claims (Major).** The abstract and contribution list claim "the first model that treats layout generation as a code generation task." This is a strong priority claim that requires exhaustive literature verification. Given that prior work (LayoutGPT, Feng et al. 2023; BLT, Kong et al. 2022) uses structured representations and LLM prompting for layout-related tasks, the "first" claim needs explicit qualification or removal. In Retrieval-Disabled Mode, this claim cannot be verified and should be downgraded to "we propose a code-generation formulation..." without priority assertion.

**3. Ambiguous joint loss formulation (Major).** Equation (3) has notational issues: the loss function L(·) is overloaded (total loss and per-element loss share the same symbol), the element-level summation structure is unclear, and the loss type (cross-entropy, MSE, etc.) is unspecified. This hinders independent implementation.

**4. Underdeveloped qualitative evaluation (Major).** The qualitative evaluation consists of 5 sentences for 18 figures across 3 datasets. There is no systematic analysis of failure modes, no selection criteria for displayed examples, and no structured comparison of what types of errors each method makes. The figures carry the entire argument without textual guidance.

**5. Undisclosed computational cost (Moderate).** Training uses 64 NVIDIA V100 GPUs, a resource requirement 1-2 orders of magnitude larger than all baselines (which typically use 1-4 GPUs). This cost is not reported in the limitations section or discussed in terms of cost-performance trade-off. A practitioner cannot assess whether the method's gains justify its cost.

**6. Domain confusion undermines DA claims (Moderate).** The mixed-domain experiments (Appendix F) reveal that domain prompts can be overridden by template priors, causing severe performance degradation. This is a significant practical limitation that is relegated to the appendix and not discussed in the main paper's narrative about the advantages of domain-agnostic training.

**7. Conclusion overclaims (Moderate).** The conclusion uses "groundbreaking," "superiority," and "potential to revolutionize" without summarizing specific validated findings or bounded claims. No limitations are mentioned in the main conclusion (deferred to appendix).

## Key Issues
**Issue 1 (Critical - Confounded Performance Attribution).** The central narrative claim — that treating layout generation as code generation yields 50%+ improvements — is not adequately supported because the gains are confounded with model scale. The main comparison (Table 1) pits 7B LLMs against diffusion models with far fewer parameters. The ablation in Table 4 shows that the 7B backbone alone (with numerical tuning) achieves FID 17.98 vs. LayoutDM's 19.21, meaning ~40% of the total improvement comes from the larger model, not the code format. The paper should either (a) control for model capacity by comparing against a similarly-sized autoregressive baseline with numerical coordinates, or (b) train a smaller version of LayoutNUWA for fair comparison.

**Issue 2 (Major - Unsubstantiated Priority Claim).** The abstract, introduction, and contribution list assert that LayoutNUWA is "the first model that treats layout generation as a code generation task." Without external literature verification (which is unavailable in this run), this claim is unsubstantiated. The paper should remove "first model" language and instead state the contribution as "we propose a code-generation formulation."

**Issue 3 (Major - Notation Gaps in Joint Loss).** Equation (3) is insufficiently specified for independent reproduction. The loss function type is not stated (cross-entropy? MSE?), the element-level decomposition is ambiguous (are per-element losses computed independently or over the full token sequence?), and the mask-application mechanism across permutations is unclear. This must be clarified in a revision.

**Issue 4 (Major - Qualitative Evaluation Underspecified).** 18 figures across 3 datasets are presented with only 5 sentences of analysis. The paper should provide structured qualitative analysis: selection criteria for displayed samples, systematic error-type comparison across methods, and at least one case study per dataset showing where each method succeeds and fails.

**Issue 5 (Major - Domain Confusion Underexplored).** The mixed-domain experiment (Appendix F) reveals that domain prompts have limited controlling power when template priors conflict. This is directly relevant to the paper's claim that domain-agnostic training is beneficial, yet it is only briefly discussed in the appendix. A concise version should appear in the main paper.

**Issue 6 (Moderate - Conclusion Overclaim).** The conclusion introduces unsupported claims ("revolutionize the field") and omits limitations entirely. Should be rewritten to summarize specific validated findings and explicit limitations.

## Actionable Suggestions
**S1. Decompose performance attribution (Must, addresses Issue 1).** Add a controlled experiment comparing LayoutNUWA against an autoregressive baseline of matched capacity (e.g., a 7B GPT-like model) trained on raw numerical coordinates. This can be approximated by the "LayoutNUWA-N" variant from Table 4, but that experiment should be moved into the main quantitative comparison table and discussed in Section 4.2. Specifically, add a row for "LayoutNUWA-N (7B, numerical)" in Tables 1 and 2 and discuss what fraction of the improvement is attributable to model scale vs. code format.

**S2. Remove unsupported priority claims (Must, addresses Issue 2).** Replace all instances of "first model" with bounded language throughout the paper. The abstract should say "we propose a model that treats layout generation as a code generation task" without priority assertion. The contribution list should similarly avoid "first" language.

**S3. Clarify joint loss notation (Must, addresses Issue 3).** In Section 3.2.2, revise Equation (3) as follows:
- Specify the loss type explicitly (cross-entropy over masked token positions).
- Clarify whether the sum over j indexes elements or token positions.
- Add an explicit note about how masks are applied across different permutations (same mask pattern per task across all K permutations? different mask patterns?).
- Provide a worked example in the appendix showing the mask→template→computation flow for one layout.

**S4. Expand qualitative evaluation (Must, addresses Issue 4).** Add a dedicated paragraph for each figure/table group with:
- Selection criteria for displayed examples (e.g., "median-FID sample," "random sample from top/bottom quartile").
- At least 2-3 specific observations per figure about what differentiates methods.
- A failure case analysis section showing representative failures for LayoutNUWA and baselines.

**S5. Move domain confusion analysis to main paper (Nice-to-have, addresses Issue 5).** Add a paragraph in Section 4.2 (or a new Section 4.4) summarizing the mixed-domain experiment. Highlight that domain-agnostic training is not a free lunch — it requires effective domain conditioning.

**S6. Revise conclusion (Must, addresses Issue 6).** Replace the current 3-sentence conclusion with a three-paragraph structure: validated findings with specific numbers, bounded limitations, and concrete future work. Remove "revolutionize" and "groundbreaking" language.

**S7. Add computational cost disclosure (Nice-to-have).** Add a bullet to the limitations section (Appendix A) specifying: training hardware (64 V100 GPUs), estimated training time, inference throughput (layouts/second), and a comparison with baseline resource requirements. If feasible, report a smaller variant trained on 4-8 GPUs.

**S8. Improve Related Work section structure (Nice-to-have).** Reorganize Section 2.1 from chronological list to comparison axes: representation format, backbone capacity, conditioning approach, and training efficiency. For each axis, explicitly position LayoutNUWA relative to prior work. See the Mentor Revised Version in the annotation on Page 3 for a concrete rewrite.

**S9. Report Fail rate in main tables (Must).** Add the Fail rate column to Tables 1 and 2 alongside FID and mIoU so readers can jointly assess quality and reliability, as is done in Table 3.

## Storyline Options + Writing Outlines
### Current Storyline Analysis

The current introduction follows this paragraph structure:
- P1: Background + current methods use numerical tuples → limitation (lack of semantic info).
- P2: Research question → why code language is suitable.
- P3: LayoutNUWA + CIT method description.
- P4: Experimental summary + contribution list.

**Alignment checks:**
- Problem alignment: The stated challenge (semantic gap in numerical tuples) matches the solution (code with labeled attributes). ✓
- Variable alignment: "Code language" (P2) → "HTML template with masks" (P3/4) → visible in experiments. ✓ But "semantic information" as presented in P1 is vague — what concrete form does it take?
- Contribution-evidence alignment: C1 (first code generation model) — not independently verifiable. C2 (CIT) — supported by ablation. C3 (SOTA) — partially supported but confounded.

### Recommended Storyline (Revised)

**Abstract Outline (5 sentence structure):**
- S1 (Problem): Graphic layout generation is essential for UI/document/magazine design, but existing methods represent layouts as unlabeled numerical tuples (c, x, y, w, h) that lack explicit semantic structure.
- S2 (Gap): This position-dependent representation hides attribute semantics and prevents leveraging pre-trained models that understand structured code.
- S3 (Solution): We propose LayoutNUWA, which re-frames conditional layout generation as masked HTML completion, encoding element attributes as labeled HTML `<rect>` tags and fine-tuning an LLM to fill missing values.
- S4 (Method): Our Code Instruct Tuning approach uses a template-based initialization, multi-task joint loss with element permutation, and direct SVG rendering from completed code.
- S5 (Result): On the low-resource Magazine dataset, LayoutNUWA improves FID from 19.2 to 8.8 (54% relative); on Rico and PubLayNet it achieves leading or competitive results across three conditional tasks, and the code format itself accounts for ~46% of the gain over an identically-sized numerical baseline.

**Introduction Outline (4 paragraphs):**
- P1 (Territory + Gap): Layout generation is important for many applications. Current methods use (c, x, y, w, h) tuples → numerical optimization. Problem: attributes are implicit (position-dependent), no semantic labels, LLM pre-training cannot be directly applied.
- P2 (Proposed approach): We propose encoding layouts as structured HTML code where each element has labeled attributes. This enables: (a) explicit semantic role for each value, (b) direct rendering, (c) LLM fine-tuning with HTML code priors. Our CIT approach has three modules: CI, CC, CR.
- P3 (Evidence preview): On Magazine (low-resource), FID improves 54% over best baseline. On Rico/PubLayNet, competitive results across all tasks. Ablation shows code format provides ~46% improvement over same-sized numerical model.
- P4 (Contributions): (1) Code-generation formulation for layout generation. (2) CIT method with template masking, multi-task joint loss, and element permutation. (3) Empirical results showing effectiveness across domains, with ablation analysis disentangling code format from model-scale effects.

**Key changes from current:**
- Remove "first model," "groundbreaking," "revolutionizes" language.
- Present contributions as specific methodological components, not as SOTA claims.
- Include the decomposition result (code format vs. model scale) directly in the story.
- Make the gap concrete: specify what "lacking semantic information" means in operational terms.

## Priority Revision Plan
### Ranked Error Board

| Rank | Issue | Severity | Validity Risk | Fixability | Confidence |
|------|-------|----------|---------------|------------|------------|
| 1 | Confounded performance attribution (Issue 1) | Critical | High - Core claim may be overstated | Fixable - Add controlled numerical baseline to main tables | High |
| 2 | Unsubstantiated priority claim (Issue 2) | Major | Medium - Invites reviewer pushback | Fixable - Remove "first" language | High |
| 3 | Joint loss notation ambiguity (Issue 3) | Major | Medium - Harms reproducibility | Fixable - Clarify notation + add appendix example | High |
| 4 | Qualitative evaluation underspecified (Issue 4) | Major | Low - Doesn't affect numeric claims | Fixable - Add structured analysis text | High |
| 5 | Domain confusion underexplored in main paper (Issue 5) | Major | Medium - Undermines DA claim | Fixable - Move analysis to main paper | High |
| 6 | Conclusion overclaim (Issue 6) | Moderate | Low | Fixable - Rewrite | High |

### Revision Order (P0 → P1 → P2)

**P0 (Must, pre-submission critical):**
1. Remove all "first model" and "first time" language from abstract, intro, and contributions.
2. Add the LayoutNUWA-N (numerical 7B) row to Tables 1 and 2, and rewrite the "three aspects" discussion in Section 4.2 to explicitly disentangle code-format gains from model-scale gains.
3. Clarify Equation (3) notation: specify loss type, element vs. token indexing, mask consistency across permutations.
4. Add Fail rate column to Tables 1 and 2.

**P1 (Must, high impact):**
5. Rewrite conclusion (Section 6) with three paragraphs: validated findings, bounded limitations, future work.
6. Add one paragraph from Appendix F (mixed-domain experiment) to main paper (Section 4.2 or new Section 4.4).
7. Expand qualitative evaluation text (Section 4.3) with structured analysis and selection criteria.
8. Rewrite the abstract to remove hype and bound claims to tested settings.

**P2 (Nice-to-have, quality improvement):**
9. Add computational cost disclosure to limitations.
10. Restructure Related Work (§2.1) as comparison axes rather than chronological list.
11. Add an experiment quantifying information loss claim in Code Rendering (§3.2.3).
12. Consider training a smaller LayoutNUWA variant (e.g., 1.5B parameters) on 4-8 GPUs for broader accessibility.

### Expected Impact After Fixes
Completing P0 items addresses the two most critical validity concerns (confounded attribution and priority overclaim). Completing P1 items makes the narrative defensible and the experimental analysis complete. After all P0+P1 fixes, the paper's core contribution — reformulating layout generation as code generation — becomes verifiable and properly bounded, and the revision targets a score of [6, 7]/10.

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|--------|---------------------|-------|---------|-------------|-----------------|-------------------|
| E1: Magazine comparison (Tab. 1) | Test LayoutNUWA vs. 6 baselines on low-resource dataset | Magazine, 3 tasks, DS and DA settings | FID, mIoU | LayoutNUWA-CL-DA best FID across tasks, 50%+ over LayoutDM | C1/C2/C3 partially | Confounded with 7B scale; no matched-capacity baseline |
| E2: Rico comparison (Tab. 2) | Test on mobile UI dataset | Rico, 3 tasks | FID, mIoU, Align., Overlap | Best mIoU in 2/3 tasks; Align./Overlap closer to Real Data | C3 partially | Not best in all tasks; Align./Overlap not statistically tested |
| E3: PubLayNet comparison (Tab. 2) | Test on document layout dataset | PubLayNet, 3 tasks | FID, mIoU, Align., Overlap | Best or second-best across tasks | C3 partially | Same confound as E1 |
| E4: CIT ablation (Tab. 3) | Decompose CIT components (template, instruction, numerical tuning) | Magazine, L2-DS backbone, DS and DA | FID, mIoU, Fail | CIT > w/o template > numerical; DA fails without template | C2 well supported | Only tested on Magazine; only with L2-DS |
| E5: Output format comparison (Tab. 4) | Compare code vs. numerical output format with same 7B backbone | Magazine, all tasks | FID, mIoU, Fail | Code format dramatically better; numerical has >21% fail rate | C2 well supported | Numerical variant (LayoutNUWA-N) uses Code Infilling, not full-code autoregressive |
| E6: Unconditional generation (Tab. 7) | Test unconditional layout generation | All 3 datasets, CL-DS and CL-DA | Align., FID | CL-DS best FID on all datasets; DA slightly worse | C1/C2 partially | DA performance degradation unexplained |
| E7: GPT-4 comparison (Tab. 5, 6) | Test CIT approach with GPT-4 zero-shot | Magazine | Fail rate, mIoU | GPT-4 28-34% fail rate; LayoutNUWA ~0% | CIT necessity supported | No FID for GPT-4 (distribution mismatch) |
| E8: Mixed-domain test (Tab. 8) | Test domain confusion | Magazine→RICO, RICO→Magazine | Align., FID | Severe degradation with mismatched domain prompt | Domain confusion identified | Relegated to appendix; no mitigation proposed |
| E9: Human evaluation (Fig. 5) | Perceptual quality & diversity comparison | Rico, PubLayNet, 25 samples each | Preference voting | LayoutNUWA > LayoutDM > LayoutTrans in both quality and diversity | C1/C2/C3 partially | Only 25 samples; only 2 baselines; small annotator pool (10) |

### Research-Theme Gap Diagnosis

Three research-value claims are weakly supported:

1. **New knowledge:** The paper's core claim — that code representation improves layout generation — is partially supported but confounded with model scale. Without a matched-capacity control, the fundamental scientific question ("does code format help beyond larger models?") is not cleanly answered.

2. **Reproducibility:** The joint loss notation (Eq. 3) is ambiguous enough to prevent exact reproduction. Training on 64 V100 GPUs is prohibitive for most labs. The paper acknowledges open-sourcing code but provides no details about data preprocessing (especially the Adaptive Quantization k-Means clustering parameters).

3. **Impact on practice:** The high computational cost and domain confusion issues limit practical applicability. The paper does not discuss inference cost, which is critical for real-time layout generation applications (UI design, document layout).

### Proposed Research Experiments (P0/P1/P2)

| Exp ID | Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost/Time | Expected Quality Gain |
|--------|-------------|------------|---------------|-------------------|---------|------------------|---------------|---------------------|
| P0-E1 | Deconfound scale vs. code format | Code format provides >20% FID improvement over same-scale numerical model | Add LayoutNUWA-N row to Tab. 1 & 2 (already have data in Tab. 4) | Same 7B backbone, same training budget | FID, mIoU, Fail | FID(code) < FID(numerical) across all tasks | 0 (data exists) | Critical - resolves Issue 1 |
| P0-E2 | Ablation: what does HTML structure add vs. flat labeled sequence? | HTML structure provides additional benefit beyond attribute naming | Compare HTML template vs. flat key=value sequence with same attribute names | Flat format: "c=title x=10 y=20 w=70 h=20" formatted as plain text | FID, mIoU | HTML cod > flat labeled text > raw numerical | 1-2 GPU-days | High - isolates template structure effect |
| P1-E3 | Test code format in small model | Code format benefit is not scale-dependent | Fine-tune 1.5B model (e.g., TinyLLaMA) with and without code format | Same 1.5B backbone, numerical vs. code, same data & epochs | FID, mIoU, Fail | Code format improves FID at small scale | 8-16 GPU-days | High - shows generality |
| P1-E4 | Inference speed benchmark | Quantify AR speed disadvantage | Measure layouts/second for all methods at same batch size | LayoutNUWA, LayoutDM, LayoutTrans, BLT | Throughput (layouts/s), peak memory | Report absolute numbers; analyze trade-off | 1 GPU-day | High - addresses practical limitation |
| P2-E5 | Domain disentanglement | Adapter modules improve domain control | Add learned domain embedding to LLM input; compare with text-only prompt | Text-only vs. text+embedding vs. domain adapter | FID, Align. | Domain adapter reduces FID drop in mixed-domain setting | 8-16 GPU-days | Medium - mitigates domain confusion |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score: 6/10**

*Rationale:* The paper presents a conceptually interesting reformulation of layout generation as code generation, supported by strong empirical results on the Magazine dataset and informative ablations. However, the core empirical claim is weakened by confounded performance attribution (7B LLM vs. small diffusion baselines are not controlled), and the paper relies on unverifiable priority claims ("first model"). The notation for the joint loss is ambiguous, qualitative evaluation is superficial, and computational cost is not discussed. Novelty assessment is deferred due to Retrieval-Disabled Mode, and the contribution-level novelty verdicts are marked as `unclear`.

**Research value** (primary dimension, ~60% weight): 6/10. The code-generation framing is novel within the layout generation literature, but the confounded experiments prevent clean attribution of the claimed improvements to the core idea versus model scaling.

**Validity/Soundness** (~25% weight): 5/10. The ablation studies are well-designed (Tables 3, 4), but the main quantitative comparison (Tables 1, 2) lacks matched-capacity controls, and the qualitative analysis is underdeveloped.

**Reproducibility** (~15% weight): 5/10. The method is described at a reasonable level, but Equation (3) has notational gaps, dataset preprocessing details (especially k-Means quantization parameters) are incomplete, and the 64-GPU requirement limits independent verification.

---

**Post-Revision Target: [6, 7]/10**

If all P0 and P1 revisions are completed (deconfounded comparison, clarified notation, removed priority claims, expanded qualitative analysis, domain confusion discussion in main paper, revised conclusion, Fail rate reporting), the paper would be a solid 7/10. Reaching 8/10 would require additional experiments demonstrating that the code format benefit persists at matched model scales and that the method is practical with reasonable computational cost.