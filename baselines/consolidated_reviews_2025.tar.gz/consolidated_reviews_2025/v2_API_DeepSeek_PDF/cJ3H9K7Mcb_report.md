## Summary
This paper investigates a largely overlooked dimension of OOD generalization evaluation: the **degree** of distribution shift (as opposed to the **type** of shift). The authors construct synthetic datasets (NoisyMNIST, RotatedMNIST, LowLightCIFAR10, NoisyImageNet15, LR-ImageNet15) where each dataset contains multiple domains with monotonically increasing shift severity. Through extensive experiments with over 20 domain generalization algorithms and multiple architectures (CNN, ResNet-50, EfficientNet-b0, ViT-B/32), they demonstrate three key findings:

1. **Brittle extrapolation (mild→strong)**: A model's relative advantage under mild shifts does not transfer to even slightly stronger shifts of the same type. Performance drops of >50% (relative) from D4 to D5 are observed.

2. **Asymmetric reverse (strong→mild)**: Training on strongly shifted data *sometimes* guarantees robustness to milder shifts (NoisyMNIST) but *sometimes* harms it (RotatedMNIST) — the outcome is task-dependent.

3. **Pre-trained model brittleness**: CLIP models, despite strong in-distribution performance, can be more sensitive than randomly initialized models to downstream distribution shifts that were rare during pre-training.

The paper's core contribution is methodological: it proposes evaluating OOD generalization across a continuous range of shift degrees rather than at a single fixed degree, and provides empirical evidence that this practice can change conclusions about model and algorithm robustness. The work is timely and relevant for the OOD generalization community, but several important limitations — including reliance on synthetic shifts, unsupported mechanistic explanations, and ambiguous quantitative claims — reduce its current readiness for publication.

## Strengths
**S1 — Timely and well-motivated research question.** The paper identifies a genuine blind spot in OOD generalization evaluation: the nearly exclusive focus on varying shift *types* while keeping shift *degree* fixed. This is a practically important issue because real-world deployment often encounters varying severity levels of the same type of distribution shift. The motivating Figure 1 clearly illustrates why fixed-degree evaluations can conflate qualitatively different robustness patterns.

**S2 — Extensive empirical scope.** The paper evaluates over 20 DG algorithms across multiple architectures (4-layer CNN, ResNet-50, EfficientNet-b0, ViT-B/32) on 5 synthetic datasets spanning three shift types (noise, rotation, brightness+shot noise, and resolution degradation). This breadth provides reasonable evidence that the brittleness phenomenon is not an artifact of a single algorithm or architecture.

**S3 — Inclusion of pre-trained foundation models.** The investigation of CLIP models alongside randomly initialized and ImageNet pre-trained models is a strength. The finding that CLIP can be *more* brittle than scratch models on certain downstream shifts is non-obvious and practically relevant given the widespread deployment of foundation models.

**S4 — Nuanced second-order finding.** The asymmetry between noise shifts (where strong-shift training helps all milder shifts) and rotation shifts (where it does not) is a nuanced result that goes beyond a simple "brittleness everywhere" narrative. This dataset-dependence is correctly identified as an important open question.

**S5 — Reproducibility-oriented implementation.** The use of DomainBed codebase and explicit reporting of hyperparameter search budgets (20 random searches per algorithm) supports reproducibility. The extensive tables in the appendix (Tables 2-19) provide full numerical results.

## Weaknesses
**W1 — Over-reliance on synthetic distribution shifts.** All experiments use synthetically generated shifts (Gaussian noise, rotation, brightness+shot noise, downsampling). While these provide controlled conditions, they do not represent the complexity of natural distribution shifts (e.g., WILDS datasets). The paper's claim that conclusions "also hold for more general problems" (Page 4) is unsupported and should be replaced with a bounded statement. Natural shifts often involve correlated multi-factor changes that cannot be captured by a single monotonic ordering assumption.

**W2 — Ambiguous quantitative claims.** The paper states that the accuracy gap between CLIP0 and RI0 "increased by more than 40% from D0 to D1" (Page 8). This phrasing is ambiguous — it is unclear whether "40%" refers to an absolute gap increase (e.g., from 1% to 41%) or a relative increase (e.g., from 20% gap widening by 40% to 28%). These have very different implications. The underlying absolute accuracy values for CLIP0 and RI0 at D0 and D1 are not reported in the main text.

**W3 — Unsupportive mechanistic explanation.** The "spurious correlation breaking point" explanation (Page 7) is presented as the paper's main mechanistic hypothesis, but it rests on GradCAM visualizations of only two models (ERM and CAD) on a handful of examples. No quantitative metric of feature importance stability is provided. The claim that "where this breaking point is and how rapidly the correlation breaks seem to be totally dependent on the nature of the distribution shift" is a truism — it describes rather than explains the observed pattern.

**W4 — Missing hypothesis for dataset-dependent asymmetry.** The paper correctly identifies that NoisyMNIST and RotatedMNIST exhibit opposite behavior for strong→mild generalization (Section 4.3), but offers no hypothesis for why. This is a significant gap because understanding the underlying cause would be the paper's most valuable contribution — it would tell practitioners which shifts are safe to train on at high severity and which require data at each target degree.

**W5 — Limited CLIP adaptation protocol.** The CLIP experiments use only linear probing for downstream adaptation (Page 8). This is a reasonable starting point but does not reflect how CLIP is typically deployed (full fine-tuning or prompt tuning). The paper's strong conclusion about CLIP's brittleness should be qualified as applying to linear probing specifically. The results may change substantially with full fine-tuning or other adaptation methods.

**W6 — Conclusion lacks limitations section.** The one-paragraph conclusion (Page 9) summarizes findings but does not acknowledge key limitations: synthetic shifts only, image classification only, linear probing for CLIP, and the absence of a predictive framework for which shift types exhibit which asymmetry pattern. This undermines the paper's scientific completeness.

**W7 — Method degree ordering assumption unvalidated.** Section 3 defines degree ordering as arbitrary as long as monotonic ordering is preserved, but offers no validation that the composite LowLightCIFAR10 shift (combining brightness and shot noise) actually preserves monotonic ordering. The interaction of multiple corruption types could produce non-monotonic effects that invalidate the framework.

## Key Issues
**Issue 1 (Major): Ambiguous quantitative claim about CLIP brittleness (Page 8)**
- **Anchor:** "the gap of accuracy between CLIP 0 and RI 0 increased by more than 40% from D0 to D1"
- **Verification:** The phrase "increased by more than 40%" is ambiguous. If the gap at D0 is X% and at D1 is Y%, does "more than 40%" mean Y - X > 40 (absolute percentage point) or (Y-X)/X > 0.4 (relative)? The underlying D0 and D1 accuracy values are not reported in-text. Figure 6 omits error bars and does not label exact values.
- **Impact:** This is one of the paper's headline claims. Lack of clarity on the magnitude undermines trust in the quantitative conclusions. Readers cannot verify the claim without going to the raw data.

**Issue 2 (Major): Unsupportive "breaking point" mechanism (Page 7)**
- **Anchor:** "the brittleness manifests when the spurious correlation between the local features and the target labels reaches a breaking point"
- **Verification:** The mechanistic claim is supported only by GradCAM visualizations of 2 models (ERM, CAD) on a few random examples. No quantitative feature importance metric, no statistical test of the "breaking point" hypothesis, no ablation that controls for local vs. global features.
- **Impact:** The paper's core explanatory framework is not empirically validated. This weakens the paper from an empirical characterization to a collection of observations without demonstrated cause.

**Issue 3 (Major): Missing hypothesis for dataset-dependent asymmetry (Section 4.3)**
- **Anchor:** NoisyMNIST shows strong→mild generalization success while RotatedMNIST shows failure (Page 7).
- **Verification:** The paper presents this as a finding but offers no hypothesis for why noise and rotation differ. Without a hypothesis, the paper cannot guide practitioners on which shifts exhibit which behavior.
- **Impact:** The paper's most practically useful finding — understanding when strong-shift training suffices — remains unexplained, substantially reducing actionable value.

**Issue 4 (Major): Overclaim of generalizability (Page 4)**
- **Anchor:** "we believe that the conclusions drawn from our experiment results also hold for more general problems"
- **Verification:** All experiments use synthetic shifts on image classification. No evidence from natural shifts, other tasks, or other modalities.
- **Impact:** This overclaim weakens scientific credibility. A bounded statement acknowledging the limitation would be more defensible.

**Issue 5 (Minor): Title does not reflect paper's contribution scope**
- **Anchor:** "ROBUSTNESS MAY BE MORE BRITTLE THAN WE THINK UNDER DIFFERENT DEGREES OF DISTRIBUTION SHIFTS"
- **Verification:** The title describes an observation (brittleness) but does not convey the paper's methodological contribution (evaluation across multiple shift degrees).
- **Impact:** The title may mislead readers about the paper's primary contribution being an empirical finding rather than an evaluation methodology proposal.

## Actionable Suggestions
**A1 — Resolve ambiguous CLIP quantitative claim (Must).** Replace "the gap of accuracy between CLIP0 and RI0 increased by more than 40% from D0 to D1" with explicit absolute values. For example: "The accuracy gap between CLIP0 and RI0 grew from X% at D0 to Y% at D1 (or from X% to Y%, a Z percentage-point increase)." Report the underlying numbers in the main text or a companion table, not only in Appendix B.5.

**A2 — Bound the "breaking point" mechanism claim (Must).** Replace "the brittleness manifests when the spurious correlation... reaches a breaking point" with correlational language: "The observed brittleness is consistent with models relying on features that become unreliable at higher shift degrees. A quantitative investigation of this mechanism is left to future work." Add one supplementary quantitative analysis: compute the change in model decision boundary (e.g., distance to nearest class centroid) across degrees as a proxy for feature instability.

**A3 — Add hypothesis for dataset-dependent asymmetry (Must).** In Section 4.3, add a paragraph offering a concrete hypothesis. For example: "We conjecture that the key difference is whether the shift destroys features (noise) versus transforms them (rotation). Gaussian noise gradually destroys local edge and texture information, forcing high-noise-trained models to rely on global shape — which remains useful at lower noise levels. Rotation, by contrast, transforms features spatially; a model trained on heavily rotated digits may learn rotation-invariant shape representations that are less discriminative for upright digits."

**A4 — Remove or rephrase the overclaim about generalizability (Must).** Replace "we believe that the conclusions drawn from our experiment results also hold for more general problems" with: "While our experiments focus on image classification with synthetic distribution shifts, the evaluation protocol — varying shift degrees continuously — is generally applicable. Whether the specific brittleness patterns extend to natural shifts and other modalities requires future investigation."

**A5 — Add a limitations paragraph to the Conclusion (Must).** Insert between the findings summary and the closing encouragement: "Limitations. Our study relies on synthetic distribution shifts applied to image classification datasets. The degree ordering assumption for composite shifts (e.g., LowLightCIFAR10) was not independently validated. CLIP experiments used linear probing only, which may not reflect full fine-tuning behavior. Future work should extend this evaluation protocol to natural distribution shifts, other modalities, and richer adaptation methods."

**A6 — Validate monotonic ordering for composite shifts (Nice-to-have).** In Section 3, add: "For composite shifts, we verify that a reference ERM model's accuracy decreases monotonically with the assigned degree label. Any dataset violating monotonicity is excluded or reordered. In our experiments, all datasets passed this check."

**A7 — Report per-seed statistics for top-k model selection (Nice-to-have).** Clarify in Section 4.1: "The top-3 models per algorithm are selected based on worst-domain validation accuracy across training domains. The 20 random hyperparameter configurations are independently sampled for each algorithm from the DomainBed search space."

## Storyline Options + Writing Outlines
### Current Storyline Assessment

The current narrative follows: Big Picture (OOD is important) → Existing approach (many benchmarks) → Overlooked dimension (shift degree) → Observations (brittleness, asymmetry, CLIP sensitivity) → Conclusion. This is a reasonable structure for an empirical paper, but it has two weaknesses: (1) the "gap" is established in Paragraph 2 but the paper's own methodological contribution (the evaluation protocol) is never explicitly named as a contribution; (2) the introduction reads as a list of findings rather than as a narrative building toward a specific question.

### Best Storyline Candidate (Recommended)

**Revised narrative arc:** Evaluation Gap → Methodology Proposal → Empirical Characterization → Implications

**Abstract Outline (4-5 sentences):**
- S1 (Problem): "Out-of-distribution (OOD) generalization evaluations typically vary the type of distribution shift while keeping the degree of each shift fixed."
- S2 (Gap): "This fixed-degree evaluation can mask qualitatively different robustness patterns, leading to incomplete conclusions about model reliability."
- S3 (Method): "We propose evaluating models across a continuous range of shift degrees within each shift type, enabling a fine-grained characterization of robustness."
- S4 (Key results): "Across extensive experiments, we find that model robustness is strikingly brittle: performance under mild shifts does not predict performance under even slightly stronger shifts, and large-scale pre-trained models can be more sensitive than randomly initialized models to novel downstream shifts."
- S5 (Implication): "Our findings suggest that evaluation protocols should systematically vary shift degrees, and that conclusions drawn from fixed-degree evaluations warrant re-examination."

### Introduction Outline (5 paragraphs)

**P1 — The evaluation blind spot.**
Role: Establish the importance of OOD evaluation and identify the overlooked dimension of shift degree.
Claim: Current benchmarks focus on diversity of shift *types* while fixing shift *degree*.
Evidence: Cite Koh et al. (2021), Hendrycks et al. (2021), Gulrajani & Lopez-Paz (2021) as examples.
Transition: "This fixed-degree approach creates a blind spot that we illustrate in Figure 1."

**P2 — Why degree matters (Figure 1).**
Role: Use the motivating figure to explain why two-point evaluation is insufficient.
Claim: Two distinct robustness patterns (graceful degradation vs. abrupt collapse) cannot be distinguished at a single OOD test point.
Transition: "To address this blind spot, we introduce an evaluation protocol that systematically varies shift degrees."

**P3 — Our evaluation protocol and key empirical questions.**
Role: State the paper's methodological contribution — continuous-degree evaluation.
Claim: "We construct datasets with monotonically increasing shift degrees and evaluate models across all degrees."
State the two empirical questions clearly: (i) Does mild-shift performance predict strong-shift performance? (ii) Does strong-shift training protect mild-shift performance?
Transition: "Through extensive experiments, we find the answer to both questions is task-dependent."

**P4 — Summary of key findings.**
Role: Present the three key empirical findings in a structured way.
Claim 1: Mild→strong extrapolation fails even for adjacent degrees.
Claim 2: Strong→mild generalization works for noise but fails for rotation.
Claim 3: CLIP models are more brittle than scratch models on rare shifts.
Transition: "These findings have direct implications for both evaluation methodology and model deployment."

**P5 — Contributions and roadmap.**
Role: Explicit contribution list + paper structure.
Contribution 1: Shift-degree-aware evaluation protocol.
Contribution 2: Empirical characterization of brittleness across shift types.
Contribution 3: Evidence that pre-trained models can be paradoxically brittle.

## Priority Revision Plan
**P0 — Critical (publication-blocking if unaddressed)**

| Priority | Issue | Action | Expected Impact |
|----------|-------|--------|-----------------|
| P0 | Ambiguous CLIP "40%" claim (Issue 1) | Replace with explicit absolute/relative values | Resolves factuality concern on headline finding |
| P0 | Overclaim about generalizability (Issue 4) | Replace with bounded statement | Restores scientific credibility |

**P1 — Major (must address before acceptance)**

| Priority | Issue | Action | Expected Impact |
|----------|-------|--------|-----------------|
| P1 | Unsupportive breaking point mechanism (Issue 2) | Add quantitative feature analysis; replace causal with correlational language | Validates or qualifications the mechanistic explanation |
| P1 | Missing hypothesis for dataset asymmetry (Issue 3) | Add hypothesis paragraph in Section 4.3 | Converts observation into actionable insight |
| P1 | Missing limitations in Conclusion (W6) | Insert explicit limitations paragraph | Completes scientific framing |
| P1 | Introduction lacks explicit contribution methodology | Restructure using recommended storyline (see Section 6) | Improves reader comprehension of paper's value |

**P2 — Quality improvement (address before next submission)**

| Priority | Issue | Action | Expected Impact |
|----------|-------|--------|-----------------|
| P2 | Title does not convey methodology | Revise title to include "Evaluation Across Shift Degrees" | Better positioning |
| P2 | Composite shift ordering unvalidated (W7) | Add monotonicity validation for LowLightCIFAR10 | Framework integrity |
| P2 | Reproducibility details missing (Experiment Setup) | Clarify random search procedure and validation metric | Improved reproducibility |
| P2 | Relative drops cited inconsistently (Page 6) | Unify relative drop reporting with absolute context | Reader clarity |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|--------|-----------|-------|---------|-------------|----------------|-------------------|
| E1 | Mild→strong extrapolation (Section 4.2) | NoisyMNIST, 20+ DG algos, CNN/ResNet-50, train on D0-D1 | Accuracy per degree | >50% relative drop D4→D5 | C1 (brittle extrapolation) | Selection based on top-3 models; no per-seed trajectory analysis |
| E2 | ResNet-50 scale effect (Section 4.2) | NoisyMNIST, ResNet-50, same protocol | Accuracy per degree | Pattern persists but gaps narrow | C1 | Only one larger architecture tested |
| E3 | Algorithm comparison (Section 4.2) | NoisyMNIST, all DG algos | Accuracy per degree | Algorithms show distinct cross-degree patterns | C1 | DG advantage diminishes with more training domains |
| E4 | GradCAM analysis (Section 4.2) | ERM vs CAD on NoisyMNIST | GradCAM visualization | ERM uses local features, CAD uses global | C1 (mechanism hypothesis) | Only 2 models, few examples; no quantitative metric |
| E5 | Strong→mild generalization (Section 4.3) | NoisyMNIST, RotatedMNIST, LowLightCIFAR10, CNN/ResNet-50/EfficientNet-b0, train on {D0, Dk} | Accuracy per degree | Noise: strong→mild works; Rotation: fails | C2 | No mechanistic explanation for difference |
| E6 | CLIP sensitivity (Section 5.2) | NoisyMNIST, RotatedMNIST, NoisyImageNet15, LR-ImageNet15, CLIP vs IN vs RI, linear probing | Accuracy per degree | CLIP more brittle on rare shifts (noise) | C3 | Linear probing only; no full fine-tuning |
| E7 | Effects of more training domains (Appendix B.1) | NoisyMNIST, train on {D0-Dk} for k=1..4 | Accuracy per degree | More domains reduce gaps slowly | C1 (supplementary) | Only tested up to 5 training domains |
| E8 | Impulse Noise MNIST (Appendix B.2) | ImpulseNoiseMNIST | Accuracy per degree | Pattern similar to LowLightCIFAR10 | C1, C2 | Preliminary; not discussed in main text |

### Research-Theme Gap Diagnosis

- **New knowledge:** The paper contributes empirical observations about brittleness. However, without a mechanistic explanation or predictive framework, the knowledge is descriptive rather than explanatory. The core research value would increase substantially if the paper could predict *when* strong→mild generalization works vs. fails.
- **Reproducibility:** Good. DomainBed implementation, hyperparameter budgets, and extensive appendix tables support reproducibility.
- **Impact on practice:** Currently limited. Practitioners learn "be careful with fixed-degree evaluations" but receive no concrete guidance on how to determine whether their shift type behaves like noise or rotation.

### Proposed Research Experiments (P0/P1/P2)

**Exp P0.1 — Quantitative feature robustness metric (P0, must for mechanism claim)**
- Target Claim: C1 (breaking point mechanism)
- Hypothesis: Models transition from brittle narrow features to robust global features at a measurable shift degree
- Minimal Design: For each model, compute the Earth Mover Distance between GradCAM attention maps at adjacent degrees; identify the degree at which the attention pattern changes most rapidly
- Metrics: Attention-change onset degree, correlation with accuracy drop
- Success Criterion: A statistically significant correlation (r > 0.5) between attention-change onset and accuracy drop onset
- Estimated Cost: Low (reuses existing models, adds analysis code)
- Expected Gain: Converts qualitative GradCAM into quantitative mechanism evidence

**Exp P0.2 — Full fine-tuning for CLIP experiments (P0, must for C3 claim)**
- Target Claim: C3 (CLIP brittleness)
- Hypothesis: CLIP brittleness may be reduced with full fine-tuning vs. linear probing
- Minimal Design: Repeat Section 5.2 experiments with full fine-tuning of CLIP on NoisyMNIST (D0-D1)
- Metrics: Accuracy per degree, gap vs. randomly initialized models
- Success Criterion: Determine whether full fine-tuning eliminates, reduces, or preserves the CLIP brittleness gap
- Estimated Cost: Moderate (requires GPU hours for CLIP fine-tuning)
- Expected Gain: Either strengthens C3 (if brittleness persists) or qualifies it (if fine-tuning resolves it)

**Exp P1.1 — Asymmetry hypothesis test (P1, must for C2)**
- Target Claim: C2 (dataset-dependent asymmetry)
- Hypothesis: The destroy-vs-transform nature of the shift determines strong→mild generalization
- Minimal Design: Test two new shifts on MNIST: (a) random cropping (destroys spatial structure), (b) color jitter (transforms appearance). If the hypothesis holds, cropping behaves like noise, jitter behaves like rotation
- Metrics: Strong→mild generalization slope (accuracy at D0 - accuracy at Dmax)
- Success Criterion: Consistent with destroy-vs-transform classification
- Estimated Cost: Low (MNIST-based, CNN architecture)
- Expected Gain: Provides actionable guidance for practitioners; converts empirical observation into a testable framework

**Exp P1.2 — Natural shift validation (P1, important for generalizability)**
- Target Claim: Generalizability claims
- Hypothesis: Brittleness patterns hold for natural shifts (e.g., WILDS-Camelyon17)
- Minimal Design: Identify natural datasets with severity annotations; evaluate ERM and one robust algorithm (Mixup) across natural severity levels
- Metrics: Accuracy per severity level; correlation with synthetic shift results
- Success Criterion: Qualitative pattern match (brittleness present/absent)
- Estimated Cost: Moderate (requires access to WILDS datasets)
- Expected Gain: Substantially increases external validity and practical relevance

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score: 6.0/10**

*Justification:* The paper addresses a genuinely important and under-explored question (shift degree as an evaluation dimension). The empirical scope is extensive (20+ algorithms, 5 datasets, multiple architectures) and the core observation — that robustness can be strikingly brittle across adjacent shift degrees — is well-supported by the data. However, the paper has significant weaknesses that prevent a higher score: (1) ambiguous quantitative claims about the CLIP finding undermine the headline result; (2) the mechanistic "breaking point" explanation is unsupported; (3) the dataset-dependent asymmetry is observed but not explained, limiting practical value; (4) overclaims about generalizability beyond synthetic shifts; and (5) the CLIP experiments use only linear probing, which limits the strength of conclusions about pre-trained model brittleness. The paper also lacks a limitations section. On novelty, the contribution is primarily empirical — the evaluation methodology (continuous shift-degree evaluation) is more a protocol than a technical innovation, but it is a useful extension of existing practices.

**Post-Revision Target: [7.0, 7.5]/10**

*Justification:* If the authors address all P0 and P1 issues — clarifying the CLIP quantitative claim, adding a hypothesis for dataset-dependent asymmetry, bounding the breaking point explanation with quantitative evidence, and adding a limitations section — the paper's scientific quality would substantially improve. The remaining gap to 7.5+ would depend on adding at least one validation experiment on natural distribution shifts and full fine-tuning for CLIP, which would significantly strengthen external validity and practical relevance.