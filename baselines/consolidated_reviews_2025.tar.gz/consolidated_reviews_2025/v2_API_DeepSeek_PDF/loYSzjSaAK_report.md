## Summary
# Final Review Report

## Summary

This paper introduces **Submodular Reinforcement Learning (SUBRL)**, a paradigm that generalizes classical RL by replacing additive, history-independent rewards with monotone submodular set functions defined over trajectories. The key idea is that submodular rewards naturally capture diminishing returns — a property central to many real-world tasks including coverage control, path planning, and experimental design.

The paper makes four core contributions: (C1) the SUBRL framework with formal problem definition; (C2) SUBPO, a policy gradient algorithm that maximizes marginal gains rather than immediate rewards, with an unbiased gradient estimator (Theorem 2); (C3) theoretical characterizations including a hardness-of-approximation lower bound (Theorem 1, Ω(log^{1-γ} OPT)), a (1-1/e) guarantee under the ϵ-Bandit SMDP assumption via DR-submodularity, and a (1-c) curvature-based guarantee; and (C4) empirical demonstrations across six environments spanning discrete and continuous domains, from biodiversity monitoring to MuJoCo locomotion.

**Overall assessment:** The paper tackles a well-motivated and technically interesting problem. The theoretical framework connecting submodularity to RL is elegant, and the gradient estimator in Theorem 2 is a clean contribution with meaningful variance reduction. However, there are several weaknesses that reduce confidence in the results: (1) a potential gap in the curvature-based guarantee proof (Proposition 3); (2) a lack of experimental rigor — no quantitative summary statistics, error bars, or statistical significance testing; (3) missing baseline comparisons against dedicated submodular optimization algorithms; (4) a composite reward confound in the MuJoCo Ant experiment that is only disclosed in the appendix; and (5) restrictive theoretical assumptions that limit the applicability of the provable guarantees. Novelty claims require manual literature verification (deferred due to Retrieval-Disabled Mode).

## Strengths
1. **Well-motivated problem framing.** The paper identifies a genuine limitation of standard MDPs — the inability to naturally model diminishing returns — and proposes a principled solution via submodular set functions. The examples (coverage control, experiment design, path planning) are compelling and practically relevant.

2. **Clean theoretical contributions.** The policy gradient estimator in Theorem 2, which uses marginal gains instead of immediate rewards with a flexible baseline, is a technically sound generalization of standard policy gradient. The connection to DR-submodular optimization under the ϵ-Bandit SMDP setting provides a rigorous theoretical foundation, even if the assumptions are restrictive.

3. **Inapproximability result.** Theorem 1 establishes that the SUBRL problem is Ω(log^{1-γ} OPT)-hard to approximate through a reduction to the Submodular Orienteering Problem. This is an important negative result that delineates the fundamental limits of the framework and justifies the need for structural assumptions in the positive results.

4. **Algorithmic simplicity.** SUBPO is straightforward — it takes the REINFORCE gradient estimator and replaces the cumulative return with cumulative marginal gains. This simplicity makes it easy to implement on top of existing RL codebases, as evidenced by the use of PyTorch's automatic differentiation.

5. **Diverse empirical evaluation.** The paper evaluates SUBPO across six environments spanning discrete (grid-world path planning, item collection) and continuous (car racing, MuJoCo Ant) domains. This breadth demonstrates that the marginal-gain-based approach works beyond the simplified settings where theoretical guarantees hold.

## Weaknesses
1. **Proof gap in curvature-based guarantee (Proposition 3).** The proof (Appendix E.2) argues that if π is a stationary point for the submodular objective J, then it is also a stationary point for the modular objective H. This requires showing that ⟨∇_π J(π), π' - π⟩ ≤ 0 for all feasible π' implies ⟨∇_π H(π), π' - π⟩ ≤ 0, using only the component-wise inequality ∇_π J ≥ (1-c)∇_π H. This implication does not follow without additional sign assumptions on (π' - π). The inner product of a larger vector with an arbitrary direction is not guaranteed to be sign-preserving. This gap potentially invalidates the (1-c) guarantee for general SMDPs.

2. **Restrictive theoretical assumptions.** The (1-1/e) guarantee (Section 5) requires the ϵ-Bandit SMDP, which assumes state-independent transitions — essentially removing the MDP structure and reducing to a bandit. The curvature guarantee (1-c) is proven only for tabular SMDPs. Neither guarantee directly applies to the empirical settings (MuJoCo Ant, car racing, building exploration) which involve high-dimensional, state-dependent dynamics. The paper acknowledges this implicitly but does not clearly articulate the gap between theory and practice.

3. **Experimental rigor deficits.** Learning curves are reported without error bars, final numerical values, or statistical significance tests. The claim of "sample efficiency" is not operationalized (e.g., epochs to 90% of final performance). Only 20 runs are mentioned in the appendix for each experiment, but the main text reports only qualitative trends ("SUBPO achieves performance as good as SUBPO-NM"). The building exploration experiment (Fig. 5a) does not include error bars or confidence bands.

4. **Missing baseline comparisons.** The only baseline is MODPO — a standard RL algorithm that uses the modular (singleton) reward. No comparison against dedicated submodular optimization algorithms (e.g., recursive greedy for SOP [Chekuri & Pal 2005], multi-linear extension planning [Wang et al. 2020], or submodular bandit algorithms [Yue & Guestrin 2011]) is provided. This makes it difficult to assess whether SUBPO offers advantages beyond what simpler submodular maximization approaches would achieve on these tasks.

5. **Reward confound in MuJoCo Ant.** The main text (Page 9) presents the Ant experiment as a demonstration of SUBPO on high-dimensional problems, but Appendix F reveals that the reward function couples MuJoCo's built-in additive walking rewards with the submodular coverage reward. The sum of a modular function (walking bonus) and a submodular function is not guaranteed to be submodular. This confound is not disclosed in the main text, making the empirical claim ambiguous.

6. **Missing limitations paragraph.** The Conclusion lacks an explicit limitations section, which is standard for ICLR papers. Important limitations include: the gap between theoretical guarantees and empirical practice, the lack of formal sample complexity characterization, sensitivity to the choice of submodular function, and computational overhead of computing marginal gains.

7. **Novelty claims require verification.** The statement "this is the first work to consider submodular objectives in RL" (Page 1) is a strong claim that cannot be fully verified without external literature search (deferred due to Retrieval-Disabled Mode). While the paper provides a comprehensive discussion of related work (convex RL, submodular bandits, adaptive submodularity), the precise boundaries of novelty relative to these areas should be delineated more carefully.

## Key Issues
The following issues are ranked by severity and impact on the paper's validity and research value:

### Issue 1 (Critical): Gap in curvature-based guarantee proof (Proposition 3)
- **Location:** Page 6 — Proposition 3 and Appendix E.2
- **Evidence:** The proof attempts to show that a stationary point of the submodular objective J is also a stationary point of the modular objective H, using ∇_π J ≥ (1-c)∇_π H component-wise. However, this sign-preservation implication from ∇_π J to ∇_π H via inner products is not generally valid without additional sign constraints on (π' - π).
- **Impact:** If the proof step is unsalvageable, the (1-c) guarantee for general SMDPs is not established. This would remove one of the two main provable guarantees.
- **Recommendation:** Provide a corrected proof that addresses the sign direction issue, or add an explicit assumption about the direction of policy updates that preserves the guarantee.

### Issue 2 (Major): Experimental confound in MuJoCo Ant
- **Location:** Page 9 (main text) and Page 23 (Appendix F)
- **Evidence:** Appendix F reveals that the Ant reward combines MuJoCo's inbuilt additive walking rewards with submodular coverage rewards. Main text does not disclose this. The sum of a modular and submodular function may not preserve submodularity.
- **Impact:** The Ant experiment cannot be purely attributed to SUBPO's marginal-gain mechanism. It conflates a standard walking reward with the submodular objective.
- **Recommendation:** Report results with purely submodular coverage reward as primary experiment, and move composite reward to an ablation study.

### Issue 3 (Major): Missing quantitative experimental rigor
- **Location:** Pages 7-9, Section 7 (Experiments)
- **Evidence:** No numerical final performance values, no error bars on learning curves, no statistical significance tests. The claim of "sample efficiency" is qualitative.
- **Impact:** The empirical results cannot be independently assessed or reproduced reliably. Confidence intervals are essential for comparing stochastic policy gradient methods across runs.
- **Recommendation:** Add a summary table with mean ± std final normalized objective across 20 runs for each environment and method, and report epochs to 90% of final performance.

### Issue 4 (Major): Theory-practice gap unacknowledged
- **Location:** Pages 5-6, Section 5
- **Evidence:** The ϵ-Bandit SMDP assumption (state-independent transitions) is highly restrictive. The curvature guarantee only holds for tabular SMDPs. Neither applies to the high-dimensional continuous experiments.
- **Impact:** The theoretical framework and empirical evaluation are only loosely connected. Readers may overestimate the theoretical backing for the empirical results.
- **Recommendation:** Add an explicit paragraph in the main text clarifying which theoretical results apply to which experimental settings.

### Issue 5 (Major): Missing SOP/submodular baselines
- **Location:** Page 7, Section 6 (Related Work) and Section 7 (Experiments)
- **Evidence:** The paper discusses SOP and adaptive submodularity as related frameworks but does not compare SUBPO against any algorithm from these areas.
- **Impact:** Without a broader baseline comparison, the empirical advantage of SUBPO over existing submodular optimization approaches is unclear.
- **Recommendation:** Add comparisons against recursive greedy (for deterministic tasks) and submodular bandit algorithms (for stochastic tasks), or add a discussion explaining why such comparison is infeasible.

## Actionable Suggestions
### S1 (Must): Fix the curvature proof gap (Proposition 3)
**Problem:** The proof's implication from ∇_π J ≥ (1-c)∇_π H to stationary point equivalence is not fully justified.  
**Action:** Revise Appendix E.2 to either (a) provide a rigorous argument using directional derivatives and the fact that at a stationary point ⟨∇J, π - π'⟩ ≥ 0 for all feasible π', which combined with ∇J ≥ (1-c)∇H only yields ⟨∇H, π - π'⟩ ≥ 0 when ∇H ≥ 0, or (b) add an explicit assumption that the gradient update direction is non-negative in all policy parameters.  
**Location:** Page 6, Proposition 3; Appendix E.2, Page 21  
**Expected benefit:** Restores the curvature-based guarantee or clarifies its scope.

### S2 (Must): Add quantitative experimental results with statistics
**Problem:** Learning curves are shown without error bars, final values, or significance tests.  
**Action:** Add a summary table (Table 1 in main text) reporting final normalized objective values as mean ± std across 20 runs for each environment and method (SUBPO-M, SUBPO-NM, MODPO). Add statistical significance indicators (e.g., Welch's t-test p-values for SUBPO-M vs MODPO). Report "epochs to 90% of final performance" as a sample efficiency metric.  
**Location:** Pages 7-9, Section 7  
**Expected benefit:** Transforms qualitative claims into quantifiable, reproducible evidence.

### S3 (Must): Disclose composite reward structure in main text
**Problem:** The MuJoCo Ant experiment uses a composite reward with an additive walking bonus, only disclosed in Appendix F.  
**Action:** Move this detail to the main text (Page 9) and add an ablation study comparing SUBPO with pure submodular coverage reward vs. composite reward. Explicitly state whether the sum of the walking bonus and coverage function preserves submodularity.  
**Location:** Page 9 (main text) and Page 23 (Appendix)  
**Expected benefit:** Removes experimental confound and clarifies the empirical contribution.

### S4 (Recommended): Add SOP/submodular baselines or discussion
**Problem:** The only baseline is MODPO; no comparison against dedicated submodular optimization algorithms.  
**Action:** Add at least one comparison against a submodular optimization approach (e.g., recursive greedy for deterministic environments, or a submodular bandit algorithm for stochastic settings). If comparison is infeasible, add a paragraph explaining the practical differences (online vs offline, known vs unknown dynamics) that limit direct comparability.  
**Location:** Page 7, Section 7  
**Expected benefit:** Strengthens empirical contribution and clarifies positioning relative to existing submodular optimization literature.

### S5 (Recommended): Add explicit limitations paragraph
**Problem:** The Conclusion lacks a limitations section.  
**Action:** Add 3-4 sentences discussing: (a) the gap between theoretical assumptions and practical settings, (b) the lack of formal sample complexity guarantees, (c) sensitivity to the choice of submodular reward function, and (d) computational overhead of marginal gain computation.  
**Location:** Page 9, Section 8  
**Expected benefit:** Improves scientific rigor and reviewer reception.

### S6 (Nice-to-have): Fix sign error in Theorem 1 proof (Appendix B)
**Problem:** The reduction in Appendix B (Page 15) sets H ← -B, which is inconsistent with MDP definition (negative horizon).  
**Action:** Correct to H ← B and verify consistency of the budget-constrained walk interpretation.  
**Location:** Page 15, Appendix B  
**Expected benefit:** Fixes a formal error that does not affect the result but improves correctness.

### S7 (Nice-to-have): Clarify baseline nondifferentiability in Theorem 2
**Problem:** The statement "Theorem 2 holds for any choice of baseline critic" could mislead practitioners.  
**Action:** Add a note that the baseline must not be differentiated through when estimating ∇_θ J.  
**Location:** Page 4, Theorem 2  
**Expected benefit:** Prevents implementation errors and improves reproducibility.

## Storyline Options + Writing Outlines
### Current Storyline Assessment

The current narrative structure is: MDP background → limitation (additive rewards) → submodularity as solution → contributions list → technical details → theory → algorithm → experiments → conclusion.

**Strengths of current storyline:** The paper clearly identifies a gap (additive rewards insufficient for diminishing returns), proposes a solution (submodular RL + SUBPO), and provides a mix of theory and experiments.

**Weaknesses:** (1) The contributions list (Page 1-2) is overly long and mixes paradigm introduction with technical results, making it hard for readers to retain the key takeaway. (2) The hardness result (Theorem 1) is presented before the algorithm, which is an unusual ordering — a reader may be demotivated before seeing the proposed solution. (3) The problem statement section (Section 2) is quite dense with notation before the reader has developed intuition for why submodular rewards are useful.

### Recommended Storyline Revision

Rearrange narrative to: **Motivation → Intuition → Positive Results → Hardness Context → Empirical Validation → Scoped Conclusion**

**Abstract Outline (complete revision target):**
- **S1 (Problem):** "In reinforcement learning, additive rewards cannot capture diminishing returns that arise naturally in coverage control, experimental design, and path planning."
- **S2 (Gap):** "Existing RL frameworks cannot efficiently optimize history-dependent, non-additive objectives without exponential state blowup."
- **S3 (Solution):** "We propose SUBRL, a paradigm that models rewards as monotone submodular set functions, and SUBPO, a policy gradient algorithm that greedily maximizes marginal gains."
- **S4 (Results):** "SUBPO achieves provable constant-factor guarantees under structural MDP assumptions and demonstrates sample-efficient exploration across six environments."
- **S5 (Bound):** "A complementary inapproximability result establishes fundamental limits, while our findings suggest submodular rewards offer a principled extension of RL for diminishing-return tasks."

**Introduction Outline (6 paragraphs):**
- **P1 (Big Picture):** State that standard MDPs assume additive, Markovian rewards. Cite real tasks where this fails (coverage, experimentation). Define diminishing returns and give a concrete example.
- **P2 (Gap):** Explain that naive state augmentation leads to exponential complexity. Prior attempts (convex RL, reward shaping) address specific aspects but lack a unified treatment of diminishing returns over trajectories.
- **P3 (Proposed Idea):** Introduce submodular set functions as a natural model for diminishing returns. Define marginal gain intuitively. State that the key idea is to maximize marginal gains rather than immediate rewards.
- **P4 (Algorithm + Theory):** Preview SUBPO — it uses the same policy gradient machinery as REINFORCE but replaces additive returns with cumulative marginal gains. Mention that provable guarantees exist under structural assumptions (bandit-like MDPs, bounded curvature).
- **P5 (Hardness Context):** State that despite these positive results, the general problem is provably hard to approximate (log-factor lower bound). This motivates the need for assumptions and establishes the boundary of tractability.
- **P6 (Contributions + Roadmap):** List 3-4 concise bullet contributions, clearly distinguishing paradigm, algorithm, theoretical guarantees, and empirical validation. End with a roadmap paragraph.

## Priority Revision Plan
The following plan is ordered by impact on paper validity and acceptance likelihood. Each item is labeled as P0 (critical, must fix before acceptance), P1 (important, strongly recommended), or P2 (improvement, nice-to-have).

### P0 Items (Pre-Acceptance Critical)

| Priority | Issue | Required Action | Effort | Impact |
|----------|-------|----------------|--------|--------|
| P0.1 | Curvature proof gap (Proposition 3) | Fix the sign-preservation implication in Appendix E.2 or add an explicit assumption | Low | Restores core theoretical guarantee |
| P0.2 | MuJoCo Ant reward confound | Disclose composite reward in main text; add pure-submodular ablation | Medium | Removes validity threat to empirical claims |
| P0.3 | Missing quantitative results | Add summary table with mean±std, significance tests, and sample efficiency metric | Medium | Essential for reproducibility and assessment |

### P1 Items (Strongly Recommended)

| Priority | Issue | Required Action | Effort | Impact |
|----------|-------|----------------|--------|--------|
| P1.1 | Missing limitations paragraph | Add 3-4 sentences discussing assumptions, sample complexity, and computational costs | Low | Improves scientific rigor |
| P1.2 | Missing SOP/submodular baselines | Add comparison or discussion explaining infeasibility | Medium-High | Strengthens empirical positioning |
| P1.3 | Sign error in Theorem 1 proof | Correct H ← -B to H ← B in Appendix B | Low | Fixes formal error |
| P1.4 | Restrictive assumptions gap | Add clarifying paragraph connecting theory to practice | Low | Prevents overinterpretation |

### P2 Items (Quality Improvements)

| Priority | Issue | Required Action | Effort | Impact |
|----------|-------|----------------|--------|--------|
| P2.1 | Abstract structure | Restructure into compact 5-sentence format | Low | Readability |
| P2.2 | Baseline nondifferentiability in Theorem 2 | Add clarifying sentence about learned baselines | Low | Reproducibility |
| P2.3 | Time-index notation in marginal gain | Clarify F(sj+1|τ0:j) denotes time-augmented state | Low | Clarity |
| P2.4 | Contribution ordering in introduction | Restructure to algorithm-first narrative | Medium | Narrative flow |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Environment | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|--------|-------------|---------------------|-------|---------|--------------|-----------------|-------------------|
| E1 | Informative Path Planning (Gorilla) | SUBPO achieves better coverage than MODPO | Grid-world, 5 actions, deterministic dynamics, gorilla nest density | Normalized J(π) vs epochs | SUBPO-M and SUBPO-NM outperform MODPO; MODPO gets stuck | SUBPO effective for coverage tasks | No numerical final values, no error bars |
| E2 | Informative Path Planning (synthetic) | Same trend holds for arbitrary multimodal functions | Same grid-world, synthetic GP samples | Normalized J(π) vs epochs | Same trend as E1 | Robustness across reward functions | Same as E1 |
| E3 | Item Collection | History-dependent policy needed for optimal item collection | Grid with item groups, stochastic dynamics (0.9/0.1) | Normalized J(π) vs epochs | SUBPO-NM best, SUBPO-M comparable | Markovian policies insufficient | Only qualitative comparison |
| E4 | Bayesian D-Experimental Design | SUBPO maximizes mutual information along trajectory | GP-based reward, 10 random environments, 20 runs | Normalized J(π) vs epochs | SUBPO-M matches SUBPO-NM, MODPO stuck | SUBPO effective for info-gathering | No quantitative MI values reported |
| E5 | Building Exploration | Non-Markovian policy needed to explore both rooms | Two-room corridor, deterministic dynamics | Normalized J(π) vs epochs | SUBPO-NM explores both rooms, SUBPO-M stuck | History matters for exploration | Single environment configuration |
| E6 | Car Racing | SUBPO scales to continuous control | 6D state, 2D action, 700 horizon, coverage reward | Normalized lap completion (0→1) | SUBPO-M learns to drive, MODPO stays stationary | SUBPO scales to high dimensions | Composite reward not controlled |
| E7 | MuJoCo Ant | SUBPO scales to high-dimensional locomotion | 30D state, 8D action, 400 horizon | Normalized coverage area | SUBPO-M explores, MODPO stationary | SUBPO scales to high dimensions | **Confound:** composite reward includes additive walking bonus |

### Research-Theme Gap Diagnosis

1. **New knowledge:** The paper establishes clean theoretical connections (submodularity → DR-submodularity) and a practical algorithm. However, the gap between the provable guarantees (ϵ-Bandit SMDP, tabular curvature) and the empirical demonstrations (high-dimensional, state-dependent MDPs) significantly reduces the scientific contribution margin.

2. **Reproducibility/reusability:** Code is provided, and the algorithm is straightforward. However, the lack of quantitative summary statistics and the undisclosed composite reward for the Ant experiment reduce reproducibility.

3. **Potential to change practice/understanding:** The marginal-gain-based gradient estimator is the most impactful practical contribution — it's simple, principled, and could be adopted in RL applications where diminishing returns matter. However, the paper does not provide implementable guidance on when the approach outperforms simple reward shaping, limiting its practical impact.

### Proposed Research Experiments

#### P0 Experiment (Must, for Validity)

| Field | Value |
|-------|-------|
| **Target Claim** | C3 (curvature-based guarantee) and C4 (empirical scalability) |
| **Hypothesis** | SUBPO with purely submodular coverage reward outperforms MODPO on MuJoCo Ant |
| **Minimal Design** | Run SUBPO-M on Ant with F(τ) = \|∪_{s∈τ} D_s\| only, no additive walking bonus. Use same horizon (400), batch size (15), learning rate (10^-2) as reported. |
| **Controls/Baselines** | MODPO with same pure coverage reward; SUBPO with composite reward (current setup) |
| **Metrics** | Normalized coverage area at convergence (epoch 20,000), mean±std over 20 seeds |
| **Success Criterion** | SUBPO-pure achieves >2x coverage of MODPO-pure at convergence |
| **Estimated Cost** | ~6 hours on single-core CPU (same as current setup) |
| **Expected Gain** | Removes the reward confound and validates the central empirical claim |

#### P1 Experiment (Strongly Recommended, for Robustness)

| Field | Value |
|-------|-------|
| **Target Claim** | C4 (sample efficiency and scalability) |
| **Hypothesis** | SUBPO-M requires fewer environment interactions than MODPO to reach target coverage |
| **Minimal Design** | For each of the 6 environments, compute "epochs to 90% of final converged value" from existing learning curves. Report as a table. |
| **Controls/Baselines** | Same runs already completed (20 per environment) |
| **Metrics** | Epochs to 90% final value, mean±std |
| **Success Criterion** | SUBPO-M reaches 90% final value in ≤ 60% of the epochs required by MODPO |
| **Estimated Cost** | ~1 hour (analysis only, no new training) |
| **Expected Gain** | Operationalizes the "sample efficiency" claim with a concrete, reproducible metric |

#### P1 Experiment (Strongly Recommended, for External Validity)

| Field | Value |
|-------|-------|
| **Target Claim** | C1 (SUBRL paradigm applicable to diverse submodular rewards) |
| **Hypothesis** | SUBPO outperforms an SOP-based baseline (recursive greedy) on deterministic IPP tasks |
| **Minimal Design** | On the gorilla nest IPP environment (deterministic), compare SUBPO-M against the recursive greedy algorithm [Chekuri & Pal 2005] using the same budget (H=40) and coverage objective |
| **Controls/Baselines** | MODPO, recursive greedy |
| **Metrics** | Final coverage value, computation time |
| **Success Criterion** | SUBPO-M achieves ≥ 90% of recursive greedy coverage |
| **Estimated Cost** | ~1-2 hours (implement recursive greedy + run comparison) |
| **Expected Gain** | Provides a stronger baseline and clarifies the empirical contribution relative to existing submodular optimization approaches |

#### P2 Experiment (Nice-to-have, for Completeness)

| Field | Value |
|-------|-------|
| **Target Claim** | C3 (DR-submodularity connection) |
| **Hypothesis** | On ϵ-Bandit SMDP instances, the Frank-Wolfe variant achieves (1-1/e) approximation as predicted |
| **Minimal Design** | Construct a small ϵ-Bandit SMDP instance (3 states, 3 actions, H=5, ε=0.1). Compare SUBPO and the Frank-Wolfe algorithm from Bian et al. (2017c) in terms of converged objective value relative to optimal. |
| **Success Criterion** | Both algorithms achieve ≥ 60% of optimal (i.e., at least 1-1/e ≈ 0.63) |
| **Estimated Cost** | ~1-2 hours |
| **Expected Gain** | Provides empirical validation of the DR-submodularity theory |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score: 6.0 / 10**

**Evidence-grounded rationale:** The paper addresses a well-motivated problem with a clean theoretical framework and a practical algorithm. The main strengths are the conceptual contribution (submodular rewards in RL), the elegant gradient estimator (Theorem 2), and the breadth of empirical evaluation. However, the score is constrained by:

1. **Validity risk (-1.5):** A proof gap in the curvature-based guarantee (Proposition 3) and a reward confound in the MuJoCo Ant experiment undermine confidence in the core theoretical and empirical claims.
2. **Experimental rigor (-1.0):** Missing quantitative summary statistics, error bars, and statistical significance tests reduce the evidential value of the experimental section.
3. **Assumption-realism gap (-0.5):** The provable guarantees apply to settings (ϵ-Bandit SMDP, tabular SMDP) that do not match the empirical demonstrations, leaving the theory-practice connection loose.
4. **Novelty verification (-0.5):** The "first work to consider submodular objectives in RL" claim requires literature verification (deferred due to Retrieval-Disabled Mode).

**Post-Revision Target: [7.0, 7.5] / 10**

Achievable after:
- Fixing the curvature proof gap (P0.1): +0.5
- Resolving the Ant reward confound with clean ablation (P0.2): +0.5
- Adding quantitative results with statistics (P0.3): +0.5
- Adding explicit limitations paragraph (P1.1): +0.2
- Adding stronger baselines or discussion (P1.2): +0.3

The upper bound of 7.5 reflects the inherent limitation that the provable guarantees apply to restrictive settings; this is a structural feature of the work that cannot be fully eliminated in revision but can be made transparent.