## Summary
# Final Review Report

## Summary

This paper proposes LogoRA (Local-Global Representation Alignment), a framework for unsupervised domain adaptation (UDA) of time series data. The core idea is to jointly extract and align both local features (via multi-scale convolutional encoders) and global features (via a patching transformer encoder), integrate them through a cross-attention fusion module, and apply multiple alignment losses (DTW-based patch alignment, triplet loss, adversarial domain discrimination, and per-class prototype alignment). The method is evaluated on four human-activity and sleep-stage datasets (HHAR, WISDM, HAR, Sleep-EDF) and compared against 10 baselines (5 time-series-specific UDA methods and 5 general UDA methods).

**Strengths:** The motivation for combining local and global features is well-articulated with intuitive examples. The architecture design is systematic, combining established components (convolution, Transformer patching, cross-attention fusion, adversarial training) into a coherent pipeline. The experimental evaluation is relatively comprehensive with 10 domain pairs per dataset. Ablation studies for both loss functions and architecture choices provide useful diagnostic insights.

**Core Weaknesses:** (1) The "state-of-the-art" and "first UDA structure" claims are over-extended given the evidence—variance/statistical tests are missing, several domain pairs show negative improvements, and the "first" claim cannot be verified without external literature. (2) The center loss formulation (min_j) has a known failure mode (wrong-class pulling) that is acknowledged only in the appendix. (3) The architecture ablation is conducted in a source-only setting rather than the full UDA pipeline, limiting causal attribution. (4) Related work comparisons lack depth, especially against the strongest baseline RAINCOAT. (5) Results lack variance reporting, making small-margin improvements (e.g., HAR +0.51%) statistically unverifiable.

## Strengths
1. **Well-motivated problem framing.** The paper makes a convincing case that time-series UDA requires both local and global features. The concrete illustration (walking upstairs vs downstairs, Figure 1) clearly shows why neither pure-local (TCN last-step features) nor pure-global approaches alone are sufficient.

2. **Systematic architecture design.** The two-branch encoder (multi-scale ConvNet + patching Transformer) followed by cross-attention fusion is a logical instantiation of the problem framing. The use of patching (inspired by PathTST) for the global encoder is sensible—it provides a compact, position-aware representation of temporal segments.

3. **Multi-faceted alignment strategy.** The paper combines four complementary alignment mechanisms (DTW-based patch alignment for time-shift invariance, triplet loss for intra-class concentration, adversarial domain discrimination for global distribution alignment, and per-class prototype alignment for fine-grained class-level transfer). The ablation study (Table 2) shows that each component contributes, with the full combination achieving best results.

4. **Thorough evaluation protocol.** The evaluation covers 4 datasets with 10 domain pairs each (40 total domain-transfer scenarios), using both time-series-specific and general UDA baselines. The HHAR dataset shows particularly strong gains (+12.52% average over RAINCOAT).

5. **Informative visualizations.** Cross-attention heatmaps (Figure 6) and t-SNE plots (Figure 7, Appendix Figure 9) provide qualitative evidence that the fusion module attends to informative local regions and produces well-separated, domain-aligned clusters.

## Weaknesses
1. **Overclaimed novelty and SOTA positioning.** The contribution bullets claim "first UDA structure that learns a contextual representation considering both local and global patterns" (Page 2), and the conclusion states "state-of-the-art performance" (Page 9). These claims cannot be verified from the manuscript alone—external literature retrieval is needed to check whether prior methods (e.g., RAINCOAT's time-frequency encoder, multi-scale CNNs with attention) already capture local+global features. Even within the paper's own data, LogoRA underperforms baselines on 5 out of 40 domain pairs (negative improvement), and the average gain on HAR is only +0.51%. The "SOTA" and "first" wording should be softened until verified against the full literature.

2. **Missing statistical reliability.** All numerical results (Table 1, Table 2, Table 3) are reported as point estimates without standard deviations, confidence intervals, or significance tests. Given that many improvements are small (e.g., +0.10% on HHAR 8→3), the reader cannot assess whether these differences are statistically meaningful or due to random seed variation.

3. **Hidden failure modes of center loss.** The center loss Eq (4) uses min_j to select the nearest source prototype for each target sample, which can actively pull target samples toward wrong-class prototypes. This failure is empirically observed (Appendix F.7, domain pair 2→4) but is not disclosed in the main method section (Sec 3.5). The main text presents Lcenter as a straightforward enhancement without warning about this risk.

4. **Architecture ablation confound.** The architecture ablation (Table 3) trains all models in a source-only setting (without any UDA alignment losses), limiting its ability to inform architecture choices under the full pipeline. A backbone that scores higher in source-only mode may not provide the same advantage when alignment losses are active.

5. **Related work lacks depth.** The comparison against the strongest baseline RAINCOAT (time-frequency encoder + Sinkhorn divergence) is superficial. The paper claims RAINCOAT "has not fully explored the local and global features" without specifying why RAINCOAT's frequency-domain features are insufficient relative to LogoRA's explicit local-global factorization.

6. **Reproducibility gaps.** The Global Encoder's intra-patch aggregation mechanism (transition from R^{M×P×D} to R^{M×D}) is not specified (Page 4). The adversarial training implementation (GRL vs manual sign) is not explicitly stated despite the unusual minus sign in Eq (5). These ambiguities could lead to implementation divergence.

## Key Issues
### Issue 1: Overclaimed novelty and SOTA (Severity: Major, Pages 1-2, 9)
The paper claims "first UDA structure" and "state-of-the-art" without sufficient evidence. External literature verification is needed to check whether prior methods (RAINCOAT, CLUDA, multi-scale attention models) already capture local and global features. Within the paper's data, 5 of 40 domain pairs show negative improvement, and the HAR improvement is only +0.51%. SOTA claims must be bounded and qualified.

### Issue 2: Missing statistical validation (Severity: Major, Pages 6-7)
All results are point estimates without variance or significance tests. On HHAR 8→3 (+0.10%), Sleep-EDF 16→1 (-7.99%), and HAR 19→25 (-4.83%), the differences are within noise range. Without std/CI, the claim of consistent improvement is not statistically verifiable.

### Issue 3: Center loss failure mode not disclosed in main text (Severity: Major, Page 5)
Eq (4)'s min_j operator can pull target samples toward wrong-class prototypes. This is empirically shown (Appendix F.7) and causes accuracy drops on domain pair 2→4. The main method section presents Lcenter as unconditionally beneficial; this is misleading.

### Issue 4: Architecture ablation design confound (Severity: Major, Page 7)
Table 3 ablates architectures in a source-only (no alignment) setting. The advantage of LogoRA's architecture under the full pipeline is not directly tested against alternatives like PatchTST+adversarial.

### Issue 5: Shallow related-work positioning (Severity: Major, Page 14)
The comparison against RAINCOAT (strongest baseline) is generic. RAINCOAT uses frequency features that intrinsically capture multi-scale information—the paper does not explain why this differs from LogoRA's explicit local-global factorization.

### Issue 6: Reproducibility gaps (Severity: Minor, Page 4, 5)
Intra-patch aggregation (M×P×D→M×D) is not specified. Adversarial training implementation (GRL vs manual sign) is unclear given the minus sign in Eq (5).

## Actionable Suggestions
### S1: Add variance reporting and significance tests (Must, P0)
Report mean ± std over at least 3 random seeds for all main results (Table 1). Add a paired significance test (Wilcoxon signed-rank or t-test) comparing LogoRA against the strongest baseline (RAINCOAT) per dataset.

### S2: Soften the "first" and "SOTA" claims (Must, P0)
- Remove "first UDA structure" from contribution C1. Replace with: "To our knowledge, LogoRA is among the first UDA methods for time series to explicitly separate and align local and global features via a two-branch architecture."
- Replace "state-of-the-art" in Conclusion (Page 9) with: "LogoRA achieves competitive or superior average accuracy on four benchmark datasets, with clear gains on HHAR and WISDM and more modest improvements on HAR and Sleep-EDF."
- Include a sentence acknowledging the 5 domain pairs where LogoRA underperforms the best baseline.

### S3: Disclose center loss failure mode in main text (Must, P0)
Add a caveat paragraph after Eq (4) in Sec 3.5: "Note that Lcenter may pull target samples toward the nearest source prototype even when that prototype belongs to a different class, degrading accuracy when initial features are poorly aligned. We mitigate this by applying Lglobal first to concentrate intra-class features; see Appendix F.7."

### S4: Re-run architecture ablation under full UDA pipeline (Must, P1)
Select 3-4 key architectures (source-only best, PatchTST, Global+Local without multi-scale, full LogoRA) and train them with the complete loss (all λ > 0) on HHAR 10 pairs. This would directly test whether the two-branch architecture advantage persists when alignment is active.

### S5: Add intra-patch aggregation specification (Must, P1)
In the Global Encoder description (Page 4), specify the aggregation: "After self-attention within each patch, we mean-pool the P token vectors to obtain a single D-dimensional vector per patch, yielding o''_i ∈ R^{M×D}."

### S6: Deepen related-work comparison (Must, P1)
Add one sentence per baseline in Appendix A explaining concrete technical differences. Example for RAINCOAT: "RAINCOAT aligns time and frequency features via Sinkhorn divergence but does not explicitly separate local convolutional features from global attention features, nor does it apply DTW-based time-step invariant alignment." Consider adding a comparison table.

### S7: Clarify adversarial training implementation (Nice-to-have, P2)
State explicitly whether Gradient Reversal Layer (GRL) is used and confirm that Eq (5)'s minus sign is compatible with the chosen implementation.

### S8: Add OOD/complex dataset evaluation discussion (Nice-to-have, P2)
The CAP dataset results (Appendix Table 9) show LogoRA outperforming baselines but with low absolute accuracy (~0.50). Discuss practical limitations more concretely in the main paper.

## Storyline Options + Writing Outlines
### Abstract Outline (Revised)
Target 5-sentence structure:
- **S1 (Problem):** "Time series classification models often fail under domain shift, and existing unsupervised domain adaptation (UDA) methods struggle to capture both short-term local features and long-range global dependencies."
- **S2 (Gap):** "Prior approaches rely on single-scale encoders (RNNs, CNNs, or standard Transformers) that cannot simultaneously represent transient discriminative events and overall temporal structure."
- **S3 (Method):** "We propose LogoRA, a two-branch framework with a multi-scale convolutional encoder for local features, a patching Transformer encoder for global features, and a cross-attention fusion module that integrates both."
- **S4 (Alignment):** "To achieve domain-invariant representations, LogoRA combines DTW-based patch alignment for time-shift robustness, triplet loss for intra-class concentration, adversarial domain discrimination, and per-class prototype alignment."
- **S5 (Result + Bound):** "On four benchmark datasets (HHAR, WISDM, HAR, Sleep-EDF), LogoRA achieves an average improvement of 6.40% over the strongest baseline, with larger gains on HHAR (+12.52%) and WISDM (+10.21%) and more modest gains on Sleep-EDF (+2.36%) and HAR (+0.51%)."

### Introduction Outline (Revised)
**P1 — Big Picture and Gap:** Replace generic territory opening. Start with the concrete performance degradation under domain shift for time series (cite 15-30% drops). Then state: existing feature extractors (RNNs, CNNs, Transformers) operate at a single temporal scale, but time series classification often depends on both brief transient patterns (local) and long-term temporal structure (global). End with the gap: no prior UDA method jointly models and aligns both scales.

**P2 — Motivation (Figure 1):** Keep the walking upstairs/downstairs example but condense to 3-4 sentences. Show: (a) local features alone are insufficient when classes share similar short patterns, (b) global structure alone misses discriminative transients. Conclude: both are needed.

**P3 — Method Preview:** "We propose LogoRA, a two-branch encoder that extracts local features via multi-scale convolutions and global features via a patching Transformer. A cross-attention fusion module integrates both. For alignment, we combine DTW-based patch alignment, triplet loss, adversarial training, and prototype alignment."

**P4 — Contributions:** Keep the three bullets but revise C1 to remove "first" wording (see S2 above). C2 should separate DTW metric learning from adversarial+prototype alignment as distinct contributions. C3 should include the 6.40% average improvement number and note that gains vary by dataset.

### Storyline Candidate Comparison

| Dimension | Current Storyline | Revised Storyline |
|---|---|---|
| Opening | Generic "time series is ubiquitous" | Concrete "domain shift causes 15-30% drop" |
| Gap clarity | Implicit (Page 2, Figure 1) | Explicit: single-scale encoders cannot jointly model local+global |
| Contribution positioning | "First UDA structure" (unverifiable) | "First to explicitly separate and align local+global via two-branch design" |
| Result presentation | "Won 4/4 datasets" | "Average 6.40% gain; varies by dataset" |
| Limitations | Buried in Conclusion (vague) | Integrated throughout: center loss risk, variance missing, parameter cost |
| Recommendation | Adopt revised storyline for stronger reader engagement and defensibility. |

## Priority Revision Plan
```text
ASCII Diagram — Revision Strategy Roadmap

[Current issues: overclaims, no variance, center loss hidden, 
 shallow related work, reproducibility gaps]

         |  P0 (Before resubmission, high impact)
         |  
         ├── S1. Add variance reporting (seeds/std/significance)
         |     Expected: statistical validity for all claims
         |
         ├── S2. Soften "first"/"SOTA" claims
         |     Expected: reviewer trust, reduced vulnerability
         |
         ├── S3. Disclose center loss failure in main text
         |     Expected: scientific honesty, preempts reviewer concern
         |
         |  P1 (Within 1-2 weeks, medium-high impact)
         |
         ├── S4. Re-run architecture ablation under full pipeline
         |     Expected: confirms architecture contribution
         |
         ├── S5. Add intra-patch aggregation specification
         |     Expected: reproducibility
         |
         ├── S6. Deepen related-work comparison vs RAINCOAT
         |     Expected: stronger novelty positioning
         |
         |  P2 (Before final version, lower impact)
         |
         ├── S7. Clarify GRL/sign implementation
         ├── S8. Discuss CAP dataset limitations concretely
```

| Priority | Action | Location | Effort | Expected Impact |
|---|---|---|---|---|
| P0 | Add variance (≥3 seeds, std) | Table 1, Sec 4.2 | Medium | High: establishes statistical reliability |
| P0 | Remove "first"/"SOTA" claims | Abstract, C1, Conclusion | Low | High: prevents reviewer rejection |
| P0 | Disclose center loss caveat | Sec 3.5, after Eq (4) | Low | High: scientific transparency |
| P1 | Full-pipeline architecture ablation | Table 3, Sec 4.3 | Medium | Medium: confirms architecture claims |
| P1 | Specify intra-patch aggregation | Sec 3.2 (Global Encoder) | Low | Medium: reproducibility |
| P1 | Deepen related work comparison | Appendix A | Medium | Medium: stronger positioning |
| P2 | Clarify adversarial impl details | Sec 3.5 or Appendix B | Low | Low: implementation clarity |
| P2 | Discuss CAP dataset limitations | Sec 5 or Appendix H | Low | Low: honest scoping |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective/Hypothesis | Setup (data/split/protocol/baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Main UDA comparison | 4 datasets × 10 domain pairs; 10 baselines | Accuracy (point estimate) | LogoRA highest avg on all 4 datasets | C3 (performance) | No variance/std; 5/40 pairs show negative delta |
| E2 | Loss function ablation (Table 2) | HHAR, 10 pairs; add/remove Lcls/Ldomain/Lglobal/Ldtw/Lcenter | Accuracy (4 selected pairs, 10 avg) | Full combination best (0.872 avg) | C2 (component efficacy) | Ablation on HHAR only; single seed |
| E3 | Architecture ablation (Table 3) | HHAR, 10 pairs; source-only training | Accuracy (4 selected pairs, 10 avg) | LogoRA architecture best (0.707 source-only) | C1 (architecture design) | Trained without alignment losses; confounded |
| E4 | Hyperparameter sensitivity (Table 7) | HHAR; vary lr, layers, patch length, kernels, loss weights | Accuracy (3 pairs + avg) | Robust to modest variation; best at defaults | C1, C2 (design choices) | One dataset only |
| E5 | Cross-attention visualization (Fig 6) | HAR, 1 example | Attention heatmap | Multi-scale kernels attend to informative local regions | C1 (fusion module) | Single example; qualitative only |
| E6 | t-SNE visualization (Fig 7, Fig 9) | HHAR 8→3; LogoRA vs RAINCOAT vs CLUDA vs raw | t-SNE 2D projection | LogoRA shows tighter, better-aligned clusters | C2 (alignment efficacy) | One domain pair; qualitative |
| E7 | CAP dataset evaluation (Table 9) | CAP, 6 domain pairs; MMDA/CDAN/CLUDA/RAINCOAT | Accuracy | LogoRA best (0.506 avg), all methods low | C3 (generalizability) | Low absolute accuracy (~0.50); limited baselines |
| E8 | Inference time/parameters (Fig 8) | All methods | Log(params), Log(MFLOPs) | LogoRA slightly higher cost | Transparency | Not integrated into main text discussion |

### Research-Theme Gap Diagnosis

- **New Knowledge (Novelty):** The core claim (joint local+global extraction for UDA) cannot be fully evaluated without external literature verification. The paper's own contribution boundary is unclear—how much is genuinely new vs incremental over RAINCOAT's time-frequency encoder or multi-scale CNNs.
- **Reproducibility:** Two gaps identified (intra-patch aggregation, adversarial implementation sign). Variance missing makes cross-study comparison impossible.
- **Impact on Practice/Understanding:** The method's higher parameter count vs moderate gains (especially on HAR +0.51%) limits practical deployment motivation. The failure on CAP (0.50 accuracy) shows the approach has significant room for improvement on complex, high-dimensional data.

### Proposed Research Experiments

**P0 Experiment: Statistical Validation**
- **Target Claim:** C3 (LogoRA achieves superior UDA performance)
- **Hypothesis:** LogoRA's improvements are statistically significant against RAINCOAT
- **Minimal Design:** Run full Table 1 (4 datasets × 10 pairs) with 5 random seeds each
- **Controls/Baselines:** RAINCOAT (strongest competitor) with same seeds
- **Metrics:** Mean ± std accuracy; paired Wilcoxon signed-rank test per dataset
- **Success Criterion:** p < 0.05 for HHAR and WISDM; report p-value for all
- **Estimated Cost/Time:** ~3-5 GPU-days (parallelizable)
- **Expected Paper-Quality Gain:** High—turns point estimates into statistically valid evidence

**P1 Experiment: Full-Pipeline Architecture Ablation**
- **Target Claim:** C1 (two-branch architecture outperforms single-branch under UDA)
- **Hypothesis:** LogoRA's architecture advantage over PatchTST+adversarial persists with all alignment losses
- **Minimal Design:** Compare (a) PatchTST only + full losses, (b) ConvNet only + full losses, (c) LogoRA + full losses on HHAR 10 pairs
- **Controls/Baselines:** Same loss hyperparameters (λ values) across all architectures
- **Metrics:** Per-pair and average accuracy; feature alignment metrics (A-distance, MMD)
- **Success Criterion:** LogoRA > (a) and (b) by at least 1% average
- **Estimated Cost/Time:** ~1-2 GPU-days
- **Expected Paper-Quality Gain:** Medium—confirms architecture contribution is not an artifact of source-only testing

**P2 Experiment: Center Loss Failure Analysis**
- **Target Claim:** C2 (per-class prototype alignment is beneficial)
- **Hypothesis:** The failure mode (wrong-class pulling) can be mitigated by class-conditional thresholding
- **Minimal Design:** On HHAR 2→4 (the problematic pair), compare (a) Lcenter full, (b) Lcenter with cosine similarity threshold (only align when similarity > τ), (c) Lcenter with soft assignment weights
- **Controls/Baselines:** No Lcenter baseline (Lcls + Ldomain + Lglobal + Ldtw)
- **Metrics:** Accuracy; per-class alignment quality
- **Success Criterion:** Thresholded version outperforms vanilla Lcenter
- **Expected Cost/Time:** ~0.5 GPU-day
- **Expected Paper-Quality Gain:** Medium—turns a known weakness into methodological improvement

```text
ASCII Diagram — Experiment Upgrade Plan

Stage 1 (P0, must-have): Statistical Validation
  [Table 1 current] --> [5 seeds, std, Wilcoxon test]
  Expected: from point estimates to significance-aware reporting

Stage 2 (P1, should-have): Full-Pipeline Architecture Ablation
  [Table 3 source-only] --> [full UDA pipeline, 3 architectures]
  Expected: from confounded to causal architecture attribution

Stage 3 (P2, nice-to-have): Center Loss Fix
  [Eq 4 min_j failure] --> [thresholded/soft prototype assignment]
  Expected: from hidden failure to documented improvement
```

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
### Final Score: 5.5 / 10

**Rationale:** The paper presents a technically sound and well-motivated architecture for time-series UDA, with a clear problem framing and comprehensive evaluation on four benchmarks. However, three factors substantially limit the score under a research-value-and-novelty-focused assessment:

1. **Novelty uncertainty (primary limiter):** The core claims of being "first" and "state-of-the-art" cannot be verified from the manuscript alone. External literature retrieval is required to determine the true novelty margin over methods like RAINCOAT (time-frequency encoder), multi-scale CNNs with attention, and contrastive UDA methods that already capture multi-scale patterns. Score impact: -2.0.

2. **Statistical validation gap:** All results are point estimates without variance or significance testing. The small-margin improvements on HAR (+0.51%) and Sleep-EDF (+2.36%) are unverifiable, and 5 of 40 domain pairs show negative improvement. Score impact: -1.5.

3. **Methodological transparency issues:** The center loss failure mode is hidden in the appendix, the architecture ablation is confounded (source-only setting), and key implementation details (intra-patch aggregation, GRL usage) are underspecified. Score impact: -1.0.

Strengths partially offset these: strong motivation, systematic architecture, multi-faceted alignment strategy, and extensive ablation studies (+0.5 adjustment from baseline).

### Post-Revision Target: [6.5, 7.5] / 10

If the authors address the P0 items (add variance reporting, soften claims, disclose center loss caveat) and P1 items (full-pipeline architecture ablation, deepened related-work comparison), the score could rise to the 6.5-7.5 range. The upper bound assumes the novelty claims hold up under external literature verification and that the statistical validation confirms significant improvements on at least 3 of 4 datasets.