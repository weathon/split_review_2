## Summary
# Final Review Report

## Summary

This paper introduces LayoutSciPG, a task for automatically generating scientific posters from full-length papers through integrated multimodal content extraction and layout design. The authors construct SciPG, a dataset of 11,302 paper-poster pairs collected from CVPR, ICML, NeurIPS, and ICLR proceedings — substantially larger than prior datasets (which contain fewer than 100 pairs). They propose a multimodal extractor-generator framework consisting of: (1) a Multimodal Document Extractor (MDE) using RoBERTa + BiLSTM for joint text/image selection, and (2) an Interactive Generator (IG) based on BART with an adaptive memory mechanism for paraphrasing extracted content and predicting layout positions.

The paper addresses a real and underexplored problem: automatic scientific poster generation requires simultaneously handling content extraction, abstractive paraphrasing, and spatial layout prediction — three subtasks that prior work addresses separately. The dataset contribution is significant and addresses a clear gap in the field. The method is technically sound in its overall design, combining established components (RoBERTa, CLIP, BART, RMT memory) in a novel pipeline.

However, several issues reduce the paper's overall impact: (1) a critical formula-level error in Eq.(3) where the extraction loss uses softmax (multi-class) instead of sigmoid (multi-label), contradicting the task requirements and the text's claim of binary cross-entropy; (2) the Overlap metric interpretation is ambiguous and the absolute layout quality (5x ground-truth overlap) is understated; (3) element alignment quality for dataset construction is unreported despite being critical for all downstream training; (4) the conclusion and third contribution bullet are generic and lack concrete, bounded findings. Novelty verification against external literature could not be performed in this run (Retrieval-Disabled Mode), so comparative novelty claims are deferred for manual verification.

## Strengths
1. **Large-scale dataset contribution.** SciPG (11,302 paper-poster pairs) is an order of magnitude larger than existing datasets (NCE: 60, PGM: 25, NJU-Fudan: 85), covering four top CS conferences. This fills a clear resource gap in the scientific poster generation field and enables data-driven approaches that were previously infeasible.

2. **Well-motivated task formulation.** The paper identifies a genuine gap: prior work treats content extraction and layout generation separately, leading to suboptimal results. The proposed LayoutSciPG task definition — requiring joint multimodal extraction, paraphrasing, and layout prediction — is a natural and useful problem decomposition.

3. **Clean architectural decomposition.** The extractor-generator framework is modular and interpretable: MDE handles element selection, IG handles content rewriting + layout. The use of special index tokens ("[img i]") for image representation is a pragmatic design that allows a text-based generator (BART) to handle multimodal output without architectural modifications.

4. **Comprehensive evaluation with multiple metrics.** The paper evaluates text quality (ROUGE), image selection (ImgP/ImgR), layout quality (Overlap, Coverage, Validity, Alignment, FD, DreamSim), and human perception (3 criteria × 10 annotators). This multi-faceted evaluation is more thorough than many prior multimodal generation papers.

5. **Ablation studies.** Table 6 systematically ablates KL-Divergence, pretraining strategy, data extension, and three memory variants (adaptive, normal, none), providing evidence for the contribution of each component. The ablation on memory (settings a, f, g) directly tests the paper's main technical claim.

## Weaknesses
1. **Formula-level inconsistency in extraction loss (Critical).** Eq.(3) defines the extraction loss using softmax normalization over all elements (sentences + images), which enforces multi-class selection (exactly one element chosen). However, the extraction task is inherently multi-label: multiple sentences and images must be extracted simultaneously. The text claims 'standard binary cross-entropy loss,' but the equation implements something fundamentally different. This mismatch between equation and text, and between loss formulation and task requirement, is a correctness issue that could invalidate the reported extraction results.

2. **Overlap metric interpretation is ambiguous (Major).** The Overlap metric (IoU of layout elements) produces values of 25.08% (IG) and 47.44% (AdaD2P), while ground-truth posters have only 5.11%. The paper frames the 22.36% reduction as an 'improvement,' but the absolute values are still 5-9x the ground truth. The metric direction (lower is better? higher is better?) is never explicitly clarified, and the large gap to ground truth suggests layout overlap remains a severe, unsolved problem rather than a success.

3. **Element alignment quality is unreported (Major).** The dataset construction relies on automatic sentence matching (via RoBERTa cosine similarity) and image matching (via CLIP cosine similarity with threshold 0.8). No accuracy metrics, manual verification rates, or threshold sensitivity analyses are reported. Since alignment quality directly determines the quality of training labels for both extraction and generation, this omission leaves the entire empirical evaluation's data foundation unvalidated.

4. **Weak contribution framing (Minor).** The third contribution bullet is a generic outcome statement ('Both automatic and human evaluation results demonstrate the effectiveness'), not a concrete technical contribution. The abstract also lacks any quantitative results, making it hard for readers to assess the paper's empirical magnitude from the summary alone.

5. **Generic conclusion (Minor).** The conclusion simply recaps the introduction without stating bounded limitations or concrete next steps. The phrase 'remaining challenges' is never specified.

6. **Related Work reads as textbook-level summaries (Minor).** The Text Summarization subsection (2.1) recites basic extractive vs abstractive distinctions that are common knowledge, without specifically critiquing why these methods fail for poster generation. Space could be better used for deeper analysis of closely related methods.

7. **Missing coordinate system specification (Minor).** The bounding box notation (x0,y0,w,h) is defined without specifying whether coordinates are normalized or absolute, how they are discretized for token generation, or how canvas size is handled.

## Key Issues
### Issue 1 (Critical): Extraction loss formulation mismatch [Page 5, Eq. (3)]
- **Problem**: Eq.(3) implements softmax-based multi-class cross-entropy over all sentences and images, which forces the model to select exactly one element. The extraction task requires selecting multiple elements simultaneously (multi-label).
- **Evidence**: The equation defines $p_{tv}(\tilde{h}) = \exp(f_{cls}(\tilde{h})) / \sum_{\tilde{h} \in [h'_t; h'_v]} \exp(f_{cls}(\tilde{h}))$ and $L_{ext} = -\sum \log p_{tv}(\tilde{h})$. This is a softmax with cross-entropy over all candidate elements. The text claims 'standard binary cross-entropy loss' but the equation does not match this.
- **Impact**: If training used the softmax formulation, the model would be penalized for selecting multiple correct elements, directly degrading ImgP/ImgR and ROUGE scores. If the implementation actually uses binary cross-entropy (as the text claims), then Eq.(3) is incorrect and must be corrected for reproducibility.
- **Fix**: Replace Eq.(3) with per-element sigmoid + binary cross-entropy: $p_{tv}(\tilde{h}_i) = \sigma(f_{cls}(\tilde{h}_i))$, $L_{ext} = -\sum_i [y_i \log(p_{tv}(\tilde{h}_i)) + (1-y_i)\log(1-p_{tv}(\tilde{h}_i))]$.

### Issue 2 (Major): Overlap metric interpretation [Page 8, Evaluation Metrics; Table 4]
- **Problem**: The Overlap metric (IoU) produces values of 5.11% (GT), 25.08% (IG), and 47.44% (AdaD2P). The paper claims '22.36% improvement in overlap' without clarifying direction. Both methods produce 5-9× the ground-truth overlap, indicating severe element overlapping.
- **Evidence**: Table 4 shows IG Overlap=25.08 vs GT=5.11. The text says 'our method achieves a 22.36% improvement in overlap' — this is the absolute reduction from AdaD2P's 47.44% to IG's 25.08%, but the gap to GT is 20 percentage points.
- **Impact**: Without clarifying that lower overlap (closer to GT) is better, and without discussing the large absolute gap, the current framing overstates layout quality.
- **Fix**: Clarify direction ('lower Overlap is better, with a target of 5.11%'); reframe as 'Overlap remains 5× the ground-truth level, indicating that element overlap is a major unresolved challenge.'

### Issue 3 (Major): Alignment quality for dataset construction [Page 13, Appendix A1]
- **Problem**: The dataset uses automatic RoBERTa-based sentence alignment and CLIP-based image alignment (threshold δ=0.8), but reports no accuracy/precision/recall metrics for alignment quality.
- **Evidence**: Appendix A1 describes the alignment pipeline without any quantitative validation. The entire supervised training signal depends on alignment correctness.
- **Impact**: Noisy alignment introduces label noise that propagates through extractor training and generator training. Without accuracy metrics, reviewers cannot assess data quality.
- **Fix**: Report alignment accuracy on a manually verified sample (e.g., 200 pairs), provide threshold sensitivity analysis for δ, and discuss how alignment errors affect downstream performance.

## Actionable Suggestions
### S1 (Must): Fix Eq.(3) — Replace softmax with per-element sigmoid + binary cross-entropy
**Location**: Page 5, Section 4.2, Eq.(3)
**Action**: Replace the current softmax-based multi-class formulation with per-element binary classification:
```
p_i = σ(f_cls(h'_i))   for each element i
L_ext = -Σ_i [y_i·log(p_i) + (1-y_i)·log(1-p_i)]
```
**Rationale**: This matches the task requirement (select multiple elements) and aligns the equation with the text's claim of 'binary cross-entropy loss.'
**Verification**: After fixing, re-run the MDE results. The multi-label BCE loss should give the extractor more flexibility and potentially improve ImgR (recall) since the model is no longer forced to pick one element.

### S2 (Must): Clarify Overlap metric and add honest error analysis
**Location**: Page 8, Section 5.1 and Table 4 analysis (Section 5.4)
**Action**: (a) Explicitly state: 'Lower Overlap is better; the ground-truth overlap is 5.11%.' (b) Reframe the discussion: 'Our method reduces Overlap from 47.44% (AdaD2P) to 25.08%, but this remains ~5× the ground-truth level, indicating that element overlap is not yet solved.' (c) Add a column 'Δ to GT' showing the gap between each method's Overlap and the ground truth.

### S3 (Must): Report alignment accuracy with manual verification
**Location**: Page 13, Appendix A1 (and briefly in Section 3 main text)
**Action**: (a) Manually verify 200 sentence pairs and 200 image pairs. Report precision, recall, and F1 for alignment. (b) Perform threshold sensitivity analysis for δ ∈ {0.6, 0.7, 0.8, 0.9} — show match rate and estimated accuracy at each threshold. (c) Add one paragraph in Section 3 discussing alignment quality and its impact on training.

### S4 (Nice-to-have): Add quantitative anchors to abstract
**Location**: Page 1, Abstract
**Action**: Replace 'demonstrate the effectiveness' with concrete numbers: e.g., 'MDE achieves 40.68 ROUGE-1 and 44.43% ImgP, outperforming baselines by 2-13 points. The interactive generator improves layout coverage by 25% over AdaD2P.'

### S5 (Nice-to-have): Restructure third contribution bullet
**Location**: Page 2, Contribution list
**Action**: Replace the generic outcome bullet with a concrete technical contribution, e.g., 'We introduce an adaptive memory mechanism (extending RMT) that improves layout overlap by 22% and coverage by 25% over non-adaptive baselines.'

### S6 (Nice-to-have): Strengthen conclusion with bounded limitations
**Location**: Page 10, Section 6
**Action**: Restructure into: (1) validated findings with numbers, (2) specific limitations (overlap gap, layout aesthetics), (3) concrete next steps (post-processing overlap reduction, aesthetic-aware objectives, end-to-end pretraining).

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)

Current abstract structure: Problem → Gap → Dataset → Method → Qualitative result → Challenge mention.

**Recommended revision (5-sentence structure)**:

- **S1 (Problem + Domain)**: 'Scientific poster generation requires jointly extracting key content from a paper, paraphrasing it concisely, and arranging it in a visually coherent layout — three capabilities that prior work addresses independently.'
- **S2 (Gap)**: 'Existing methods focus on either layout composition or content extraction separately, and the largest available dataset contains fewer than 100 paper-poster pairs, limiting data-driven approaches.'
- **S3 (Dataset)**: 'We construct SciPG, a dataset of 11,302 paper-poster pairs from CVPR, ICML, NeurIPS, and ICLR, with aligned text and image elements.'
- **S4 (Method)**: 'We propose a multimodal extractor-generator framework: a hierarchical extractor (RoBERTa + BiLSTM) selects key text and images, and an interactive BART-based generator with adaptive memory paraphrases content and predicts layout positions.'
- **S5 (Key Result + Bounded Claim)**: 'Our extractor achieves 40.68 ROUGE-1 and 44.43% ImgP, outperforming prior methods by 2-13 points. The generator improves layout coverage by 25% over AdaD2P, though element overlap remains 5× higher than human-designed posters, highlighting layout quality as the primary open challenge.'

### Introduction Outline (Complete)

**Current paragraph map (Pages 1-2)**:
- P1: General motivation (too many papers → posters help → creation is hard).
- P2: Prior work review + gap statement.
- P3: Table 1 (dataset comparison) + three challenge enumeration.
- P4: Approach summary + contribution list.

**Recommended restructured outline**:

- **P1 (Stakes + Specific Challenge)**: Replace the generic 'too many papers' opening. Start with the core challenge: 'A scientific poster must simultaneously (i) extract the most salient textual and visual content from a full-length paper, (ii) rewrite the extracted text into a concise, poster-appropriate form, and (iii) arrange all elements in a spatially coherent layout — three tasks that prior multimodal generation systems handle in isolation.' This immediately signals the paper's specific focus.

- **P2 (Prior Work + Concrete Gap)**: Keep the literature review but make it more precise. Replace 'have not performed well' with specific evidence: e.g., 'Layout-focused methods (Qiang et al., 2016, 2019) rely on TextRank for extraction, which produces ROUGE scores below 25 on poster text; content-focused methods (Xu & Wan, 2021, 2022) use fixed LaTeX templates and cannot adapt to different canvas sizes. No existing system jointly optimizes extraction, paraphrasing, and layout.' Add Table 1 after this paragraph for visual support.

- **P3 (Our Approach + High-Level Solution)**: 'We address these limitations with a multimodal extractor-generator framework. A hierarchical extractor (RoBERTa + BiLSTM) identifies key sentences and images from the paper. An interactive BART-based generator then sequentially processes each extracted element, paraphrasing text and predicting its layout position, enabled by an adaptive memory module that handles long input-output sequences within GPU memory constraints.'

- **P4 (Contribution Summary)**: Keep the three bullet contributions but replace the third bullet with a concrete technical contribution as specified in S5 above.

### Candidate Storyline

**Best storyline: 'Joint Extraction-Paraphrasing-Layout' arc**
The paper's strongest framing is that it unifies three previously separate capabilities into one end-to-end framework. The narrative should emphasize: (1) prior work treats extraction and layout as separate stages → (2) this separation causes information loss and suboptimal results → (3) our framework breaks this by using an interactive generator that conditions layout on content and vice versa → (4) the adaptive memory mechanism makes this joint approach computationally feasible for long documents. This arc aligns well with the paper's actual contribution.

## Priority Revision Plan
### P0 (Must fix before acceptance)

| # | Issue | Action | Location | Expected Impact |
|---|-------|--------|----------|-----------------|
| 1 | Eq.(3): softmax vs BCE mismatch | Replace with per-element sigmoid + binary cross-entropy | Page 5, Section 4.2 | Correctness of training; reproducibility |
| 2 | Overlap metric ambiguity | Clarify direction, add gap-to-GT column, reframe narrative | Page 8, Sec 5.1 + 5.4 | Honest assessment of layout quality |
| 3 | Alignment quality unreported | Report manual verification accuracy + threshold sensitivity | Appendix A1 + Section 3 | Data quality validation |

### P1 (Must fix for strong submission)

| # | Issue | Action | Location | Expected Impact |
|---|-------|--------|----------|-----------------|
| 4 | Abstract lacks quantitative results | Add key numbers (ROUGE, ImgP, Overlap) | Page 1, Abstract | Discoverability, reader engagement |
| 5 | Third contribution bullet is generic | Replace with concrete technical claim | Page 2, Contributions | Stronger contribution framing |
| 6 | Conclusion is generic | Restructure into validated findings + limitations + next steps | Page 10, Section 6 | Scientific closure |
| 7 | Coordinate system unspecified | Add normalization/discretization details | Page 4, Section 4.1 | Reproducibility |

### P2 (Nice-to-have for quality improvement)

| # | Issue | Action | Location | Expected Impact |
|---|-------|--------|----------|-----------------|
| 8 | Related Work §2.1 reads as textbook | Condense and focus on poster-specific critique | Page 2-3, Section 2 | Better positioning |
| 9 | Pretraining masking ratio unjustified | Add ablation for masking ratio | Section 4.3.3 | Evidence for design choice |
| 10 | Data extension details missing | Specify shuffle count, training protocol | Section 4.3.4 | Reproducibility |
| 11 | Ablation isolation for memory | Add clean head-to-head comparison (adaptive vs normal vs none) | Section 5.4 | Clearer contribution attribution |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective | Setup (Data/Baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|--------|-----------|----------------------|---------|-------------|-----------------|-------------------|
| E1 | Multimodal element extraction (Table 3) | SciPG test set; baselines: NeuralExt, MSMO, AdaD2P | ROUGE-1/2/L, ImgP, ImgR | MDE achieves 40.68 ROUGE-1, 44.43 ImgP — best overall | C2 (extractor quality) | No variance/std reported; single seed |
| E2 | Multimodal generation (Table 4) | SciPG test set; baseline: AdaD2P | ROUGE, Overlap, Coverage | IG achieves 41.05 ROUGE-1, 25.08 Overlap, 37.43 Coverage | C2 (generator quality) | Overlap still 5× GT; only one baseline |
| E3 | Layout evaluation (Table 5) | SciPG test set; baseline: AdaD2P | Val, Ali, FD, DreamSim | Ours: 0.9765 Val, 18.23 FD | C2 (layout quality) | DreamSim favors baseline (0.1314 vs 0.2436) — not discussed |
| E4 | Ablation: MDE w/o LSTM (Table 3) | SciPG test set; MDE minus LSTM | ROUGE, ImgP, ImgR | Significant drop: 36.73 ROUGE-1, 40.26 ImgP | C2 (LSTM importance) | Not tested on generator |
| E5 | Ablation: generator components (Table 6) | SciPG test set; 7 settings (KL/PT/DE/Memory) | ROUGE, Overlap, Coverage | Full (a) best; no memory increases Overlap to 42.94 | C3 (memory mechanism) | Confounds: settings drop multiple components simultaneously |
| E6 | Topic-aware evaluation (Table 7) | Per-conference train/test splits | ROUGE, Overlap, Coverage, ImgP, ImgR | 'All' outperforms per-topic for text/layout; CVPR best for images | C1 (dataset generalizability) | Topic overlap not analyzed; per-topic data size varies |
| E7 | Parameter sensitivity (Fig 2) | Vary k (0-100) and β (0-1.0) | ROUGE, Overlap, Coverage | Best: k=50, β=0.5 | C3 (adaptive memory tuning) | Only reports layout metrics; text metrics 'comparable' — no figure shown |
| E8 | Human evaluation (Fig 3) | 50 samples, 10 annotators, 3 criteria (1-5 scale) | Text Relevance, Image Accuracy, Layout Aesthetics | Ours > AdaD2P on all; all < 3.5 on Layout Aesthetics | C2 (human-perceived quality) | Only 50 samples; inter-annotator agreement not reported |

### Research-Theme Gap Diagnosis

- **New Knowledge**: The paper provides a new dataset (clear) and a new framework (moderate). However, the core technical novelty of the adaptive memory mechanism is incremental over RMT (Bulatov et al., 2022) — the main difference is applying cross-attention to update memory between segments. Whether this 'adaptive' component substantially differs from RMT's recurrent memory is not clearly established.
- **Reproducibility**: Several details are missing: coordinate normalization scheme, alignment accuracy, data shuffling parameters, training epoch count, inference decoding strategy (greedy/beam search?). The Eq.(3) inconsistency further reduces reproducibility confidence.
- **Impact on Practice/Understanding**: The SciPG dataset is a genuine resource that could enable future work. The end-to-end framework provides a useful baseline. However, the absolute layout quality (25% overlap, low aesthetic scores) suggests the method is not yet deployment-ready.

### Proposed Research Experiments (P0/P1/P2)

| ID | Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|----|-------------|------------|---------------|-------------------|---------|------------------|-----------|---------------|
| P0-E1 | C2: Extractor quality | Per-element BCE improves ImgR over softmax | Retrain MDE with BCE loss (Eq.3 fix) | Current MDE (softmax) | ImgR, ImgP, ROUGE | ImgR improves ≥3 points | 1 GPU-day | Validates the main formula fix |
| P0-E2 | C1: Alignment quality | Manual verification of alignment accuracy | Sample 200 sentence + 200 image pairs; compute precision/recall | δ=0.8 baseline | Accuracy, Precision, Recall | Sentence accuracy >85%, Image accuracy >80% | 1-2 person-days | Validates dataset quality |
| P1-E3 | C3: Adaptive vs RMT memory | Ablate with exact RMT (no cross-attention update) | Replace Eq.(7) with direct copy: H_mem_{τ+1} = H_hat_mem_τ | Adaptive, None | Overlap, Coverage | Adaptive > RMT by >3% overlap reduction | 1 GPU-day | Isolates adaptive contribution |
| P1-E4 | C2: Layout quality | Post-processing overlap reduction | Add non-maximum suppression or iterative refinement after IG | IG alone | Overlap, Coverage, Val | Overlap <15% with Val >0.95 | 1-2 GPU-days | Addresses the main empirical weakness |
| P2-E5 | All: Statistical reliability | Multi-seed variance reporting | Run all experiments with 3 random seeds | Single seed | All metrics + std | std reported for all tables | 3× compute | Standard requirement for top venues |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score: 5.5 / 10**

**Rationale**: The paper addresses a meaningful underexplored task and contributes a large-scale dataset that fills a clear resource gap. The extractor-generator framework is logically designed and modular. However, several issues prevent a higher score: (1) a critical formula-level inconsistency in the extraction loss (Eq.3) undermines confidence in the reported results; (2) the layout Overlap metric is ambiguously interpreted, and the absolute layout quality is substantially below human-level (5× ground-truth overlap); (3) the dataset alignment quality — which underpins all supervised training — is unvalidated; (4) novelty claims cannot be verified without external literature comparison (Retrieval-Disabled Mode). The paper's research value is primarily in the dataset and task formulation rather than in technical novelty of the method components.

**Post-Revision Target: [6.5, 7.5] / 10**

**Rationale**: If all P0 and P1 issues are addressed (Eq.3 correction, overlap clarification, alignment validation, contribution reframing, conclusion strengthening, multi-seed experiments), the paper could reach 6.5-7.5. The dataset contribution is solid and would remain valuable. The main technical contribution (interactive generator + adaptive memory) would benefit from a cleaner ablation isolating the adaptive component from the RMT baseline. The upper bound (7.5) assumes the corrected experiments confirm the reported improvements and external literature verification supports the novelty claims.