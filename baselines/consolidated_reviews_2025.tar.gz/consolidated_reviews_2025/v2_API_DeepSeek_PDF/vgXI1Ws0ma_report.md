## Summary
# Final Review Report

## Summary

This paper (accepted at ICLR 2025) proposes Empowerment through Causal Learning (ECL), a framework that integrates empowerment gain with causal structure learning in Model-Based Reinforcement Learning (MBRL). The core idea is to close the loop between causal structure discovery and exploration: the learned causal mask guides the agent toward controllable state dimensions via empowerment maximization, and the data collected during exploration is used to refine the causal mask. ECL consists of three steps: (1) learning a causal dynamics model with a causal mask and a reward model, (2) alternating empowerment-driven exploration and causal mask optimization, and (3) downstream policy learning with a curiosity-based intrinsic reward to prevent overfitting.

The paper evaluates ECL with both constraint-based (ECL-Con) and score-based (ECL-Sco) causal discovery methods across six environments, including both state-based (Chemical, Physical, Manipulation) and pixel-based tasks (Modified Cartpole, Robodesk, DMC). Results show improved causal graph accuracy (F1 scores 0.93-1.00) and episodic rewards compared to baselines CDL, REG, GRADER, GNN, and MLP, with the largest gains in complex manipulation tasks.

**Strengths:** The framework is method-agnostic, the iterative causal-empowerment loop is well-motivated, and the evaluation is reasonably broad (6 environments, 6 baselines). The curiosity reward component is a practical contribution that addresses the risk of causal overfitting.

**Core weaknesses (detailed in sections below):** (1) Several mathematical definitions have notational ambiguities (Eq. 3's conditioning on mask M, Eq. 5's unbound index i in L^Con_causal). (2) The derivation from Eq. 7 to Eq. 10 drops two entropy terms with insufficient justification. (3) The curiosity reward Eq. (11) relies on the ground-truth dynamics P_env, which is inaccessible in MBRL, and its approximation is not discussed. (4) Experimental comparisons lack error bars on key bar charts (Fig. 3) and the 4-seed setup may not support the strength of the "outperforms" claims. (5) The introduction's gap statement ("passively rely") is vague, and contribution bullet items mix conceptual novelty with empirical results. (6) Related work reads as separate literature summaries without explicit comparison to the closest baselines.

## Strengths
1. **Well-motivated iterative loop.** The central idea—closing the loop between causal structure learning and empowerment-driven exploration—is conceptually sound and addresses a genuine limitation in prior causal MBRL work, where causal graphs are learned once and never updated during exploration.

2. **Method-agnostic design.** ECL can accommodate both constraint-based (CIT) and score-based (sparse regularization) causal discovery methods. This increases the framework's applicability and allows researchers to plug in different causal discovery algorithms.

3. **Broad evaluation scope.** The paper evaluates across 6 environments spanning state-based (Chemical, Physical, Manipulation) and pixel-based (Cartpole, Robodesk, DMC) tasks. The inclusion of OOD evaluation and pixel-based tasks with distractors strengthens the empirical contribution.

4. **Curiosity reward for robustness.** The addition of an intrinsic curiosity reward (Eq. 11-12) that balances causal and dense dynamics predictions is a practical contribution that addresses the risk of overfitting to an imperfect causal model.

5. **Competitive causal discovery results.** On the chemical environments, ECL achieves F1 scores of 0.93-1.00 for causal graph discovery, with consistent improvements over CDL and REG baselines, especially on the more complex "Full" and "Collider" causal structures.

## Weaknesses
1. **Mathematical notation ambiguity (core method).** The paper's formalism suffers from several ambiguities that undermine reproducibility. (a) Eq. (3) conditions mutual information on the causal mask $M$, which is a matrix, not a random variable — the intended meaning is unclear. (b) The constraint-based objective $L^{Con}_{causal}$ in Eq. (5) uses an unbound index $i$ inside the summation, making it impossible to implement as written. These are not minor typos; they affect the core definitions of the method.

2. **Empowerment derivation shortcut without justification.** The derivation from Eq. (7) to Eq. (10) drops two conditional entropy terms ($H(s_{t+1}|s_t; M) - H(s_{t+1}|s_t)$) and optimizes only the KL term. The paper states "For simplicity" without analyzing whether the dropped terms are constant with respect to $\pi_e$ or whether they affect the optimal policy. This creates a gap between the stated theoretical objective and the actual implemented optimization.

3. **Curiosity reward depends on inaccessible ground truth.** Eq. (11) uses $P_{env}$ (the ground truth environment dynamics) to compute the curiosity bonus. In MBRL, $P_{env}$ is unknown — this is the entire motivation for learning a dynamics model. The paper does not clarify how $P_{env}$ is obtained in practice (buffered empirical distribution? separate estimator?) nor does it analyze the bias introduced by this approximation.

4. **Statistical rigor of experimental claims.** Several empirical claims rely on small margins (e.g., Chemical Chain: ECL-Con=38 vs GNN=36, a ~5% relative improvement) without error bars in Fig. 3, which uses bar charts without variance. The paper uses only 4 random seeds and does not report significance tests. This weakens the "outperforms" narrative.

5. **Fairness of baseline comparisons.** The paper reuses the same causal discovery methods (CDL, REG) as building blocks within ECL, then compares ECL against those same methods "combined" with the ECL pipeline. It is unclear whether the improvement comes from the ECL loop or from unequal tuning (e.g., ECL uses 32M training steps for Manipulation vs presumably less for CDL/REG). A fairness statement is missing.

6. **Novelty positioning is uncertain (deferred).** Due to Retrieval-Disabled Mode for this run, we cannot verify whether key first-mover claims ("pioneers the integration of empowerment with causal reasoning") are valid against the existing literature. The paper cites CDL, GRADER, REG, and empowerment methods (Bharadhwaj et al., Eysenbach et al.) but does not fully articulate residual novelty space. External literature verification is needed before accepting the novelty claims at face value.

7. **Related work lacks explicit differentiation.** The two paragraphs (Causal MBRL, Empowerment in RL) read as separate literature summaries without directly stating how ECL differs from the closest baselines (CDL, empowerment-by-MI methods). The most critical comparison — that CDL does not update its causal graph during exploration — is stated implicitly rather than as a clear differentiating statement.

## Key Issues
**Issue 1 (Severity: Major)** — Notational ambiguity in core mathematical definitions. Eq. (3)'s conditioning on $M$ and Eq. (5)'s unbound index $i$ in $L^{Con}_{causal}$ both affect the reproducibility of the method. These should be corrected before any re-submission.

**Issue 2 (Severity: Major)** — The empowerment-driven exploration objective (Eq. 7→10) drops two entropy terms and optimizes only the KL term. The paper labels this as "for simplicity" without analyzing whether the simplification preserves the optimal policy. If the entropy terms depend on $\pi_e$, the optimized policy may differ materially from the stated objective.

**Issue 3 (Severity: Major)** — The curiosity reward (Eq. 11) depends on ground-truth dynamics $P_{env}$, which is not available in MBRL. Without clarifying how $P_{env}$ is approximated and what bias this introduces, the curiosity reward's effectiveness cannot be independently assessed.

**Issue 4 (Severity: Major)** — Fig. 3 reports bar charts without confidence intervals. With only 4 random seeds and small margins (2-3 points on ~36-point baselines), the statistical reliability of the "outperforms" claims is unverified. The paper should report per-seed variance or add significance tests.

**Issue 5 (Severity: Major)** — The experiment section does not include a fairness statement regarding baseline tuning. Since ECL uses the same causal discovery methods as CDL/REG but within an optimized pipeline, the reported gains could partially reflect unequal tuning effort rather than the novel mechanism.

**Issue 6 (Severity: Medium)** — The introduction's gap statement ("passively rely on pre-existing or learned causal structures") is too vague to be falsifiable. The precise deficiency (failure to update the causal graph during exploration) is stated later but not foregrounded.

**Issue 7 (Severity: Medium)** — The related work section does not provide explicit "difference vs this paper" statements for the closest baselines (CDL, empowerment-by-MI methods).

**Issue 8 (Severity: Medium)** — The conclusion uses subjective wording ("remarkable performance") instead of bounded, evidence-anchored claims. Limitations are placed in a separate subsection rather than integrated into the conclusion.

## Actionable Suggestions
### S1 (Must): Fix mathematical notation
- **Eq. (3):** Replace $I(s_{t+1}; a_t | M)$ with $I(s_{t+1}; a_t | s_t; M)$ where $M$ indexes the causal dynamics model used to compute the distribution: $E := \max_{\pi} I(s_{t+1}; a_t | s_t; M)$, with the clarification that $M$ determines which edges are active in the transition model $p(s_{t+1}|s_t, a_t, M)$.
- **Eq. (5) L^Con_causal:** Replace $\log \hat{p}(s^j_{t+1}|\{a_t, s_t \setminus s^i_t\})$ with $\log \hat{p}(s^j_{t+1} | a_t, s_t \setminus s^j_t)$ to fix the index binding. The term should use $j$ consistently.

### S2 (Must): Justify the simplification from Eq. (7) to (10)
- Add a paragraph explaining why the two entropy terms $H(s_{t+1}|s_t; M) - H(s_{t+1}|s_t)$ can be dropped. If they are constant with respect to $\pi_e$, state this explicitly and show the derivation. If they are not, add an ablation experiment comparing the full objective vs. the KL-only optimization.

### S3 (Must): Clarify the curiosity reward's practical implementation
- Replace $P_{env}$ in Eq. (11) with a realistically accessible quantity, e.g., $\hat{P}_{buf}$ (empirical transition distribution from the replay buffer) or $P_{\phi_c}^{dense}$ (the dense dynamics model without causal mask). Add a sentence: "In practice, we approximate $P_{env}$ using the empirical transition distribution stored in the replay buffer with kernel density smoothing."

### S4 (Must): Add statistical rigor to experimental results
- Replace Fig. 3 bar charts with plots showing mean $\pm$ std over 4 seeds. Add a brief statistical statement: "Due to the limited number of seeds (4), these results should be interpreted as preliminary evidence rather than confirmed statistical superiority."

### S5 (Must): Add baseline fairness statement
- Add a sentence in Section 5: "All baselines were evaluated using their original hyperparameters on the same training steps and seeds. No additional tuning was performed for ECL's benefit beyond the framework's own hyperparameters (mask regularization coefficient, curiosity weight $\lambda$)."

### S6 (Nice-to-have): Strengthen related-work differentiation
- Restructure the related work into comparison axes: (1) whether the causal graph is updated during exploration, (2) whether empowerment is used, (3) whether the exploration policy is causally informed. Clearly state ECL's position on each axis.

### S7 (Nice-to-have): Revise conclusion
- Replace "remarkable performance" with specific, bounded outcomes: "ECL-Con achieved higher episodic rewards than CDL on all tested environments (Chemical: +2-3, Manipulation Stack: +4, Physical: +6) and higher causal graph F1 (+0.03-0.08 on Chemical Full). These gains were consistent across 4 seeds but were not tested for statistical significance."

### S8 (Nice-to-have): Restructure introduction gap
- Replace "passively rely" (lines 41-42) with a concrete deficiency statement: "Most prior causal MBRL methods learn a causal graph once from pre-collected data and do not update it based on exploration-driven data collection. This paper closes that gap."

## Storyline Options + Writing Outlines
### Current Storyline Diagnosis

The current introduction uses three paragraphs:
- **P1:** MBRL + causal structures context, then a gap statement ("passively rely").
- **P2:** Empowerment motivation, iterative loop intuition, motivating example.
- **P3:** Proposed framework (ECL) overview + contribution bullets.

**Problem:** P1's gap statement is too vague to be actionable. P2 introduces empowerment but does not explicitly state why empowerment is the right tool for active causal exploration. The causal chain "causal structure → empowerment → exploration → better causal structure" is described in P2 but the logical link (why empowerment specifically, not other exploration objectives) is not justified.

### Recommended Storyline (Option A: Best)

**Sentence-by-sentence arc:**

**P1 (Stakes + Gap):** 
- S1: "Model-based RL (MBRL) improves sample efficiency by learning predictive dynamics models, but these models often capture spurious correlations that hurt generalization."
- S2: "Recent work incorporates causal structures into MBRL to address this, learning directed acyclic graphs over state and action variables."
- S3: "However, existing causal MBRL methods learn a causal structure once from a fixed dataset and do not revise it using actively collected exploration data."
- S4: "This one-shot approach limits both the accuracy of the learned causal graph (since the training data may not cover informative regions) and the agent's ability to discover which state dimensions are truly controllable."

**P2 (Solution intuition + Empowerment justification):**
- S1: "We hypothesize that an agent can close this loop by using its causal structure to guide exploration, and then refining the structure with the data collected through that exploration."
- S2: "Empowerment — the mutual information between actions and future states — is a natural objective for this purpose: it measures how much control the agent has over the environment."
- S3: "By maximizing empowerment under the causal mask (which filters out irrelevant dimensions), the agent focuses exploration on controllable state variables."
- S4: "The targeted data collected in this way yields higher-quality causal discovery, which in turn improves empowerment maximization — creating a positive feedback loop."

**P3 (Framework + Contributions):**
- S1: "We operationalize this idea in Empowerment through Causal Learning (ECL), a three-step framework: (1) learn a causal dynamics model, (2) alternate empowerment-driven exploration with causal mask refinement, (3) learn the downstream task policy with a curiosity bonus."
- S2-4: (explicit contribution bullets from the Mentor Revised Version in earlier annotations)

### Abstract Outline (Complete)

**S1 (Problem):** "In Model-Based Reinforcement Learning (MBRL), causal structure learning can improve generalization by identifying relevant state-action dependencies."
**S2 (Gap):** "However, existing methods learn a causal graph once from pre-collected data and do not update it during exploration, limiting both graph accuracy and policy efficiency."
**S3 (Method):** "We propose Empowerment through Causal Learning (ECL), which closes this loop by using the learned causal mask to guide empowerment-driven exploration, then refining the mask with exploration data."
**S4 (Components):** "ECL combines a causal dynamics model, an empowerment gain objective (equipped with a curiosity-based regularization term), and alternates between exploration and causal optimization."
**S5 (Results, bounded):** "Across six environments, ECL with constraint-based discovery improved causal graph F1 by 3-8 points over CDL and achieved higher episodic rewards, with the largest gains in complex manipulation tasks."

### Alternative Storyline (Option B: Results-first)

Lead with the surprising finding first: "Standard empowerment in dense dynamics models often focuses on all state dimensions equally. By restricting the empowerment objective to the learned causal mask, the agent can focus on controllable dimensions. We show that this masked empowerment gain improves both causal discovery accuracy (F1 +0.03-0.08) and sample efficiency (2-3x faster convergence in manipulation tasks) compared to prior causal MBRL methods." This is more direct but requires strong empirical results up front.

## Priority Revision Plan
### P0 (Publication-critical — must fix before next submission)

| Priority | Issue | Effort | Impact | Concrete Action |
|----------|-------|--------|--------|----------------|
| P0 | Notation ambiguity in Eq. (3) and Eq. (5) | Low | High (reproducibility) | Fix index binding in $L^{Con}_{causal}$; clarify $M$ conditioning in Eq. (3) |
| P0 | Missing justification for Eq. (7)→(10) simplification | Medium | High (theoretical soundness) | Add derivation or ablation comparing full vs KL-only objective |
| P0 | Curiosity reward $P_{env}$ ambiguity | Low | High (reproducibility) | Replace $P_{env}$ with a concretely accessible estimator |
| P0 | Missing error bars in Fig. 3 | Medium | High (statistical credibility) | Replace bars with box/variance plots or add table with per-seed results |

### P1 (High priority — should fix)

| Priority | Issue | Effort | Impact | Concrete Action |
|----------|-------|--------|--------|----------------|
| P1 | Baseline fairness statement missing | Low | Medium (trust in comparisons) | Add explicit statement about tuning protocol |
| P1 | Vague introduction gap | Low | Medium (narrative clarity) | Replace "passively rely" with concrete deficiency (see S8) |
| P1 | Conclusion uses hype language | Low | Medium (scientific tone) | Replace "remarkable" with bounded evidence summary |
| P1 | Related work lacks explicit differentiation | Low | Medium (novelty positioning) | Restructure as comparison table or axis-based paragraphs |

### P2 (Nice-to-have — quality improvement)

| Priority | Issue | Effort | Impact | Concrete Action |
|----------|-------|--------|--------|----------------|
| P2 | Motivating example in Fig. 1 | Low | Low (illustration) | Add explicit caption linking example rows to empowerment gain values |
| P2 | Missing hyperparameter sensitivity for $\lambda$ | Medium | Medium | Add ablation or sensitivity plot for curiosity reward weight |
| P2 | OOD evaluation scope | Medium | Medium | Add more diverse OOD shifts (e.g., environment color/texture change) |

### Expected Impact After Fixes

If P0 items are fully addressed, reproducibility improves from "ambiguous" to "unambiguous" for the core method. If P1 items are addressed, the narrative clarity and novelty positioning improve substantially. The paper could move from borderline-acceptable to solid acceptance at a top ML conference after these revisions.

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective/Hypothesis | Setup (Data/Split/Protocol/Baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|--------|---------------------|---------------------------------------|---------|--------------|-----------------|-------------------|
| E1 | Task learning: does ECL achieve higher episodic reward? | 3 environments (Chemical, Physical, Manipulation); 6 baselines (CDL, REG, GNN, MLP, GRADER, IFactor) | Episodic reward mean | ECL-Con highest reward in 3/3 environments (Fig. 3) | C3 (performance claim) | No error bars in Fig. 3; 4 seeds only |
| E2 | Sample efficiency: does ECL learn faster? | Collider + Manipulation Reach tasks; comparison vs CDL | Success rate | ECL converges faster (Fig. 5) | C3 | Only 2 tasks; no quantitative speedup measure |
| E3 | Causal graph discovery accuracy | 3 Chemical environments; 5 metrics; comparison vs CDL and REG | Accuracy, Recall, Precision, F1, ROC AUC | ECL achieves 0.93-1.00 F1 (Table 1) | C1 (implicit) | Metrics near ceiling; limited to simple graphs |
| E4 | Future state prediction (ID and OOD) | 4 environments; 1-step prediction on 5K transitions | Mean accuracy / log-likelihood | ECL matches GNN/MLP in ID, outperforms in OOD (Fig. 7) | C1, C3 | OOD shift is small (position change only) |
| E5 | Pixel-based task learning | Robodesk, compared with IFactor | Average return; visualization | ECL > IFactor (Fig. 8) | C3 | Only 1 pixel environment shown with comparative curve |
| E6 | Ablation: combining Steps 1&2 | Variants of ECL-Con/ECL-Sco with/without Step 2 | Episodic reward | See Appendix D.8 | C1 | Reported only in appendix |
| E7 | Ablation: curiosity reward variants | With/without curiosity, causality, task-only reward | Episodic reward | Curiosity reward helps performance (Appendix D.8) | C2 | Only reported in appendix |

### Research-Theme Gap Diagnosis

- **New knowledge:** The core conceptual contribution (closing the causal-empowerment loop) is well-motivated, but the novelty verdict cannot be fully established without external literature verification (deferred).
- **Reproducibility:** At risk due to notation ambiguities in Eq. (3) and Eq. (5), and the unclarified $P_{env}$ approximation in Eq. (11).
- **Impact on practice:** Moderate — the method-agnostic design is a practical strength, but the reported gains are small and statistical reliability is unverified.

### Proposed Research Experiments (P0/P1/P2)

**P0.1 — Full vs KL-only empowerment objective ablation**
- Target claim: The KL-only optimization (Eq. 10) approximates the full objective (Eq. 7) well.
- Hypothesis: Entropy terms are approximately constant under $\pi_e$ for the tested environments.
- Design: Compare episodic reward under (a) full objective, (b) KL-only, (c) random exploration baseline.
- Controls: Same seeds, same training steps, same CEM planner.
- Success criterion: No statistically significant difference between (a) and (b).
- Expected gain: Clarifies whether the theoretical shortcut is benign.

**P0.2 — Statistical validation of main results**
- Target claim: ECL outperforms CDL/REG.
- Design: Run 10 seeds instead of 4 on the Chemical (Full) and Manipulation (Stack) tasks. Report mean $\pm$ 95% CI.
- Controls: Identical hyperparameters across seeds.
- Success criterion: Non-overlapping CIs or $p < 0.05$ via paired bootstrap test.
- Expected gain: Determines whether reported margins are real or noise-driven.

**P1.1 — Hyperparameter sensitivity for $\lambda$ (curiosity weight)**
- Target claim: $\lambda$ balances causal vs. dense model influence.
- Design: Grid search $\lambda \in \{0, 0.01, 0.1, 0.5, 1.0, 5.0\}$ on Chemical (Full).
- Metric: Episodic reward + causal graph F1.
- Expected gain: Provides practical guidance for $\lambda$ selection.

**P1.2 — Stronger OOD generalization test**
- Target claim: Causal structure improves OOD generalization.
- Design: Beyond position changes, test (a) color/texture randomization, (b) modified physics parameters (e.g., friction, gravity).
- Baseline: Compare ECL vs CDL vs GNN on all OOD variants.
- Expected gain: Strengthens the generalization and robustness claims.

### ASCII Diagram — Experiment Upgrade Plan

```text
[Stage 0: Current evidence base]
  ├── Task learning (4 seeds, no CI): tentative gains
  ├── Causal graph F1 (near ceiling): modest differentiation
  └── OOD prediction (small shift): moderate

[Stage 1: P0 experiments — validity assurance]
  ├── Full vs KL-only ablation -> resolves theoretical gap
  ├── 10-seed repeat + CI -> establishes statistical reliability
  └── P_env approximation clarification -> fixes reproducibility

[Stage 2: P1 experiments — impact enhancement]
  ├── Lambda sensitivity -> practical guidance
  └── Stronger OOD tests -> robustness claim support

[Stage 3: P2 experiments — scope extension]
  └── More diverse OOD shifts, real-world-like distractors
```

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
### Final Score: **6/10**

**Rationale:** The paper has a well-motivated core idea and reasonably broad evaluation, but it is held back by several reproducible-significant weaknesses:

- **Research value (primary dimension): 6/10.** The conceptual contribution (closing the causal-empowerment loop) is genuine and the method-agnostic design is practical, but the novelty cannot be fully confirmed without external literature verification (deferred). The iterative loop is the main conceptual advance, but the paper does not demonstrate conclusively that the improvement comes from the loop rather than from unequal tuning or modeling capacity.

- **Validity/soundness: 5/10.** Core mathematical definitions (Eq. 3, Eq. 5, Eq. 11) have ambiguities that affect reproducibility. The derivation from Eq. 7 to Eq. 10 drops terms without justification. The curiosity reward depends on an inaccessible $P_{env}$.

- **Empirical rigor: 5/10.** Fig. 3 lacks error bars. Only 4 seeds are used. Baseline tuning parity is not explicitly stated. Statistical significance is not assessed.

- **Writing/clarity: 6/10.** The introduction gap is vague, contribution bullets mix novelty and performance, related work lacks explicit differentiation, and the conclusion uses hype wording.

### Post-Revision Target: **[6, 7]/10**

If all P0 and P1 issues are resolved (notation fixes, Eq. 10 justification, $P_{env}$ clarification, error bars added, baseline fairness statement, narrative restructuring), the paper could reach a solid 7/10. Further gains would require stronger empirical validation (10+ seeds, broader OOD tests, statistical tests) and external novelty verification, which could push it to 8/10. Reaching above 8/10 would require evidence that the closed-loop mechanism provides a step-change improvement over CDL (e.g., >20% relative gain on a complex benchmark with full statistical rigor).