## Summary
This paper investigates the subgraph-counting capabilities of message-passing GNNs beyond worst-case analysis. The key idea is to identify sufficient conditions under which standard GNNs (without architectural modifications) can count substructures in real-world graphs. The authors: (1) introduce **(\u2113,k)-identifiability**, showing that if depth-\u2113 universal covers uniquely determine radius-k ego-nets, GNNs with O(\u03b7\u00b2\u2113) parameters can realize any k-local function including subgraph counting; (2) propose **TREE-COLSI** and **TREE-COL LIH**, dynamic programming algorithms inspired by color-coding for subtree isomorphism under "quite-colorful" and "parent-colorful" conditions, proving GNNs can simulate them; (3) validate empirically on 7 molecular datasets that the sufficient conditions approximately hold in practice.

The paper is accepted at ICLR 2025. The theoretical analysis is rigorous and the framework (moving beyond worst-case to data-dependent expressivity) is a valuable perspective. However, several significant gaps between theory and practice are not adequately addressed: the node-level vs. graph-level identifiability gap, the astronomical O(\u03b7\u00b2) parameter bounds for realistic \u03b7 values, the bounded-degree assumption not validated in experiments, the non-learnability of hand-constructed weights, and overclaims in the conclusion. Novelty/comparison conclusions are deferred (Retrieval-Disabled Mode active).

## Strengths
1. **Important problem framing**: The paper correctly identifies that worst-case expressivity analysis of GNNs (Chen et al., 2020; Zhang et al., 2024) may be overly pessimistic for practical applications. Moving beyond worst-case to data-dependent sufficient conditions is a valuable and under-explored direction.

2. **Rigorous theoretical framework**: The introduction of (\u2113,k)-identifiability (\u2113-depth universal cover determines k-radius ego-net) provides a clean mathematical formalism for analyzing when GNNs can realize local functions. The connection to universal covers, WL colors, and sample complexity via pseudo-dimension is well-executed.

3. **Algorithmic alignment contribution**: TREE-COLSI and the proof that GNNs can simulate it (Theorem 5) are technically sound and provide a principled connection between color-coding dynamic programs and message-passing architectures. The design choice to replace random colors with WL colors is a practical adaptation that makes the algorithm simulable by GNNs.

4. **Empirical validation of theoretical conditions**: Tables 2 and 3 provide convincing evidence that WL distinguishes nearly all graphs in molecular benchmarks and that (\u2113,k)-identifiability holds for most nodes. This empirical grounding is a significant strength.

5. **Honest self-critique of Proposition 1**: The paper transparently acknowledges the limitations of the trivial universal approximation argument (exponential parameters, memorization rather than learning), setting up the motivation for the more nuanced analysis that follows.

6. **Self-contained exposition**: The Preliminaries section (Section 2) provides all necessary background (WL algorithm, universal covers, GNN definitions), making the paper accessible to readers with basic graph learning knowledge.

## Weaknesses
1. **Node-level vs. graph-level identifiability gap**: Theorem 2 and Corollary 1 require that *all* nodes be (\u2113,k)-identifiable for GNNs to exactly realize k-local functions. However, Table 3 shows that the fraction of graphs where ALL nodes are (\u2113,k)-identifiable is substantially lower than the node-level fraction. At k=2, \u2113=4 on ogbg-molpcba, only 86.1% of graphs have all nodes identifiable, while 98.9% of individual nodes are identifiable. The paper's narrative emphasis on "more than 97%" (node-level) overstates the practical guarantee.

2. **Astronomical parameter bounds**: The O(\u03b7\u00b2\u2113) parameter count in Theorem 2 depends on \u03b7, the number of distinct truncated universal covers. From Table 6, \u03b7 at \u2113=3 ranges from 1,308 (Peptides-func) to 913,960 (PCQM-Contact). At \u03b7=913,960, \u03b7\u00b2 is 8.35\u00d710\u00b9\u00b9, far beyond any practical model. The paper does not discuss at what \u03b7 values the bound becomes meaningful.

3. **Bounded-degree assumption unvalidated**: Theorem 5 assumes bounded degree (\u0394), which critically affects the complexity bound (Lemma 5 shows exponential dependence on \u0394). The maximum degree is not reported in Table 5 (which only shows average degrees), and no experiment verifies this assumption.

4. **Existence proof vs. learnability**: The constructions for Theorem 2 and Theorem 5 use hand-crafted weight assignments (one-hot encodings, tri/lsig functions) that are not guaranteed to be learnable via gradient descent. The gap between existence of a weight assignment and practical learnability is not discussed.

5. **Conclusion overclaim**: The statement "more expressivity in GNN architectures is almost never needed" and "having ruled out expressivity" go beyond what the evidence supports. The paper only tests molecular benchmarks, does not compare against any expressive architectures, and acknowledges the question is still open. This strong claim could mislead readers.

6. **Restrictive quite-colorful condition**: Definition 3 requires strict color separation between nodes at distance \u22653. For Peptides-func (6 node labels), Figure 6 shows 0% quite-colorful maps for some patterns at any l. This counterexample is relegated to the appendix but represents a significant practical limitation.

7. **Missing novelty/comparison**: Due to Retrieval-Disabled Mode, novelty and comparison with related work cannot be externally verified. This is a self-imposed limitation of the current review run, not a paper flaw, but means novelty conclusions are deferred.

## Key Issues
### Issue 1 (Critical): Node-level vs. Graph-Level (\u2113,k)-Identifiability Gap
**Location**: Page 9 - Experimental Evaluation \u00a76.1  
**Evidence**: Table 3 shows brackets (graph-level all-nodes identifiability) are significantly lower than main node-level fractions. For k=2, \u2113=4 on PCQM-Contact: 97.3% nodes vs 80.5% graphs.  
**Impact**: Theorem 2 requires the entire graph set to be (\u2113,k)-identifiable. The paper's claim that conditions "hold in practice" relies on node-level statistics, but the sufficient condition requires graph-level satisfaction. This gap undermines the strength of the empirical validation.

### Issue 2 (Major): O(\u03b7\u00b2) Parameter Bound Impracticality
**Location**: Page 6 - Theorem 2 and Corollary 1; Page 25 - Table 6  
**Evidence**: \u03b7 at \u2113=3 ranges 1,308\u2013913,960 across datasets. The bound O(\u03b7\u00b2\u2113) at \u03b7=913,960 gives ~8.35\u00d710\u00b9\u00b9 parameters\u2014clearly impractical.  
**Impact**: The theoretical parameter bound is presented as a strength ("independent of maximum graph size n"), but for realistic datasets it exceeds practical limits by many orders of magnitude. The paper should discuss the practical range where the bound is meaningful.

### Issue 3 (Major): Conclusion Overclaim on Expressivity
**Location**: Page 10 - Discussion and Conclusions  
**Evidence**: "more expressivity in GNN architectures is almost never needed" and "having ruled out expressivity, an interesting research avenue is to investigate the true reasons..."  
**Impact**: The paper only studies molecular graphs, does not compare against expressive architectures, and explicitly states the question remains open. The strong dismissal of expressivity research is not supported and could mislead readers about the scope of findings.

### Issue 4 (Major): Quite-Colorful Condition Limitations
**Location**: Page 8 - Definition 3; Page 26 - Figure 6  
**Evidence**: Peptides-func shows 0% quite-colorful maps for some patterns at any l. The quite-colorful condition requires color separation for nodes at distance \u22653, which may fail in graphs with few node labels.  
**Impact**: The main contribution of Section 5 (TREE-COLSI) only works for quite-colorful maps. When this condition fails completely (as on some Peptides-func patterns), the algorithmic alignment justification does not apply, yet the GNN may still perform well\u2014meaning alignement is not necessary for good performance, weakening the causal claim.

### Issue 5 (Major): Bounded-Degree Assumption Not Validated
**Location**: Page 8 - Theorem 5; Page 25 - Table 5  
**Evidence**: Theorem 5 assumes bounded degree \u0394, which appears in the exponential complexity bound. Table 5 reports only average degrees, not maximum degrees. No validation of bounded-degree assumption is provided.  
**Impact**: The complexity bound for the GNN simulation of TREE-COLSI depends critically on \u0394 (Lemma 5 shows dependence O(\u03b7\u0394+1/\u0394!)). Without reporting maximum degrees, readers cannot assess whether the bound is meaningful for the datasets studied.

## Actionable Suggestions
### S1 (Must): Address the Node-Level vs. Graph-Level Identifiability Gap
**Location**: Page 9 - Section 6.1  
**Problem**: The paper states "more than 97% of the ego-nets centered around nodes can be identified" but Theorem 2 requires all nodes.  
**Action**: 
- Report and discuss the graph-level (all-nodes) identifiability alongside node-level metrics throughout Section 6.1.
- Add an explicit paragraph analyzing why GNNs perform well even when some nodes are not identifiable, exploring whether the theoretical condition is sufficient but not necessary.
- Revise the claim from "conditions hold in practice" to "conditions approximately hold for the majority of cases, with X% of graphs fully satisfying the sufficient condition."

### S2 (Must): Discuss Practical \u03b7 Values
**Location**: Page 6 - Section 4.1 (after Theorem 3)  
**Problem**: The O(\u03b7\u00b2) bound is presented as favorable but realistic \u03b7 values make it astronomical.  
**Action**:
- Add a paragraph after Theorem 3 referencing Table 6 values: "\u03b7 ranges from 76 (Peptides-func, \u2113=1) to 913,960 (PCQM-Contact, \u2113=3). This implies that the parameter bound, while theoretically independent of n, can exceed practical budgets for datasets with high structural diversity. However, the bound is an upper bound, and actual required parameters may be lower."
- Discuss the trade-off: smaller \u2113 reduces \u03b7 but requires more layers to achieve (\u2113,k)-identifiability.

### S3 (Must): Soften Conclusion Overclaim
**Location**: Page 10 - Discussion and Conclusions  
**Problem**: "more expressivity in GNN architectures is almost never needed" and "having ruled out expressivity" are unsupported.  
**Action**:
- Replace with: "Our findings suggest that on molecular benchmarks, expressivity limitations may not be the primary bottleneck for subgraph counting. Understanding the interplay between expressivity, sample complexity, and optimization in these settings remains an important direction for future work."
- Add scope qualification: "The conclusions are based on molecular datasets; extending this analysis to other graph types is necessary."

### S4 (Must): Validate Bounded-Degree Assumption
**Location**: Page 8 - Section 5.2; Page 25 - Table 5  
**Problem**: Theorem 5 assumes bounded degree but maximum degrees are not reported.  
**Action**:
- Add maximum degree \u0394_max to Table 5 alongside average degrees.
- In Section 5.2, add: "For the molecular datasets studied, the maximum degree ranges from X to Y, making the bounded-degree assumption realistic and the complexity bounds O(\u03b7\u0394+1) manageable for small \u0394."
- If \u0394 is large for some datasets, discuss the implications for Lemma 5's bound.

### S5 (Nice-to-have): Validate Non-Learnability Gap
**Location**: Throughout Sections 4-5  
**Problem**: The weight constructions are hand-crafted, not learned.  
**Action**:
- Add one sentence to Section 4 after Theorem 2: "We emphasize that this is an existence proof; whether the required weights can be learned via gradient descent in practical training settings is a separate question that merits further investigation."
- In Section 5.2, after the tri/lsig discussion: "The tri and lsig functions can be simulated with ReLU, suggesting the required computations are within the expressible function class of standard GNNs, though optimization may not recover these exact weights."

### S6 (Nice-to-have): Move Peptides-func Analysis to Main Text
**Location**: Page 26 - Figure 6 (appendix)  
**Problem**: The Peptides-func counterexample (0% quite-colorful maps for some patterns) is only discussed in the appendix.  
**Action**:
- Add 2-3 sentences in Section 6.1 discussing the Peptides-func case: "Notably, for Peptides-func, some patterns achieve 0% quite-colorful subgraph isomorphisms even after many WL iterations, likely due to the small number of node labels (6). Understanding how GNNs still achieve reasonable accuracy on these patterns remains an open question."

### S7 (Nice-to-have): Improve Abstract Precision
**Location**: Page 1 - Abstract  
**Problem**: "Several real-world datasets" and "quite accurately" are vague.  
**Action**:
- Replace "several real-world datasets" with "seven molecular benchmark datasets."
- Replace "quite accurately" with a bounded claim: "achieving AUC above 0.85 and nMAE below 0.05 for most tested patterns."

## Storyline Options + Writing Outlines
### Current Storyline Analysis

The current introduction follows this structure:
- P1: GNNs are powerful but WL-limited.
- Table 1 + P2: Despite limits, GNNs count well on molecular data (empirical surprise).
- P3: More expressive architectures exist but are expensive.
- P4: Our work provides theory to explain this.
- Related Work (1.1): Literature list.

**Strengths**: The empirical motivation (Table 1) effectively creates curiosity.  
**Weaknesses**: 
- The Table 1 intrusion breaks narrative flow.
- The "more expressive architectures" paragraph (P3) arrives before the gap is fully established.
- The transition from "GNNs are limited" to "but they work anyway" lacks a clear research question articulation.

### Recommended Storyline (Candidate A)
**Abstract Outline (4-5 sentences):**
- S1 (Problem): "Message-passing GNNs cannot count arbitrary subgraphs in the worst case."
- S2 (Observation): "Yet on molecular benchmarks, simple GNNs achieve surprising accuracy."
- S3 (Gap): "Existing theory only addresses worst-case settings, leaving this practical success unexplained."
- S4 (Method): "We introduce (\u2113,k)-identifiability and quite-colorful subtree isomorphism, deriving sufficient conditions for GNNs to count subgraphs sample-efficiently."
- S5 (Result): "On seven molecular datasets, we verify that over 97% of nodes satisfy these conditions, providing the first theory-practice bridge for GNN subgraph counting."

**Introduction Outline (paragraph-by-paragraph):**
- P1 (Stakes): "Subgraph counting is critical for molecular property prediction. GNNs are the standard tool but have known expressivity limits deriving from the 1-WL algorithm."
- P2 (Gap): "Chen et al. (2020) proved GNNs cannot count arbitrary subgraphs in worst-case instances. However, these worst-case constructions rarely occur in real data."
- P3 (Surprise): "Table 1 shows standard GNNs achieve AUC > 0.85 on subgraph counting across 7 molecular datasets. This contradicts the pessimistic worst-case view."
- P4 (Question): "When and why can GNNs count subgraphs despite theoretical impossibility? This paper provides the first systematic answer."
- P5 (Contributions): Explicit numbered list with quantitative anchors.
- P6 (Roadmap): "Section 2 provides preliminaries. Sections 3-4 establish conditions for universal approximation on local functions. Section 5 develops algorithmically-aligned DP. Section 6 validates conditions empirically."

### Alternative Storyline (Candidate B - Theory-First)
- P1: Formal definition of subgraph counting as a promise problem on restricted graph sets.
- P2: Proposition 1 and its limitations (too many parameters).
- P3: Key insight - subgraph counting is k-local, reducing complexity.
- P4: (\u2113,k)-identifiability as the right condition.
- P5: Extension to tree patterns via algorithmic alignment.
- P6: Empirical validation.

**Recommendation**: Use Candidate A for submission. Candidate B is more natural for a theory journal but less engaging for ICLR/ML audience. The empirical surprise framing creates stronger motivation.

### Paragraph-by-Paragraph Revision Targets

**Abstract**: Replace vague "several real-world datasets" with "seven molecular benchmarks." Replace "sample-efficiently learn" with explicit reference to (\u2113,k)-identifiability.

**Introduction P1**: Add a concrete example of why subgraph counting matters early. Replace "significant empirical success" with a specific domain example.

**Introduction P2 (contribution list)**: Add quantitative anchors to each contribution.

**Conclusion**: Remove the speculative paragraph about "true reasons why several GNN architectures... show better performance." Replace with bounded limitations statement.

## Priority Revision Plan
### P0 (Critical - Must Fix Before Resubmission)

| Priority | Issue | Action | Expected Gain |
|----------|-------|--------|---------------|
| P0 | Node-level vs. graph-level identifiability gap (Key Issue #1) | Revise \u00a76.1 to report both metrics; add analysis paragraph on the gap | Prevents overclaim; increases credibility |
| P0 | Conclusion overclaim on expressivity (Key Issue #3) | Replace strong dismissal with measured statement (S3) | Preserves reputation; avoids reviewer pushback |
| P0 | Bounded-degree assumption not validated (Key Issue #5) | Add max degree to Table 5; discuss in \u00a75.2 | Makes theoretical bounds verifiable |

### P1 (Major - Should Fix)

| Priority | Issue | Action | Expected Gain |
|----------|-------|--------|---------------|
| P1 | O(\u03b7\u00b2) bound impracticality not discussed (Key Issue #2) | Add discussion paragraph after Theorem 3 | Manages reader expectations |
| P1 | Quite-colorful condition limitations (Key Issue #4) | Move Peptides-func analysis to main text | Honest disclosure of limitations |
| P1 | Abstract precision (S7) | Bound claims to molecular datasets | Avoids scope overclaim |

### P2 (Nice-to-Have - Strengthens Paper)

| Priority | Issue | Action | Expected Gain |
|----------|-------|--------|---------------|
| P2 | Existence vs. learnability gap (S5) | Add caveat sentences in Sections 4-5 | Intellectual honesty |
| P2 | Related Work reorganization | Restructure around comparison axes (S6 in annotations) | Improved readability |
| P2 | Introduction narrative flow | Move Table 1 to experiments; strengthen P1 motivation | Reader engagement |

### Revision Order (Recommended)
1. **Week 1**: Conclusion rewrite + Abstract revision (P0 items with minimal effort, high impact)
2. **Week 1-2**: \u00a76.1 revision to report graph-level identifiability + add Peptides-func discussion (P0-P1)
3. **Week 2**: Add \u0394_max to Table 5 and bounded-degree discussion (P0)
4. **Week 3**: Add O(\u03b7\u00b2) practicality discussion + existence/learnability caveats (P1-P2)
5. **Week 3-4**: Related Work and Introduction restructuring (P2)

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|--------|---------------------|-------|---------|--------------|-----------------|-------------------|
| E1 (Table 1) | Can GNNs count subgraphs on molecular data? | 7 datasets, GNNK-4 layers, 512-dim, 80/20 split | AUC, nMAE | AUC 0.86-1.00; nMAE 0.000-0.167 | C3 (empirical validation) | Only molecular graphs; single architecture |
| E2 (Table 2) | Are WL-indistinguishable graphs rare? | 7 datasets, WL iterations 1-4 | |G/\u2243_WL\u2113|/|G/\u2243| | At \u2113=4, ratio 1.000 for most datasets | C3 | Only counts graph-level indistinguishability |
| E3 (Table 3) | Are nodes (\u2113,k)-identifiable? | 7 datasets, k=1,2,3; \u2113 varying | Node fraction, graph fraction | >97% nodes at \u2113=k+2 | C1 (conditions hold) | Node-level vs graph-level gap not analyzed |
| E4 (Figure 4) | Are subgraph isomorphisms quite-colorful? | 7 datasets, several patterns, l=0-5 | |Q|/|S| | Near 100% at l=3 for most patterns | C2 (algorithm validation) | Peptides-func counterexample in appendix |
| E5 (Table 7 left) | Parent-colorful counting (synthetic) | 2000 graphs, 32 nodes, min cycle 5 | MAE, AUC | Near-perfect (MAE 0.000-0.090) | C2 | Simple synthetic setting |
| E6 (Table 7 right) | Quite-colorful counting (synthetic) | 2000 graphs, 96 nodes, 120 edges | MAE, AUC | Near-perfect (MAE 0.000-0.138) | C2 | Simple synthetic setting |

### Research-Theme Gap Diagnosis

1. **New knowledge**: The paper contributes the concept of (\u2113,k)-identifiability and connects it to sample complexity via pseudo-dimension. This is a genuine theoretical contribution. However, the practical utility is unclear given the astronomical O(\u03b7\u00b2) bound for realistic datasets.

2. **Reproducibility**: The code is available (github.com/BorgwardtLab/GNNsCanCountSubstructures) and experimental details are provided. However, the synthetic data generation (E5, E6) is not fully reproducible from text alone.

3. **Impact on practice**: The main practical implication is that practitioners can use standard GNNs for subgraph counting on molecular data without needing expressive architectures. But this is already common practice; the paper's contribution is explanatory rather than prescriptive.

4. **Why expressive GNNs work better?**: The paper ends by questioning why WL-beyond architectures outperform simpler ones if expressivity is not the issue. This is the most impactful open question the paper identifies, but it is not addressed.

### Proposed Research Experiments

**P0 Experiment A: Impact of Non-Identifiable Nodes on Counting Accuracy**
- **Target Claim**: C3 - conditions hold in practice
- **Hypothesis**: Graphs with non-(\u2113,k)-identifiable nodes have significantly worse counting accuracy
- **Minimal Design**: Split each dataset's test set into "fully identifiable" vs. "partially identifiable" graphs based on Table 3 criteria; compare per-group AUC/nMAE
- **Controls/Baselines**: Same GNN architecture, same training set
- **Metrics**: AUC and nMAE per group; statistical significance (paired t-test)
- **Success Criterion**: 95% confidence that fully identifiable group has lower nMAE
- **Estimated Cost/Time**: Low (analysis of existing predictions, 1-2 days)
- **Expected Paper-Quality Gain**: Quantifies the actual impact of the identifiability condition on performance; closes the node-level vs graph-level gap

**P1 Experiment B: Ablation of Quite-Colorful vs. Non-QC Maps**
- **Target Claim**: C2 - TREE-COLSI alignment explains GNN performance
- **Hypothesis**: GNN accuracy is higher for patterns with higher |Q|/|S| ratio
- **Minimal Design**: For each pattern in Table 4, compute correlation (across datasets) between |Q|/|S| ratio at l=3 and AUC/nMAE
- **Controls/Baselines**: Compare against random correlation baseline
- **Metrics**: Pearson correlation, Spearman rank correlation
- **Success Criterion**: |r| > 0.5 with p < 0.05
- **Estimated Cost/Time**: Low (compute ratio for all pattern-dataset pairs, 1-2 days)
- **Expected Paper-Quality Gain**: Directly validates whether quite-colorfulness correlates with GNN success, strengthening the causal claim

**P2 Experiment C: GNN Training from Hand-Constructed Weights**
- **Target Claim**: C2 - GNNs can simulate TREE-COLSI
- **Hypothesis**: A GNN initialized with the hand-constructed weights from Theorem 5's construction, then fine-tuned, converges faster and generalizes better than random initialization
- **Minimal Design**: Implement the weight construction for a small tree pattern; compare train/test curves vs. random initialization
- **Controls/Baselines**: Random initialization, Kaiming initialization
- **Metrics**: Convergence epochs, final AUC, nMAE
- **Success Criterion**: Construction-initialized model reaches comparable AUC > random-init in < 50% of epochs
- **Estimated Cost/Time**: Medium (implementation + 2-3 days training)
- **Expected Paper-Quality Gain**: Bridges the existence-proof-to-learnability gap; demonstrates practical relevance

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
### Final Score: 6.5 / 10

**Rationale**: The paper makes a genuine theoretical contribution ((\u2113,k)-identifiability, sample complexity bounds) and provides thorough empirical validation on molecular benchmarks. The core insight—that worst-case analysis is unnecessarily pessimistic for practical subgraph counting—is valuable. However, significant concerns about the gap between theoretical sufficient conditions and practical applicability (node-level vs. graph-level identifiability, astronomical \u03b7\u00b2 bounds, unvalidated bounded-degree assumption, conclusion overclaims) prevent a higher score. The algorithmic alignment contribution (TREE-COLSI) is technically sound but its practical relevance is limited by the restrictive quite-colorful condition.

**Scoring Dimensions**:
- **Research Value**: 7/10 (important problem framing, useful theoretical framework)
- **Novelty**: Deferred (Retrieval-Disabled Mode active; manuscript-level assessment of the theoretical framework suggests incremental but solid contribution)
- **Validity/Soundness**: 6/10 (theoretical proofs appear correct, but gaps between claimed and demonstrated empirical support)
- **Reproducibility**: 7/10 (code available, reasonable experimental details, though synthetic data generation could be more specific)
- **Writing Quality**: 7/10 (well-structured, self-contained, but some overclaims and vague language)

### Post-Revision Target: [7.0, 7.8] / 10

If the authors address the P0 and P1 issues (closing the node-level vs. graph-level identifiability gap, correcting conclusion overclaims, validating bounded-degree assumption, discussing \u03b7 bound practicality, and moving counterexamples to main text), the paper would be a solid 7+ submission. The theoretical contribution is real and the framing is important, but the current overreach on empirical and conceptual claims creates unnecessary vulnerability.