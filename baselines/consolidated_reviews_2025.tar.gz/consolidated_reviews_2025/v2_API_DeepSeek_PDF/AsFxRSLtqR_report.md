## Summary
This paper presents LR0.FM, a large-scale benchmark evaluating the zero-shot classification performance of 10 vision-language foundation models (66 backbones) on low-resolution (LR) images across 15 datasets. The study makes three contributions: (1) a systematic benchmarking analysis revealing that model size, pre-training data quality, fine-tuning, and input resolution all affect LR robustness; (2) a novel weighted aggregation metric (WAR) that addresses biases in existing robustness averaging schemes; and (3) a lightweight method called LR-TK0 that adds learnable tokens to frozen backbones, trained on synthetic diffusion-generated images, to improve LR robustness without altering pre-trained weights.

**Strengths:** The benchmark is comprehensive in scale (10 models, 66 backbones, 15 datasets) and the paper identifies several practically useful trends. The LR-TK0 method is conceptually clean — using feature-level distillation from a frozen teacher to align HR and LR representations — and avoids expensive super-resolution preprocessing. The WAR metric addresses a genuine flaw in existing robustness averaging.

**Key weakness:** The paper's strongest claims (novelty of the benchmark, "quality over quantity" finding, and LR-TK0 effectiveness) are partially undermined by: (a) uncontrolled comparisons confounded by architecture and training recipe differences; (b) missing statistical significance testing across all results; (c) unaddressed potential data contamination via the synthetic data generator's training set; and (d) an unbounded novelty claim that invites reviewer skepticism. The WAR metric's weight optimization is ad-hoc and not portable to other dataset collections.

**Overall assessment:** This is a well-executed benchmarking study with a reasonable lightweight mitigation method. However, the paper's scientific claims need tighter bounding, and several experimental controls need strengthening before the conclusions are fully convincing.

## Strengths
**S1. Large-scale systematic benchmark.** The paper evaluates 10 FMs with 66 backbones across 15 datasets — significantly larger than prior FM robustness studies (typically 4-11 backbones). This breadth enables more reliable trend identification.

**S2. Useful empirical insights.** The finding that pre-training data quality matters more than quantity for LR robustness (DataComp-1B vs LAION-2B), while confounded, is directionally valuable and practically actionable for practitioners selecting pre-trained models.

**S3. Clean method design.** LR-TK0 is conceptually elegant: frozen teacher provides HR feature anchors; lightweight trainable tokens added to each block of a frozen student learn to bridge the HR-LR feature gap. Training on synthetic diffusion data without target dataset exposure is a principled zero-shot approach.

**S4. Thorough ablation and diagnostic experiments.** The paper includes multi-scale training analysis (Table 6), LR token position sensitivity (Figure 15), parameter count impact (Table 5), and Grad-CAM visualizations (Figure 16). These analyses strengthen the method's credibility and provide actionable design guidance.

**S5. Identification of a genuine metric gap.** The paper correctly identifies that existing robustness metrics (SAR) produce misleadingly high scores when models perform near-random on hard datasets. The proposed WAR framework, while imperfect, is a step toward more balanced evaluation.

## Weaknesses
**W1. Confounded "quality over quantity" claim (Major).** The comparison between DataComp-1B and LAION-2B conflates data filtering methodology, training recipe, architecture differences, and loss function variations. This makes the headline claim that "pre-training dataset quality is more important than its size" a correlation, not a causal finding. Without a matched-control experiment (same architecture, same training recipe, only data source varied), this claim is not sufficiently supported. (See Annotation: Page 6 - Benchmarking Analysis, "Quality over Quantity" paragraph)

**W2. Missing statistical significance across all experiments (Major).** No multi-seed runs, confidence intervals, or significance tests are reported. Given that LR-TK0 improvements at 32×32 are often small (EVA-B/16 SAR: +0.9, WAR: +1.6), single-seed results cannot distinguish genuine improvement from random variation. This undermines confidence in the reported gains. (See Annotation: Page 9 - Table 2)

**W3. WAR metric weight optimization is ad-hoc (Major).** The objective function (Eq. 2) uses a hand-picked 0.95 coefficient and a manually selected dataset triple (ImageNet, ImageNet-V2, DTD). No sensitivity analysis is provided, and the weights are not portable to other dataset collections. The metric appears engineered for this specific benchmark rather than derived from general principles. (See Annotation: Page 5 - WAR Optimization)

**W4. Potential data contamination via synthetic data generator (Major).** PIXART-α was trained on LAION-5B, which overlaps with the training distribution of many evaluated FMs and may contain images resembling target benchmark datasets. While the paper argues that greater LR improvement rules out shortcut learning, this argument is not a rigorous falsification test. The claimed "first to train on synthetic diffusion images for zero-shot evaluation" needs stronger validation. (See Annotation: Page 8 - Synthetic HR Dataset)

**W5. Unbounded novelty claims (Moderate).** The statement "no prior work has explored this aspect of FMs" in Contribution 1 is too broad. RECLIP and other works on efficient CLIP training with small images are adjacent. The claim should be explicitly bounded (e.g., "first systematic benchmark at ≤32×32 resolution with ≥10 FMs"). (See Annotation: Page 2 - Contributions)

**W6. LR-TK0 computational cost not reported (Moderate).** The paper claims LR-TK0 is "lightweight" but #LR tokens = #Spatial tokens × (N+1) implies a substantial increase in per-block token count. For ViT-B/16, this means each of the 12 transformer blocks processes 196+196=392 tokens instead of 196, quadratically increasing attention cost. No FLOPs, memory, or inference-time analysis is provided. (See Annotation: Page 7 - LR Tokens)

**W7. Conclusion lacks limitations (Minor).** The conclusion does not discuss failure cases, HR accuracy tradeoffs for some backbones, or the gap between synthetic bicubic degradation and real-world LR. This weakens the paper's scientific completeness. (See Annotation: Page 10 - Conclusion)

**W8. Introduction opening factual error (Minor).** LLaMA is listed as a vision-language model, but it is text-only. This categorical error reduces credibility. (See Annotation: Page 1 - Introduction Paragraph 1)

## Key Issues
### Issue 1: Confounded "Quality over Quantity" Claim Undermines a Core Finding
- **Severity**: Major | **Validity Risk**: High | **Fixability**: Medium
- **Evidence**: Page 6 - Benchmarking Analysis, the claim is based on DataComp-1B (1.4B) vs LAION-2B (2.4B) comparison without controlling for filtering pipeline, training recipe, architecture, or loss function.
- **Impact**: This is Abstract finding (ii). If unsupported, one of the three headline findings is effectively invalidated.
- **Required action**: Rephrase as observational trend, add matched-control experiment (same architecture/subset size), or downgrade to a caveated suggestion.

### Issue 2: Missing Variance Reporting Across All Experiments
- **Severity**: Major | **Validity Risk**: High | **Fixability**: Easy
- **Evidence**: Page 9 - Table 2 and Page 9 - Table 3 show no standard deviations, confidence intervals, or significance tests for any metric.
- **Impact**: Small LR-TK0 gains at 32×32 (SAR +0.9 to +1.6) cannot be distinguished from noise. Main claims about LR-TK0 effectiveness are not statistically grounded.
- **Required action**: Re-run with ≥3 seeds, report mean±std, add paired significance test across datasets.

### Issue 3: WAR Metric Weight Optimization is Arbitrary
- **Severity**: Major | **Validity Risk**: Medium | **Fixability**: Medium
- **Evidence**: Page 5 - Eq. (2) uses hand-picked coefficient 0.95 and a manually selected dataset triple. No sensitivity analysis or cross-validation.
- **Impact**: WAR could be perceived as engineered for a desired ranking rather than a principled metric. Not portable beyond the 15 specific datasets.
- **Required action**: Add sensitivity analysis, propose a simpler principled alternative (inverse-correlation weighting), or validate with held-out datasets.

### Issue 4: Potential Data Contamination from Synthetic Data Generator
- **Severity**: Major | **Validity Risk**: Medium | **Fixability**: Hard
- **Evidence**: Page 8 - Section 5.2: PIXART-α trained on LAION-5B, which likely contains ImageNet-like images. The paper's counter-argument (greater LR improvement) is not a rigorous test.
- **Impact**: If contamination exists, LR-TK0's zero-shot claim is partially compromised and gains may not transfer to truly out-of-distribution LR data.
- **Required action**: Evaluate on held-out datasets not in LAION-5B/PIXART-α distribution; quantify distribution overlap.

### Issue 5: Computational Overhead of LR Tokens Not Quantified
- **Severity**: Moderate | **Validity Risk**: Low | **Fixability**: Easy
- **Evidence**: Page 7 - Section 5.1: #LR tokens = #Spatial tokens × (N+1). For ViT-B/16 with 196 tokens × 12 blocks, this is ~2352 tokens. The "lightweight" claim is unsubstantiated without complexity analysis.
- **Impact**: Readers cannot assess the practical deployability of LR-TK0 vs alternatives (e.g., SR preprocessing, prompt tuning).
- **Required action**: Report FLOPs, inference time, and peak memory vs. baseline and competing methods.

## Actionable Suggestions
### Suggestion A: Bound the "Quality over Quantity" Claim (Must, P0)
**Target:** Page 6 - "Pretraining 'Quality over Quantity'" paragraph, Abstract finding (ii), Page 10 - Conclusion.

Replace the causal-sounding claim with a more defensible statement:
> "Under the compared pre-training pipelines, models trained on the smaller DataComp-1B (1.4B) tend to show better LR robustness than those trained on the larger LAION-2B (2.4B), despite having fewer image-text pairs. This suggests data curation quality is a significant factor, though we note that pre-training recipe, loss function, and architectural details are not fully controlled across model families."

Also add a one-sentence caveat in the Abstract: "We observe that..."

### Suggestion B: Add Statistical Significance to Main Results (Must, P0)
**Target:** Page 9 - Table 2 and Table 3.

Re-run LR-TK0 for EVA-B/16, Meta-B/16, and OC-B/16 with 3 random seeds. Report mean ± std for SAR, WAR, and Acc at all resolutions. For the key improvement claims, add a paired Wilcoxon signed-rank test across the 15 datasets (baseline vs LR-TK0 per dataset). Example revised table cell: `42.4 ± 1.2` instead of `42.4`.

### Suggestion C: Add Sensitivity Analysis for WAR Hyperparameters (Must, P1)
**Target:** Page 5 - Eq. (2) and associated text.

Provide a supplementary table showing WAR-16 rankings under $\alpha \in \{50, 100, 200, 500, 1000\}$ and under alternative objective formulations (e.g., equal-weight, inverse-correlation weighting). This will demonstrate that the main conclusions are robust to the specific choice of $\alpha$ and objective coefficients.

### Suggestion D: Evaluate on Held-Out Datasets for Data Contamination Check (Nice-to-have, P1)
**Target:** Page 8 - Section 5.2.

Add one or two held-out evaluation datasets that are unlikely to be in the LAION-5B training distribution of PIXART-α, such as:
- A medical imaging dataset (e.g., ChestX-ray, Kvasir)
- A specialized remote sensing dataset not in EuroSAT
Report whether LR-TK0's improvement holds on these OOD datasets.

### Suggestion E: Report Computational Overhead of LR-TK0 (Must, P1)
**Target:** Page 7 - Sections 5.1 and 6.1.

Add a one-paragraph analysis reporting the following for baseline vs LR-TK0:
- Total parameter count (already in Table 2)
- FLOPs per forward pass
- Inference time (ms/image) on a standard GPU
- Peak GPU memory
- For comparison, include the same metrics for VPT and RobustSAM

### Suggestion F: Fix the LLaMA Factual Error (Must, P0)
**Target:** Page 1 - Introduction Paragraph 1.

Replace "LLaMA" with a proper vision-language model reference (e.g., CoCa, SigLIP, or simply "their variants"). See Annotation for exact replacement text.

### Suggestion G: Restructure Related Work (Nice-to-have, P2)
**Target:** Page 3 - Related Work.

Reorganize around three comparison axes: (1) FM Robustness Evaluation, (2) Low-Resolution Recognition, (3) LR Mitigation Strategies. Each paragraph should end with "This paper differs by..." See Annotation for detailed structure.

### Suggestion H: Add Limitations to Conclusion (Must, P1)
**Target:** Page 10 - Conclusion.

Add a limitations paragraph covering: (1) HR accuracy tradeoff for some backbones, (2) synthetic bicubic degradation vs real-world LR, (3) confounded nature of the "quality over quantity" finding, (4) single-seed results. See Annotation for Mentor Revised Version.

## Storyline Options + Writing Outlines
### Abstract Outline (4-5 sentences)

**S1 — Problem and Domain:** Open with the observation that vision-language FMs excel on HR benchmarks but degrade sharply under low-resolution/pixelated conditions — a real-world challenge.

> "Vision-language foundation models (FMs) achieve strong zero-shot accuracy on high-resolution benchmarks, but their performance degrades substantially on low-resolution (LR) images — a common real-world condition arising from surveillance, satellite, and privacy-protected imagery."

**S2 — Gap:** State that prior robustness evaluations focus on face recognition or specific degradations, lacking a systematic FM benchmark at very LR (≤32×32).

> "Existing robustness studies focus on face recognition or image quality metrics, leaving the impact of very low resolution (≤32×32) on FM zero-shot classification systematically unexplored."

**S3 — Benchmark and Key Findings:** Introduce LR0.FM and three headline findings.

> "We introduce LR0.FM, evaluating 10 FMs across 66 backbones and 15 datasets under LR. We find that: (i) model size correlates positively with LR robustness; (ii) pre-training data quality appears more important than quantity, though this is an observational trend; (iii) fine-tuned and higher-resolution models are less robust."

**S4 — New Metric:** Briefly mention WAR.

> "We further propose Weighted Aggregated Robustness (WAR), a metric that corrects biases in existing averaging schemes."

**S5 — Method and Outcome:** Present LR-TK0 and its result.

> "Leveraging these insights, we introduce LR-TK0 — lightweight trainable tokens added to frozen backbones — which improves LR robustness by up to +9.8 SAR points while preserving pre-trained weights and zero-shot capability."

### Introduction Outline (5 paragraphs)

**P1 — Big Picture & Problem** (current: Page 1, needs LLaMA fix)
- Role: Establish the importance of FMs, their HR success, and the open problem of LR robustness.
- Key claim: FMs are untested on very LR images.
- Transition: Lead into real-world LR scenarios.

**P2 — Real-World LR Scenarios** (current: Page 1-2, good)
- Role: Concrete examples (surveillance, satellite, privacy) to establish practical stakes.
- Key claim: LR images are widespread and cause performance degradation.
- Transition: "Motivated by this, we present..."

**P3 — Our Benchmark and High-Level Approach** (current: Page 2, first part of "Motivated by this" paragraph)
- Role: Introduce LR0.FM — its scope (10 models, 66 backbones, 15 datasets) and what it measures.
- Key claim: This is the largest-scale LR robustness study for FMs.
- Transition: "Our analysis reveals..."

**P4 — Key Insights** (currently embedded mid-paragraph, should be a standalone paragraph)
- Role: State the three key findings without metric technicalities.
- Key claims: (i) model size, (ii) pre-training quality, (iii) fine-tuning/resolution impact, (iv) semantic reasonability of LR predictions.
- Transition: "These insights suggest that..."

**P5 — Proposed Solution and Contributions** (currently merged with metrics discussion, needs separation)
- Role: Introduce LR-TK0 intuitively, then list three contributions explicitly.
- All metrics discussion (SAR limitations, WAR) should be moved to Section 3.
- Key claim: LR-TK0 is simple, preserves weights, uses synthetic data only.

### Storyline Option Comparison

| Criterion | Current Storyline | Preferred Candidate |
|-----------|-------------------|---------------------|
| Problem alignment | Good (LR is real problem) | Same |
| Variable alignment | OK (findings → method intuition) | Better: explicit bridge from finding "initial layers suffer most" → "LR tokens at initial layers" |
| Contribution-evidence alignment | Weak (metrics discussion in intro) | Stronger: separate metric discussion, tighter intro |
| Narrative clarity | Good | Better: clearer separation of benchmark findings vs. method vs. metric |

## Priority Revision Plan
### P0 — Must-fix before resubmission (critical for validity)

| # | Task | Effort | Impact | Annotation Ref |
|---|------|--------|--------|----------------|
| P0.1 | Bound the "quality over quantity" claim with caveats | Low | High (invalidated claim) | Page 6 - Benchmarking Analysis |
| P0.2 | Add multi-seed variance (±std) to Table 2 and Table 3 | Medium | High (statistical grounding) | Page 9 - Table 2 |
| P0.3 | Fix LLaMA factual error in Introduction P1 | Low | Medium (credibility) | Page 1 - Introduction Paragraph 1 |
| P0.4 | Rewrite Contribution 1 with bounded novelty language | Low | High (reviewer skepticism) | Page 2 - Contributions |
| P0.5 | Move metrics detail (SAR limitations, Problem A/B) from Introduction to Section 3 | Low | Medium (narrative flow) | Page 2 - Intro Paragraph 4 |

### P1 — Important improvements (moderate effort, high value)

| # | Task | Effort | Impact | Annotation Ref |
|---|------|--------|--------|----------------|
| P1.1 | Add WAR sensitivity analysis (α variation, alternative objectives) | Medium | High (metric credibility) | Page 5 - Eq. (2) |
| P1.2 | Report computational overhead (FLOPs, memory, latency) for LR-TK0 | Low | Medium (deployability) | Page 7 - LR Tokens |
| P1.3 | Add limitations paragraph to Conclusion | Low | Medium (completeness) | Page 10 - Conclusion |
| P1.4 | Evaluate LR-TK0 on held-out OOD datasets for contamination check | High | High (zero-shot claim) | Page 8 - Synthetic Data |
| P1.5 | Add sensitivity for α=100,200,500 in Eq. (1) | Low | Medium (metric rigor) | Page 4 - Eq. (1) |

### P2 — Quality improvements (lower priority)

| # | Task | Effort | Impact | Annotation Ref |
|---|------|--------|--------|----------------|
| P2.1 | Restructure Related Work around comparison axes | Medium | Medium (positioning) | Page 3 - Related Work |
| P2.2 | Clarify LR token addition mechanism (concatenation vs summation) | Low | Medium (reproducibility) | Page 7 - LR Tokens |
| P2.3 | Add paired significance test for LR-TK0 vs baseline across datasets | Low | Medium (evidence quality) | Page 9 - Results |
| P2.4 | Add E^D clamping for negative accuracy gaps in Eq. (1) | Low | Low (edge case) | Page 4 - Eq. (1) |

### Revision Execution Timeline

```text
ASCII Diagram — Revision Strategy Roadmap

Stage 1 (1-2 days): Language & Claim Fixes
  [Bound quality/quantity claim] ──> [Fix LLaMA error] ──> [Rewrite Contribution 1]
  └──> [Move metrics from Intro to Section 3] ──> [Add limitations to Conclusion]
  
Stage 2 (3-5 days): Experimental Validation
  [Re-run Table 2 with 3 seeds] ──> [Compute ±std + significance tests]
  └──> [WAR sensitivity: α sweep + alternative weighting]  
  └──> [Report FLOPs/memory for LR-TK0]
  
Stage 3 (1-2 weeks): Robustness Checks
  [Evaluate on held-out OOD datasets] ──> [Data contamination analysis]
  └──> [Restructure Related Work]
  └──> [Clarify LR token mechanism in Figure 10]
```

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective/Hypothesis | Setup (Data/Split/Protocol/Baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|--------|---------------------|---------------------------------------|---------|--------------|-----------------|-------------------|
| E1 | Benchmark LR0.FM: evaluate FM performance under LR | 10 FMs, 66 backbones, 15 datasets, 4 LR levels (16/32/64/128), bicubic downsampling | Top-1 Acc, SAR, WAR | All models degrade significantly below 64×64; larger models more robust | C1 (Benchmark) | No statistical testing; single-seed; synthetic bicubic only |
| E2 | WAR metric evaluation | Same 66 models, 15 datasets, Spearman correlation analysis | Spearman correlation | WAR improves EuroSAT correlation 0.26→0.49, ImageNet-A 0.56→0.68 | C3 (WAR metric) | Ad-hoc weight optimization; no sensitivity analysis |
| E3 | LR-TK0 improvement (main result) | EVA-B/16, Meta-B/16, OC-B/16; 7K captions, 30 img/caption; multi-scale training | SAR, WAR, Acc (all resolutions) | Consistent improvement at 16×16 (+2.8 to +9.8 SAR); small/negligible at higher resolutions | C2 (LR-TK0) | No variance reported; no significance testing |
| E4 | SR methods comparison | EVA-B/16 vs 6 SR methods (BSRGAN, ESRGAN, SwinIR, AddSR, Inf-DiT, IDM) | SAR, WAR, Acc | LR-TK0 outperforms all SR methods; SR fails at very LR | C2 (LR-TK0) | Unequal compute budgets; IDM too expensive for full eval |
| E5 | Ablation: freezing vs fine-tuning | EVA-B/16 with/without frozen weights, with/without LR tokens, with/without classifier | SAR-16, WAR-16, SAR-32, WAR-32 | Frozen weights + LR tokens best; fine-tuning degrades performance | C2 (design choice) | Single architecture only |
| E6 | Multi-scale ablation | EVA-B/16, cumulative resolution buckets [16,32]→[128,224] | WAR-16, WAR-32 | Cumulative improvement; diminishing returns after [64,128] | C2 (multi-scale design) | Small gains; computational cost of more buckets not reported |
| E7 | LR token position | EVA-B/16, LR tokens introduced from i-th block onward | SAR-16, WAR-16 | Earlier layers benefit more; validates initial-layer-damage finding | C2 (design choice) | Only tested on EVA-B/16 |
| E8 | Generalization to other methods | VPT, RobustSAM with/without LR-TK0 | SAR-16, WAR-16 | LR tokens improve VPT further; RobustSAM underperforms | C2 (generalization) | Limited scope; RobustSAM adaptation details in appendix |
| E9 | Grad-CAM visualization | EVA-B/16, LR-TK0 vs baseline at 16×16 | Qualitative (attention maps) | LR-TK0 focuses on object; baseline attention scattered | C2 (mechanism) | Qualitative only; small sample |

### Research-Theme Gap Diagnosis

The following core claims are not fully supported by the current evidence:

1. **Causal quality-quantity tradeoff**: The finding that pre-training data quality > quantity is confounded by uncontrolled factors (filtering method, training recipe, architecture). This weakens the paper's most practically relevant claim.

2. **LR-TK0 statistical reliability**: Without variance estimates, the modest gains at 32×32 (SAR +0.9 to +1.6) may be within noise range. The claim that LR-TK0 "consistently enhances robustness" is not statistically validated.

3. **Zero-shot generalization of LR-TK0**: The synthetic data generator's training distribution overlaps with target benchmarks. The paper's argument against shortcut learning is insufficient.

4. **WAR metric generalizability**: The ad-hoc optimization makes WAR specific to the 15-dataset benchmark, limiting its adoption as a standard evaluation protocol.

### Proposed Research Experiments

#### P0 Experiments (must-do for validity)

**Exp P0.1: Multi-seed replication of Table 2**
- **Target Claim:** C2 (LR-TK0 effectiveness)
- **Hypothesis:** LR-TK0 improvements are statistically significant
- **Minimal Design:** Run EVA-B/16, Meta-B/16, OC-B/16 with 3 seeds each
- **Controls:** Same random seeds for baseline and LR-TK0
- **Metrics:** Mean±std for SAR, WAR, Acc; paired Wilcoxon test p-value
- **Success Criterion:** p < 0.05 for 16×16 improvements; report non-significant results honestly
- **Expected Quality Gain:** Statistical grounding for all LR-TK0 claims

**Exp P0.2: Controlled quality-quantity experiment**
- **Target Claim:** Finding (ii) — data quality > quantity
- **Hypothesis:** On equal-size subsets, better-filtered data improves LR robustness
- **Minimal Design:** Train ViT-B/16 with CLIP objective on equal-size (500M) subsets of DataComp-1B and LAION-2B
- **Controls:** Same architecture, optimizer, learning rate, training steps
- **Metrics:** WAR-16, SAR-16
- **Success Criterion:** DataComp-1B subset outperforms LAION-2B subset
- **Expected Quality Gain:** Transforms observational correlation into causal evidence

#### P1 Experiments (important additions)

**Exp P1.1: OOD held-out evaluation for contamination check**
- **Target Claim:** C2 (zero-shot generalization)
- **Hypothesis:** LR-TK0 improvements hold on datasets unlikely to be in PIXART-α training data
- **Design:** Add ChestX-ray or a non-EuroSAT remote sensing dataset to evaluation
- **Controls:** Same LR-TK0 training (no additional data)
- **Metrics:** Top-1 Acc improvement at 16×16 and 32×32
- **Success Criterion:** Positive improvement on OOD datasets
- **Expected Quality Gain:** Strengthens zero-shot claim; addresses contamination concern

**Exp P1.2: WAR sensitivity analysis**
- **Target Claim:** C3 (WAR metric)
- **Hypothesis:** WAR rankings are stable under α and objective variations
- **Design:** Compute WAR-16 rankings for α ∈ {50,100,200,500,1000} and 3 alternative objectives (equal weight, inverse-correlation, leave-one-out)
- **Metrics:** Spearman correlation between ranking variants
- **Success Criterion:** All variants show inter-correlation > 0.9
- **Expected Quality Gain:** Demonstrates WAR robustness; enables broader adoption

**Exp P1.3: LR-TK0 computational profiling**
- **Target Claim:** C2 (lightweight method)
- **Hypothesis:** LR-TK0 adds < 2× inference time
- **Design:** Profile baseline, VPT, RobustSAM, and LR-TK0 for FLOPs, inference time, peak memory
- **Controls:** Same batch size, hardware (single A100)
- **Success Criterion:** LR-TK0 overhead quantified and compared
- **Expected Quality Gain:** Enables practical deployment assessment

### Experiment Upgrade Plan

```text
ASCII Diagram — Experiment Upgrade Plan

P0 (Must, 1 week)
┌────────────────────────────────────────────────────┐
│  Exp P0.1: Multi-seed Table 2 (3 seeds × 3 models)│
│  └──> Statistical validation of all LR-TK0 gains   │
├────────────────────────────────────────────────────┤
│  Exp P0.2: Controlled quality-quantity comparison   │
│  └──> Train ViT-B/16 on equal-size subsets         │
│  └──> Causal evidence for Finding (ii)              │
└────────────────────────────────────────────────────┘

P1 (Important, 2-3 weeks)
┌────────────────────────────────────────────────────┐
│  Exp P1.1: Held-out OOD evaluation (medical + RS)  │
│  └──> Contamination check for synthetic data        │
├────────────────────────────────────────────────────┤
│  Exp P1.2: WAR sensitivity (α sweep + alternatives)│
│  └──> Metric robustness demonstration               │
├────────────────────────────────────────────────────┤
│  Exp P1.3: Computational profiling (FLOPs/memory)   │
│  └──> Deployability assessment                      │
└────────────────────────────────────────────────────┘
```

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score: 6/10**

*Rationale:* The paper demonstrates substantial benchmarking effort (10 FMs, 66 backbones, 15 datasets) and introduces a clean, conceptually elegant method (LR-TK0). The identification of a genuine flaw in existing robustness metrics is a positive contribution. However, the score is constrained by:

- **Research Value (Moderate):** The benchmark is the largest of its kind, but the most interesting finding ("quality over quantity") is confounded and cannot be causally attributed. The practical value is clear for practitioners selecting FMs for LR deployment.
- **Novelty (Low-Moderate):** The benchmarking contribution is incremental (larger scale of a known evaluation paradigm). The LR-TK0 method is a novel application of learnable tokens but shares architectural similarities with visual prompt tuning. The WAR metric addresses a real problem but its ad-hoc optimization limits its novelty. Due to Retrieval-Disabled Mode, external literature comparison was not possible; novelty conclusions are deferred for manual verification.
- **Validity (Moderate):** The confounded quality-quantity comparison and missing statistical significance are the primary validity concerns. The WAR metric's hyperparameter sensitivity is unexamined.
- **Reproducibility (Moderate-High):** The evaluation protocol and method are clearly described. Code is promised. The main gap is the absent variance reporting and the unspecified LR token addition mechanism (concatenation vs summation).

**Post-Revision Target: [7.0, 7.5]/10**

This target assumes all P0 and P1 items are addressed: multi-seed variance reporting, bounded claims, controlled quality-quantity experiment, data contamination analysis, WAR sensitivity analysis, and computational profiling. If these are fully addressed, the paper would present a solid benchmarking contribution with a well-validated mitigation method. The upper bound of 7.5 reflects the inherently incremental nature of the contributions — a benchmark extension and a lightweight adaptation method — which, even with perfect execution, would not exceed the "strong accept" threshold without a fundamentally new technical insight or a paradigm-shifting empirical finding.