## Summary
This paper studies bandit learning in matching markets with **indifferent preferences** — a relaxation of the strict-preference assumption that dominates existing theoretical work. The authors propose an **adaptive exploration algorithm based on arm-guided Gale-Shapley (AE-AGS)** that allows players to explore arms proposed to them through a GS process, avoiding the "when to stop exploring" dilemma that breaks existing explore-then-GS algorithms under indifference. 

The paper makes three core contributions:

- **C1 (Problem formulation):** Identifying that existing explore-then-GS algorithms fail under indifference because their stopping condition (confidence-interval separation) is never triggered for tied preferences, leading to O(T) regret.
- **C2 (Algorithm design):** Proposing AE-AGS, which uses arm-guided proposals to decouple exploration from explicit gap detection, enabling cost-free exploration of indifferent arms and adaptive elimination of suboptimal arms.
- **C3 (Theoretical analysis):** Proving an O(NK log T / Δ²) stable regret bound for both centralized and decentralized settings, and showing that when Δ = 0 the regret is 0 (centralized) or O(log T) (decentralized).

The paper also provides a systematic analysis (Table 1) of which existing algorithms can be extended to indifference and identifies the exact proof steps that fail. Experiments on synthetic markets (N=K up to 12) with Gaussian rewards compare AE-AGS against two baselines (C-ETC and P-ETC), showing lower cumulative regret and market instability.

**Novelty/comparison verdict:** External literature verification is deferred in this run (Retrieval-Disabled Mode). Based on manuscript evidence alone, the problem formulation (indifference in bandit matching markets) and the adaptive arm-guided exploration mechanism appear to be novel contributions beyond the existing strict-preference literature cited in the paper. The paper's own Table 1 provides a structured comparison showing that prior works claiming O(K log T / Δ²) or O(NK log T / Δ²) regret under strict preferences do not extend to indifference-extend without modification.

## Strengths
1. **Important problem formulation.** Relaxing the strict-preference assumption in bandit matching markets is a meaningful step toward practical applicability. The paper correctly identifies that indifference creates a fundamental failure mode for explore-then-GS algorithms and provides a clean characterization of why.

2. **Clean algorithmic idea.** The arm-guided adaptive exploration mechanism is intuitive and well-motivated. By letting arm proposals drive exploration rather than statistical confidence-gap detection, the algorithm naturally avoids the stopping dilemma that plagues prior work under indifference. This design insight is the paper's strongest conceptual contribution.

3. **Rigorous theoretical analysis.** The paper provides complete regret bounds (Theorems 4.1 and 5.1) with detailed proofs in the appendix. The decomposition of regret into a failure event term and a conditional term is standard but carefully executed. The paper also provides a systematic analysis (Table 1) of which existing algorithms fail under indifference and why, which is valuable for the community.

4. **Both centralized and decentralized settings.** The paper addresses both settings both variants, with a non-trivial communication protocol (Algorithm 5) for the decentralized case. This completeness is a strength.

5. **Honest limitation discussion.** The conclusion explicitly acknowledges that the paper focuses on weak stability (not stronger forms like super-stability) and that player-optimal stable matchings may not exist under indifference.

## Weaknesses
1. **[Major] Definition-proof mismatch in stable regret.** The stable regret defined in Eq. (1) measures per-player cumulative reward difference against the worst-case stable matching reward. However, the proof (Lemma B.2) bounds the cumulative number of unstable matchings. The paper's footnote acknowledges that "the worst partner for all players may not appear in a single stable matching," which means the proof does not directly bound the quantity defined in Eq. (1). The paper claims the bound "also applies to cumulative market instability," which is a different metric. This gap between claimed objective and proven quantity undermines theoretical rigor. (Annotation ID: c43533a0-bd05-4eb7-ada8-8fb87cc6f106)

2. **[Major] Overclaim on empirical validation.** The abstract and conclusion claim "extensive experiments" and "consistent superiority over baselines." In reality, experiments compare against only two baselines (C-ETC and P-ETC), both of which are weak: C-ETC requires prior knowledge of Δ, and P-ETC has exponential regret. No comparison is made against adapted versions of the state-of-the-art explore-then-GS algorithms (Zhang et al., 2022; Kong & Li, 2023) with random tie-breaking. All data is synthetic with Gaussian rewards, and market sizes are limited (N=K ≤ 12). (Annotation IDs: c3498acc-3316-4b7d-8042-b2f184c9c4cc, e665c8ae-da31-4a02-9124-5f4c3601c066)

3. **[Major] Logical gap in the Δ = 0 regret claim.** Theorem 4.1 states Reg_i(T) = 0 when Δ = 0, with the proof assuming "all players have the same preferences over all arms." However, Δ = 0 (defined as min non-zero gap being zero) does not imply all players are completely indifferent — it only implies at least one pair of arms is tied for at least one player. In markets where some players have ties and others have strict preferences, the claim that "any matching is stable" does not hold, and regret may not be zero. (Annotation ID: f16fc844-41d6-4867-9281-65d1a369cecd)

4. **[Major] Overclaim in contribution summary.** The contribution paragraph (Page 2) states the algorithm achieves O(NK log T / Δ²) regret without acknowledging the N-factor overhead compared to the best strict-preference bounds (O(K log T / Δ²) in decentralized settings). This N factor is notable and should be transparently discussed as the cost of handling indifference. (Annotation ID: f9b06790-2357-460c-a96d-6bc9ffec0f92)

5. **[Minor] Related work section is a list rather than taxonomy-organized.** The Related Work section (Pages 3-4) reads as a chronological list of papers rather than organizing methods by comparison axes (e.g., algorithmic paradigm, regret type, setting assumptions). This makes it harder for readers to quickly understand the paper's positioning. The paper's own Table 1 is more informative than the narrative text.

6. **[Minor] Unnecessary MAB tutorial content.** The second paragraph of the introduction (Page 2) is a basic tutorial on multi-armed bandits that is unnecessary for the target ICLR audience. This space could be better used to elaborate on the technical challenge of indifference. (Annotation ID: 36509690-a5f8-4559-8ea1-dc59f8deb620)

7. **[Minor] Gaps in peer comparison with Lin et al. (2024).** The comparison with the concurrent work by Lin et al. correctly identifies the difference in regret type (exact vs. α-approximate) but does not discuss the trade-off between problem-dependent and problem-independent bounds. (Annotation ID: d706eac6-53cc-4ce5-bf1d-6f447a52b51c)

## Key Issues
### Issue 1: Definition-Proof Mismatch (Severity: Major)
**Location:** Page 5 — Stable regret definition (Eq. 1) and Page 13-15 — Proof (Lemma B.2)

The paper defines stable regret as $\text{Reg}_i(T) = \mathbb{E}[\sum_{t=1}^T (\mu_{i,m_i} - X_{i,A_i(t)})]$ where $\mu_{i,m_i} = \min_{m' \in \mathcal{M}} \mu_{i,m'_i}$. However, the proof bounds $\mathbb{E}[\sum_{t=1}^T \mathbf{1}\{A(t) \notin \mathcal{M}\}]$ — the number of unstable matchings. The footnote acknowledges "the worst partner for all players may not appear in a single stable matching," confirming that the proof quantity does not equal the defined quantity.

**Required fix:** Either (a) redefine stable regret as cumulative market instability (aligning definition with proof), or (b) provide a rigorous argument linking unstable matchings to per-player regret against the worst-case stable reward.

### Issue 2: Δ = 0 Regret Claim (Severity: Major)
**Location:** Page 7 — Theorem 4.1 and Page 13 — Appendix B proof

Theorem 4.1 claims $\text{Reg}_i(T) = 0$ when $\Delta = 0$, but the proof relies on the assumption that "all players have the same preferences over all arms." Definition 4.1 defines $\Delta = 0$ as the case where the minimum non-zero gap is zero — i.e., there exists at least one tied arm pair. This is weaker than total indifference. The claim is only valid under the stricter condition of complete indifference.

**Required fix:** Clarify the condition for the $\Delta = 0$ case. Either restrict the theorem to "all preference gaps are zero" or provide a separate analysis for the mixed case (some ties, some strict preferences).

### Issue 3: Empirical Overclaim (Severity: Major)
**Location:** Page 1 — Abstract, Page 3 — "Extensive experiments", Page 18-19 — Appendix E

The paper claims "extensive experiments" and "consistent superiority over baselines," but only compares against two weak baselines on synthetic data. C-ETC requires knowing $\Delta$ (unrealistic), and P-ETC has exponential regret. No comparison against adapted strict-preference algorithms. All experiments use Gaussian rewards and random preferences — no real-world data.

**Required fix:** (a) Add a comparison against adapted explore-then-GS baselines with tie-breaking. (b) Replace "extensive experiments" language with precise scope description. (c) Add non-Gaussian noise robustness check or real-world preference data.

## Actionable Suggestions
### S1: Resolve the definition-proof mismatch (Must)
**Problem:** The stable regret definition (Eq. 1) measures per-player reward against the worst-case stable matching, but the proof bounds the number of unstable matchings.

**Recommended action:** Redefine stable regret in Section 3 (Page 5) to match what is actually bounded. Replace Eq. (1) with:
$$\text{Reg}_i(T) = \mathbb{E}\left[\sum_{t=1}^T \mathbf{1}\{\bar{A}(t) \notin \mathcal{M}\}\right]$$
This counts the number of time slots where the matching is unstable. The footnote about "worst partner may not appear in a single stable matching" can then be removed, as it is no longer needed.

**Acceptance criteria:** Definition matches proof quantity; no gap between claimed bound and proven bound.

### S2: Fix the Δ = 0 case (Must)
**Problem:** Theorem 4.1 claims Reg_i(T) = 0 when Δ = 0, but the proof requires "all players have the same preferences over all arms," which is stricter than Δ = 0.

**Recommended action:** (a) Restrict the Δ = 0 claim to the case where all preference gaps are zero (complete indifference). (b) Separately analyze the mixed case where some gaps are zero and others positive — in this case, the bound for Δ > 0 applies (using the minimum non-zero gap), and no separate analysis is needed. Update Definition 4.1 and Theorem 4.1 accordingly.

### S3: Strengthen experimental evaluation (Must)
**Problem:** Only two weak baselines are compared; all data is synthetic.

**Recommended action:** (a) Add a comparison against adapted explore-then-GS baselines (Zhang et al., 2022; Kong & Li, 2023) with random tie-breaking. Even if these algorithms fail, showing their O(T) regret experimentally would strengthen the paper's motivation. (b) Replace "extensive experiments" with precise scope language. (c) Add at least one non-Gaussian noise condition (e.g., Bernoulli or heavy-tailed rewards) to test robustness.

### S4: Tone down contribution claims (Nice-to-have)
**Problem:** The abstract and conclusion claim "consistent superiority over baselines" and "significant improvement" but only compare against two weak baselines.

**Recommended action:** Replace first-paragraph conclusion claims with scoped language. Acknowledge that the N-factor overhead (compared to O(K log T / Δ²) strict-precision bounds) is the cost of handling indifference.

### S5: Improve introduction narrative flow (Nice-to-have)
**Problem:** The MAB tutorial paragraph (Page 2, Paragraph 2) is unnecessary for ICLR audience. The gap paragraph (Page 2, Paragraph 4) could more precisely explain the technical failure mechanism.

**Recommended action:** Condense the MAB tutorial into one sentence. Expand the technical explanation of why confidence intervals never separate for tied arms (addressed in annotation d9e133b5-c3b2-42be-bbe9-6f511dccab1f).

## Storyline Options + Writing Outlines
### Current Storyline Assessment

The current introduction (Pages 1-2) has 5 paragraphs:
1. Background on matching markets and GS algorithm
2. MAB tutorial (largely unnecessary for target audience)
3. Bandit learning in matching markets literature overview
4. Strict-preference limitation and why indifference breaks explore-then-GS
5. Contribution summary and proposed method

**Problem:** The MAB tutorial (P2) distracts from the core narrative. The gap identification (P4) is the strongest paragraph but could be more technically precise about the confidence-interval failure mechanism. The literature survey paragraph (P3) reads as a chronological list rather than a structured comparison.

### Option A: Problem-First Narrative (Recommended)

**Abstract Outline (S1-S5):**
- **S1 (Problem):** "Two-sided matching markets model interactions where employers, schools, or platforms seek stable pairings with workers, students, or providers."
- **S2 (Challenge):** "When participants learn preferences through bandit feedback, the standard strict-preference assumption is often violated in practice — multiple candidates exhibit comparable performance, creating ties."
- **S3 (Gap):** "Existing explore-then-Gale-Shapley algorithms fail under indifference because their confidence-interval-based stopping criteria never trigger for tied preferences, leading to linear regret."
- **S4 (Method):** "We propose AE-AGS, an arm-guided adaptive exploration algorithm that decouples exploration from gap detection, allowing cost-free exploration of indifferent arms."
- **S5 (Result):** "AE-AGS achieves O(NK log T / Δ²) stable regret in both centralized and decentralized settings, matching the best strict-preference bounds up to an N factor."

**Introduction Outline (P1-P4):**
- **P1 (Stakes):** "Matching markets are everywhere — labor, schools, online platforms. But participants rarely know preferences precisely before interaction. Bandit learning offers a solution, but only under the unrealistic assumption that all preferences are strictly ordered."
- **P2 (Gap + Mechanism):** "The key failure mode is subtle but decisive: when two arms have identical preference values, their confidence intervals overlap indefinitely, so the stopping condition LCB_i > UCB_j is never satisfied. This causes explore-then-GS algorithms to explore forever, incurring O(T) regret."
- **P3 (Solution Intuition):** "Our key insight is to let arm proposals — not statistical tests — drive exploration. In each round, arms propose to their most preferred players via a Gale-Shapley process. Players accept the best arm with the fewest prior matches and reject the rest. Rejected arms simply propose to the next player, continuing until all are matched."
- **P4 (Contributions + Preview):** "We prove an O(NK log T / Δ²) regret bound, systematically analyze which prior algorithms fail under indifference, and validate our approach experimentally."

### Option B: Application-First Narrative

Start with a concrete application (e.g., "Consider an online labor platform where employers post tasks and workers apply. Employers cannot distinguish between equally qualified candidates...") before introducing the formal model. This option is slightly longer but more accessible to non-specialists.

### Option C: Algorithm-First Narrative

Restructure to present the arm-guided GS intuition before the formal problem statement, helping readers understand why the algorithm works before seeing the math. This option is best for theory-oriented readers but may confuse those unfamiliar with GS.

**Recommendation:** Option A balances rigor and accessibility, and its P2 explicitly explains the technical failure mechanism, which is currently implicit in the manuscript.

## Priority Revision Plan
```text
ASCII Diagram — Revision Strategy Roadmap

[P0: Definition-Proof Mismatch (Issue 1)]
    -> Fix: Redefine stable regret as cumulative market instability
    -> Location: Page 5, Eq. (1) and related text
    -> Effort: Low (text change only)
    -> Impact: High (removes theoretical gap)

[P0: Δ=0 Regret Claim (Issue 2)]
    -> Fix: Clarify condition in Theorem 4.1
    -> Location: Page 7, Definition 4.1, Theorem 4.1, Appendix B proof
    -> Effort: Low (text change + proof clarification)
    -> Impact: High (fixes logical inconsistency)

[P1: Strengthen Experimental Evaluation (Issue 3)]
    -> Fix: Add adapted baselines, tone down language
    -> Location: Appendix E, Abstract, Conclusion
    -> Effort: Medium (requires running new experiments)
    -> Impact: High (improves empirical credibility)

[P1: Tone Down Contribution Claims (S4)]
    -> Fix: Replace "extensive experiments" and "significant improvement" with scoped language
    -> Location: Abstract, Conclusion, Page 3
    -> Effort: Low (text change only)
    -> Impact: Medium (improves factuality)

[P2: Improve Introduction Narrative]
    -> Fix: Condense MAB tutorial, strengthen gap explanation
    -> Location: Page 1-2, Introduction
    -> Effort: Low (text rewrite)
    -> Impact: Medium (improves readability)
```

| Priority | Issue | Effort | Impact | Acceptance Criteria |
|----------|-------|--------|--------|-------------------|
| P0 | Definition-proof mismatch | Low (text) | High | Regret definition matches proof quantity |
| P0 | Δ = 0 logical gap | Low (text) | High | Theorem condition correctly scoped |
| P1 | Weak baselines in experiments | Medium (experiments) | High | At least one stronger baseline compared |
| P1 | Overclaim wording | Low (text) | Medium | Claims match evidence scope |
| P2 | Introduction narrative | Low (text) | Medium | Clearer problem->gap->solution arc |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Limitation |
|--------|---------------------|-------|---------|-------------|----------------|-----------|
| E1 | Validate AE-AGS convergence under indifference | N=K=5, random preferences, Δ=0.1, Gaussian rewards, T=100k, 20 runs | Per-player stable regret, cumulative market instability | AE-AGS converges; lower regret than C-ETC and P-ETC | C2 (algorithm works under indifference) | Only 2 baselines; synthetic data only |
| E2 | Sensitivity to preference gap Δ | N=K=5, Δ∈{0.1/.15/.2/.25 | Max cumulative stable regret, market unstability | AE-AGS stable across Δ values; C-ETC sensitive to Δ; P-ETC not converged | C2 (robustness to Δ) | Small N=K=5 only |
| E3 | Effect of market size | N=K∈{3,6,9,12}, Δ=0.1 | Max cumulative stable regret, market unstability | Regret grows with N,K as predicted | C3 (bound verified) | Limited to N≤12; no N≠K setting |

### Research-Theme Gap Diagnosis

- **New knowledge:** The paper generates new knowledge about how indifference affects bandit learning in matching markets. However, the empirical validation is too narrow to fully establish this — synthetic-only experiments limit the generality of findings.
- **Reproducibility:** The algorithms are described in sufficient detail for reproduction. Missing details: exact tie-breaking rules for arms, hyperparameter selection process for C-ETC (how Δ is provided), and software/hardware specifications.
- **Impact on practice/understanding:** The paper's main practical insight is that arm-guided exploration naturally handles indifference. This is a valuable design principle, but without real-world validation or deployment-relevant metrics (e.g., communication cost, convergence speed in rounds vs wall-clock time), the practical impact remains unverified.

### Proposed Research Experiments

```text
ASCII Diagram — Experiment Upgrade Plan

[P0: Add adapted explore-then-GS baselines]
    -> Test: Zhang2022 and KongLi2023 with random tie-breaking
    -> Expected: O(T) regret for baselines, O(log T) for AE-AGS
    -> Impact: Strong empirical validation of theoretical claim

[P1: Non-Gaussian reward robustness]
    -> Test: Bernoulli(μ), exponential noise, uniform noise
    -> Expected: Similar ranking across noise types
    -> Impact: Shows robustness beyond Gaussian assumption

[P2: Real preference data]
    -> Test: Generate preferences from real school admission or 
             labor market datasets with ties
    -> Expected: Validates practical applicability
    -> Impact: Bridges theory-practice gap
```

| Target Claim | Hypothesis | Minimal Design | Controls | Metrics | Success Criterion | Est. Effort | Paper-Quality Gain |
|-------------|-----------|----------------|----------|---------|------------------|-------------|-------------------|
| C2 (algorithm novelty) | AE-AGS outperforms adapted strict-preference algorithms with tie-breaking | Run Zhang2022 and KongLi2023 with tie-breaking on existing synthetic setup | Same seeds, budgets, evaluation protocol | Cumulative stable regret, market instability | AE-AGS regret grows as O(log T); baselines grow as O(T) | Low (code adaptation only) | High — directly tests the paper's central claim |
| C2 (robustness) | AE-AGS works under non-Gaussian noise | Replace Gaussian with Bernoulli(μ) or Laplace noise | Same N=K=5, Δ=0.1 | Regret ranking across algorithms | AE-AGS maintains lowest regret ranking | Low (re-run with different noise) | Medium — shows empirical robustness |
| Practical impact | AE-AGS scales to larger markets | Test N=K=20, 50 on synthetic data | Same setup as E3 | Regret, communication overhead | Sub-linear regret growth | Medium (compute) | Medium — addresses scalability concern |
| Practical impact | AE-AGS works on near-real preferences | Use preference data from published admission datasets, add ties | N=K=5-20, tie density 20-50% | Regret vs baselines | AE-AGS outperforms C-ETC and P-ETC on real-derived preferences | Medium (data collection) | High — validates practical relevance |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score: 6/10**

This score reflects the paper's solid theoretical contributions (clean algorithm design with rigorous regret bounds, plus a systematic analysis of why existing algorithms fail under indifference) weighed against its significant empirical limitations (only two weak baselines on synthetic data, narrow market sizes, no real-world validation) and two theoretical gaps (definition-proof mismatch in stable regret, and the Δ=0 logical inconsistency). The paper's conceptual contribution — using arm-guided exploration to naturally handle indifference — is genuinely novel and well-executed. However, the empirical evidence is insufficient to fully support the claims of "consistent superiority" and "extensive experiments."

**Primary scoring dimensions:**
- *Research value:* 7/10 — The indifference setting is practically motivated and the arm-guided exploration insight is transferable
- *Novelty:* 7/10 — First systematic treatment of indifference in bandit matching markets (deferred external verification)
- *Soundness:* 5/10 — Two proof-definition gaps weaken theoretical rigor; empirical scope is narrow
- *Reproducibility:* 6/10 — Algorithms are clearly described but missing hardware/software details

**Post-Revision Target: [7, 8]/10**

If the authors resolve the definition-proof mismatch, fix the Δ=0 logical gap, add at least one stronger baseline comparison (adapted explore-then-GS with tie-breaking), and tone down overclaims to match evidence scope, the paper would score 7-8/10. Full resolution of all issues (including real-world data validation) could approach 8/10, but the absence of real-market experiments is a structural limitation that could be addressed in future work rather than this revision.