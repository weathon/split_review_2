## Summary
# Final Review Report

## Summary

This paper introduces a new federated learning setting called Modality-Collaborated Federated Learning (MCFL), where uni-modal clients with different data modalities (vision and language) collaborate to improve performance across all modalities without requiring multi-modal data on any single client. The authors propose FedCola, a framework built on a modality-agnostic transformer with three key strategies: (1) **Attention Sharing** — sharing only self-attention layers across modalities while keeping FFN layers modality-specific, (2) **Modality Compensation** — extending client models with weights from the previous global round before aggregation to maintain layer-level alignment, and (3) **Modality Warm-up** — scheduling early rounds as uni-modal pre-training to provide better initialization.

The paper is well-motivated: existing federated multi-modal learning (FMML) relies on multi-modal clients, which limits applicability. The MCFL setting addresses a practical gap. FedCola is evaluated on two dataset pairs (CIFAR-100+AGNEWS for general-domain, OrganAMNIST+MTSamples for medical-domain) across multiple FL scenarios (varying client counts, data heterogeneity, and client availability). Results show consistent improvements over Uni-FedAVG (no cross-modal sharing) and CreamFL (knowledge-distillation-based) in terms of average Top-1 accuracy, without additional computation or communication costs.

**Key strengths:** Clear problem identification, systematic ablation of design choices (parameter sharing, aggregation, scheduling), efficient framework design, and comprehensive experimental evaluation. **Key weaknesses:** Overclaimed scope in abstract/conclusion, under-specified limitations, a tenuous theoretical justification for modality compensation, and architectural inconsistency in the collaboration verification experiment. Novelty assessment is deferred as external retrieval is unavailable in this run.

## Strengths
**S1 — Well-motivated new problem setting.** The paper clearly identifies a practical gap in existing federated multi-modal learning (FMML): FMML requires multi-modal clients with aligned multi-modal data, which is hard to collect and excludes uni-modal clients. The proposed MCFL setting (uni-modal clients collaborating to improve per-modality performance) is a natural and useful extension. The healthcare example (hospitals with X-rays vs. transcriptions) effectively illustrates the practical relevance.

**S2 — Systematic ablation and design-space exploration.** Rather than proposing a monolithic method, the paper formulates three research questions (RQ1: parameter sharing, RQ2: aggregation, RQ3: temporal modality arrangement) and empirically evaluates multiple strategies for each. This gives readers clear insight into which design choices matter most. The finding that attention sharing (not full transformer sharing) is the most impactful strategy (+26.93% avg accuracy) is a valuable design insight for future work.

**S3 — Efficiency without performance compromise.** FedCola achieves consistent gains over baselines without requiring additional computation, communication, or a public dataset. The resource analysis (Figure 6) confirms that FedCola has the same communication costs as Uni-FedAVG while CreamFL requires 1.97x computation. The warm-up stage actually reduces costs by involving fewer clients in early rounds. This efficiency-accuracy trade-off is practically important for deployment on resource-limited clients.

**S4 — Comprehensive evaluation.** The experimental design covers two dataset pairs (general-domain and medical-domain), two client counts (4 and 16), three data heterogeneity levels (α=0.5, α=0.1), and two client availability settings (r=0.5, r=0.25). The six evaluation settings in Table 4 provide a reasonably thorough assessment of the method's robustness across varying conditions, including imbalanced client scenarios in Appendix E.

**S5 — Clean ablation and collaboration verification.** The ablation study (Table 5) isolates each component's contribution, and the collaboration verification experiment (Figure 7) provides a creative test of cross-modal knowledge transfer by showing that increasing one modality's capacity improves the other modality's performance.

## Weaknesses
**W1 — Overclaimed scope and promotional language (Severity: Major).** The abstract claims a "substantial advancement in federated learning" and the conclusion states the work "open[s] up new avenues for the deployment of FL in multi-modal data scenarios." These claims go beyond what the paper demonstrates, which is limited to two-modality (vision + language) classification on specific benchmarks. The conclusion omits key limitations such as the restriction to two modalities, classification-only evaluation, and lack of formal privacy analysis. The limitations paragraph (Appendix H) only mentions system heterogeneity. (Cf. annotations on Abstract, Conclusion, and Appendix H Limitations.)

**W2 — Tenuous theoretical justification for Modality Compensation (Severity: Major).** Section 5.2 invokes a Rademacher complexity bound (Mansour et al., 2020) to argue that layers aggregated from different numbers of samples have "misaligned generalizability." However, the cited bound applies to the whole model's generalization error as a function of total samples — it does not decompose into per-layer contributions, nor does it directly imply misalignment between layers. The layer-level alignment claim is an intuitive hypothesis, not a theorem-derived conclusion. Presenting it alongside the Rademacher bound gives a misleading impression of theoretical support. The modality compensation scheme itself is a reasonable heuristic that empirically helps, but this should be acknowledged clearly. (Cf. annotation on Page 6 - RQ2 Modality Compensation.)

**W3 — Verification experiment uses non-standard architecture (Severity: Major).** The "Verification of Modality Collaboration" experiment (Section 7, Figure 7) uses a scratch-trained 7-layer transformer with random initialization, while the main experiments use a pre-trained ViT-Small with BERT tokenizer. The positive correlation shown in Figure 7 is promising, but the architectural discrepancy means the result may not directly generalize to the main experimental setting. This caveat should be explicitly acknowledged. (Cf. annotation on Page 9 - Discussion: Verification of Modality Collaboration.)

**W4 — Limited novelty assessment (Severity: Medium under the circumstances).** Due to external retrieval being unavailable for this run, novelty claims cannot be independently verified against the literature. The paper positions MCFL as a new setting and FedCola as a new framework. While the setting clearly differs from prior FMML, the extent to which the individual techniques (attention sharing in FL, modality-specific vs. shared parameter partitioning, warm-up scheduling) overlap with existing work requires manual verification. The authors should proactively position their work against the strongest baselines and acknowledge any overlap. (Marked as deferred verification.)

**W5 — Ablation reveals Attention Sharing dominates improvements (Severity: Minor).** The ablation study (Table 5) shows that Attention Sharing accounts for +26.93% average accuracy improvement, while Modality Compensation and Modality Warm-up contribute only +0.51% and +0.30% respectively. The paper describes these as "marginal but crucial," but the improvement is marginal without clear evidence of statistical significance. The paper should more transparently state that the core contribution is the attention-sharing strategy, with the other two components providing minor refinements. (Cf. annotation on Page 9 - Ablation Study.)

**W6 — Evaluation metric may obscure per-modality stagnation (Severity: Minor).** The equal-weighted average accuracy gives equal importance to each modality regardless of task difficulty. In the OrganAMNIST+MTSamples setting, language accuracy is very low (20-36%), so the average primarily reflects image performance. A method could achieve high average accuracy by improving only the image modality while language stagnates. Reporting per-modality gains separately or using a min-over-modalities metric would provide a more balanced assessment. (Cf. annotation on Page 7 - Experimental Settings.)

## Key Issues
**Issue 1 (Major): Theoretical overextension in Modality Compensation argument.**
- **Location:** Page 6 - Section 5.2, paragraphs 2-3.
- **Problem:** The paper invokes Rademacher complexity bounds to claim that layers aggregated from different numbers of training samples have "misaligned generalizability." The cited bound is a uniform-convergence bound for the entire model; it does not decompose into per-layer contributions. The layer-level alignment argument is an intuitive heuristic, not a theorem-derived conclusion.
- **Risk:** This overextension could mislead readers about the theoretical grounding of the method. If a reviewer familiar with learning theory reads this, they may flag it as an incorrect or misleading application of theory.
- **Fix:** Reframe the paragraph to clearly separate the empirical observation (modality bias from imbalanced aggregation) from the theoretical reference (generalization correlates with sample size). State the layer-alignment argument as a plausible hypothesis and the modality compensation as an empirical fix.

**Issue 2 (Major): Incomplete limitations disclosure.**
- **Location:** Page 18 - Appendix H (Broader Impact and Limitations).
- **Problem:** The limitations paragraph only mentions "system heterogeneity." Key limitations omitted include: (a) evaluation limited to two modalities, (b) classification tasks only, (c) transformer-specific architecture assumption, (d) no formal privacy analysis, (e) only FedAVG tested as base aggregation.
- **Risk:** An incomplete limitations section undermines scientific integrity and leaves the paper vulnerable to reviewer criticism about missing scope boundaries.
- **Fix:** Expand the limitations to cover the scope restrictions above, as detailed in the annotation.

**Issue 3 (Major): Verification experiment uses mismatched architecture.**
- **Location:** Page 9 - Section 7 (Verification of Modality Collaboration) and Appendix G.3.
- **Problem:** The collaboration verification uses a scratch-trained 7-layer transformer, while main experiments use pre-trained ViT-Small. This makes it uncertain whether the observed cross-modal transfer effect holds under the main experimental configuration.
- **Risk:** A key piece of evidence for the claimed cross-modal knowledge transfer may not generalize to the paper's primary experimental setting.
- **Fix:** Either reproduce the verification with the pre-trained ViT-Small, or explicitly add a caveat acknowledging the architectural difference and explaining why the result should transfer.

**Issue 4 (Minor): Overclaim in abstract and conclusion.**
- **Location:** Page 1 - Abstract; Page 9 - Conclusion.
- **Problem:** The paper uses promotional language ("substantial advancement," "open up new avenues," "strong foundation") that is not bounded to the demonstrated scope (two-modality classification).
- **Risk:** Overclaiming reduces scientific credibility and may cause reviewers to lower their assessment of the paper's quality.
- **Fix:** Replace promotional wording with bounded factual statements as proposed in the annotations.

**Issue 5 (Minor): Dominant contribution attribution.**
- **Location:** Page 9 - Ablation Study.
- **Problem:** The ablation shows Attention Sharing contributes +26.93% improvement while Modality Compensation and Modality Warm-up contribute only +0.51% and +0.30%. Describing these as "marginal but crucial" is subjective and could be seen as inflating minor components.
- **Risk:** May give readers incorrect expectations about the relative importance of each component.
- **Fix:** Explicitly state that the core improvement comes from attention sharing, with the other components providing minor refinements.

## Actionable Suggestions
**Suggestion A (Must fix — Page 6, Section 5.2): Reframe theoretical justification for Modality Compensation.**
Replace the Rademacher-complexity-based argument with an honest empirical motivation. The current text invokes a bound that does not directly support per-layer alignment claims. Recommended revision:
*Original framing:* "As demonstrated in a previous generalization analysis... a model's generalization error is bounded by the Rademacher complexity... layers aggregated from different numbers of training samples may have misaligned generalizability."
*Better framing:* "The generalization error of a model depends on the total number of training samples (Mansour et al., 2020). When shared parameters are aggregated from (N_v + N_l) clients while modality-specific parameters are aggregated from only N_v or N_l clients, different parts of the model are effectively trained with different sample sizes, which may cause inconsistent generalization behavior. To mitigate this, we propose modality compensation..."

**Suggestion B (Must fix — Pages 9 and 18, Conclusion and Limitations): Expand limitations and bound claims.**
Replace promotional closing language with bounded statements. Expand the limitations paragraph in Appendix H to explicitly mention:
- The method is evaluated on two modalities (vision + language) only; extension to more modalities is future work.
- Only classification tasks are tested; applicability to generation, retrieval, or regression is unverified.
- Only transformer architectures with FedAVG aggregation are studied.
- No formal privacy analysis is provided despite qualitative claims about reduced leakage risk.
- The balanced aggregation scheme assumes equal participation; performance under severe client imbalance degrades (Appendix D.2).

**Suggestion C (Must fix — Page 9, Section 7): Add architectural caveat to verification experiment.**
Explicitly state that the collaboration verification uses a scratch-trained 7-layer transformer rather than the pre-trained ViT-Small used in main experiments. Explain why the finding should transfer (shared attention mechanism is architecture-agnostic) and suggest future verification with the primary architecture.

**Suggestion D (Nice-to-have — Page 1, Abstract): Tighten abstract claims.**
Replace "marking a substantial advancement in federated learning" with a bounded statement such as "establishing FedCola as a competitive baseline for MCFL under the evaluated settings."

**Suggestion E (Nice-to-have — Page 5, Section 4.1): Add diagnostic analysis of modality bias.**
The vision accuracy collapse (51.39% to 3.58%) under Vanilla MAT is striking but under-analyzed. Add a brief analysis of whether the bias is caused by gradient dominance, representation collapse, or optimization interference. A simple gradient-norm comparison per modality would strengthen the motivation for proposed solutions.

**Suggestion F (Nice-to-have — Page 7, Experimental Settings): Add a min-over-modalities metric.**
Consider reporting per-modality minimum accuracy alongside the average to ensure balanced improvement across all modalities. This would make the evaluation more robust against scenarios where one modality dominates the average.

## Storyline Options + Writing Outlines
### Current Storyline Assessment

The current introduction follows this structure:
- P1: FL basics -> uni-modal limitation -> call for multi-modal FL.
- P2: Review of existing FMML work -> critique of multi-modal client requirement.
- P3: Gap analysis -> MCFL setting proposal -> two principles.
- P4: Technical challenges (model heterogeneity, modality gap) -> preview of solutions.
- Contribution list.

**Strengths of current storyline:** The progression from FL basics to gap to solution is logically sound. The distinction between FMML (multi-modal clients) and MCFL (uni-modal clients) is clearly drawn. The healthcare example is effective.

**Weaknesses:** The first paragraph spends too much time on basic FL concepts that are well-known to the target audience. The contribution list contains redundancy (item 3: "Better Performance" is a metric claim, not a conceptual contribution).

### Alternative Storyline Candidate (Recommended)

**Abstract Outline (4 sentences):**
- S1: Federated Learning (FL) is predominantly uni-modal, limiting cross-modal knowledge sharing.
- S2: Existing multi-modal FL requires multi-modal clients, which is impractical in many real-world scenarios where clients hold data of only one modality.
- S3: We introduce Modality-Collaborated Federated Learning (MCFL) — a setting where uni-modal clients with different modalities collaborate to improve per-modality performance without multi-modal data — and propose FedCola, which uses a modality-agnostic transformer with cross-modal attention sharing, balanced aggregation, and modality-aware scheduling.
- S4: On vision-language classification benchmarks, FedCola outperforms baselines (Uni-FedAVG, CreamFL) by 3-10% average accuracy without additional computation or communication costs, establishing a competitive baseline for MCFL.

**Introduction Outline (4 paragraphs):**

**P1 — The gap: uni-modal FL cannot leverage cross-modal knowledge (Revised, concise):**
"Federated Learning (FL) enables collaborative training without sharing raw data [McMahan et al., 2017]. However, current FL systems are designed for uni-modal scenarios, where all participants contribute data of the same modality. This excludes clients whose data belongs to a different modality, even when their data shares substantial high-level knowledge with the target modality. For instance, a hospital with only medical transcription data cannot participate in an FL system training medical image classifiers, losing valuable cross-modal information."

**P2 — Existing FMML requires multi-modal clients (Revised, gap-focused):**
"Recent work on multi-modal FL [Yu et al., 2023; Xiong et al., 2022; Feng et al., 2023] aims to improve multi-modal task performance such as image-text retrieval. These methods fundamentally require multi-modal clients — clients with aligned data from multiple modalities — because cross-modal alignment must happen locally under FL privacy constraints. This design excludes uni-modal clients and assumes the availability of aligned multi-modal data, which is often harder to collect than uni-modal data. We term this line of work Federated Multi-Modal Learning (FMML, Figure 1a)."

**P3 — MCFL: a new setting for uni-modal client collaboration (New):**
"To address this limitation, we propose Modality-Collaborated Federated Learning (MCFL), a setting where clients are restricted to data from a single modality, and the goal is to improve per-modality performance for all participants through cross-modal knowledge sharing (Figure 1b). MCFL eliminates the need for multi-modal clients or aligned data, making it applicable to scenarios such as cross-hospital collaboration where each institution holds different types of uni-modal data."

**P4 — Challenges and proposed approach (Revised):**
"MCFL introduces two technical challenges: model heterogeneity (different modalities use different architectures) and the modality gap (shared parameters can become biased toward one modality). We address the first using a modality-agnostic transformer (MAT) that supports a shared architecture across modalities. However, as we show empirically (Section 4), naive MAT aggregation causes severe modality bias. To overcome this, we decompose the problem into three design dimensions — parameter sharing, aggregation, and round scheduling — and systematically identify optimal strategies, leading to our FedCola framework."

**P5 — Contributions (Revised, 3 items):**
"Contributions: (1) New setting — MCFL for uni-modal client collaboration across modalities. (2) New framework — FedCola, combining cross-modal attention sharing, modality compensation, and modality warm-up. (3) Empirical demonstration that multi-modal knowledge can be obtained by aggregating parameters from uni-modal data, outperforming adapted baselines across multiple FL scenarios without extra cost."

### Comparison Criteria
| Check | Current | Recommended |
|---|---|---|
| Problem alignment | Good (gap identified) | Better (faster entry to problem) |
| Variable alignment | Adequate (MCFL defined) | Same |
| Contribution-evidence alignment | Good (claims match results) | Better (removes redundant performance claim) |
| Reader engagement | Slow start (FL basics) | Fast start (problem-first) |
| Conciseness | Verbose opening | Tighter opening |

## Priority Revision Plan
### P0 — Critical (Must fix before resubmission)

| Priority | Issue | Location | Action | Expected Benefit |
|---|---|---|---|---|
| P0.1 | Incomplete limitations | Page 18 (App. H) | Expand to cover modality/task scope, architecture assumption, privacy analysis gap | Increases scientific integrity and preempts reviewer criticism |
| P0.2 | Overclaimed abstract/conclusion | Pages 1, 9 | Replace promotional language with bounded factual claims | Strengthens credibility and defensibility |
| P0.3 | Tenuous Rademacher argument | Page 6 (Section 5.2) | Reframe as empirical motivation with theoretical reference as supporting context only | Removes misleading theoretical overextension |

### P1 — Major (Should fix before resubmission)

| Priority | Issue | Location | Action | Expected Benefit |
|---|---|---|---|---|
| P1.1 | Verification architecture mismatch | Page 9 (Section 7) | Add caveat about scratch-trained vs. pre-trained model; optionally reproduce with pre-trained ViT for verification | Ensures collaboration evidence is valid for main experimental setting |
| P1.2 | Contribution list redundancy | Page 3 | Merge "Better Performance" (item 3) into framework contribution (item 2); rephrase "New outlook" as empirical finding | Cleaner, more defensible contribution list |
| P1.3 | Slow introduction opening | Page 1 (Section 1, P1) | Condense FL basics into one sentence; move directly to uni-modal limitation and motivating example | Faster reader entry to research problem |

### P2 — Nice-to-have (Quality improvement)

| Priority | Issue | Location | Action | Expected Benefit |
|---|---|---|---|---|
| P2.1 | Evaluation metric limitation | Page 7 (Section 6.1) | Add min-over-modalities metric or report per-modality deltas | Prevents the average from masking modality stagnation |
| P2.2 | Modality bias analysis | Page 5 (Section 4.1) | Add gradient-norm analysis to diagnose why Vanilla MAT fails | Strengthens motivation for proposed solutions |
| P2.3 | Ablation attribution | Page 9 (Section 7) | Explicitly state AS as dominant contribution (+26.93%), MC/MW as minor refinements | Sets accurate reader expectations |
| P2.4 | Heat Distribution stage analysis | Page 7 (Table 3) | Add explanation for why HD helps on medical but hurts on general-domain datasets | Provides deeper insight into the method's behavior |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective/Hypothesis | Setup (Data/Split/Protocol/Baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Vanilla MAT baseline evaluation | CIFAR-100+AGNEWS, Nv=Nl=4, α=0.5, r=0.5; compare Uni-FedAVG vs MAT | Img Acc, Txt Acc, Avg Acc | MAT causes vision collapse (3.58%) due to modality bias | Setting is non-trivial (Motivation) | Only one dataset pair tested; bias diagnosis at aggregation level only |
| E2 | Parameter-sharing strategies (RQ1) | Same as E1; compare None/All/Attn/FFN/VisionOnly/LangOnly sharing | Img Acc, Txt Acc, Avg Acc | Attention Sharing best (72.92% avg) | RQ1 answered: share attention layers | Only 4 strategies tested; ablation covers FFN vs Attn only |
| E3 | Cross-modal aggregation (RQ2) | Same as E1; compare w/ and w/o Modality Compensation | Img Acc, Txt Acc, Avg Acc | MC adds +0.51% avg | RQ2 answered: MC fixes layer misalignment | Gain is small; theory justification is weak |
| E4 | Temporal modality arrangement (RQ3) | Same as E1 + OrganAMNIST+MTSamples; compare Vision/Lang warm-up ± HD | Img Acc, Txt Acc, Avg Acc | Vision warm-up best; HD helps medical domain only | RQ3 answered: warm-up helps | HD improvement is inconsistent across domains |
| E5 | Full FedCola vs baselines | 2 dataset pairs, 2 client counts (4/16), 3 data settings (α=0.5/0.1, r=0.5/0.25); compare Uni-FedAVG, CreamFL, FedCola | Img Acc, Txt Acc, Avg Acc | FedCola consistently best (Avg +3-10% over baselines) | C1 (new setting feasible), C2 (FedCola effective) | No statistical significance tests; single seed per setting |
| E6 | Resource analysis | Nv=Nl=16, r=0.25; compute comm. and comp. per round | Communication (GB), Computation (GFLOPs) | FedCola = Uni-FedAVG cost; CreamFL 1.97x computation | FedCola is cost-efficient | Only one configuration analyzed |
| E7 | Collaboration verification | Scratch-trained 7-layer transformer; vary patch size (2-8) and token length (20-60) | Img Acc, Txt Acc | Positive cross-modal correlation | FedCola enables cross-modal transfer | Architecture mismatch with main experiments |
| E8 | Imbalanced client scenarios | α=0.1, r=0.25, Nv=16/Nl=4 and Nv=4/Nl=16 | Img Acc, Txt Acc, Avg Acc | FedCola outperforms baselines under imbalance | Robustness to client imbalance | Limited to one heterogeneity setting |

### Research-Theme Gap Diagnosis

1. **New knowledge gap (partially addressed):** The paper contributes a new problem setting (MCFL) and empirical design insights. However, the relative novelty of each technique (attention sharing in FL, modality warm-up) versus existing centralized multi-modal work is not quantified. The core insight — that attention sharing works best — is well-supported but may be partially overlapping with VLMo [Bao et al., 2022] and model merging [Sung et al., 2023] insights.

2. **Reproducibility gap (partially addressed):** Hyperparameters, model architecture, and data partitioning are described. However, critical details are only in the appendix (Algorithm 1, implementation details). Single-seed reporting (no variance) limits reproducibility confidence.

3. **Impact on practice/understanding gap (partially addressed):** The practical relevance of MCFL is well-motivated. The demonstration that modality collaboration can be achieved through parameter sharing (not feature alignment) is a noteworthy conceptual contribution. However, the restriction to two modalities and classification tasks limits the breadth of this impact claim.

### Proposed Research Experiments (P0/P1/P2)

**P0 Experiment — Statistical significance testing**
- **Target Claim:** FedCola outperforms baselines.
- **Hypothesis:** Observed gains are statistically significant.
- **Minimal Design:** Run each setting (Table 4) with 3-5 random seeds; report mean and std; perform paired t-test between FedCola and best baseline.
- **Controls:** Same seed list for all methods.
- **Metrics:** Avg Acc mean±std, p-value.
- **Success Criterion:** Gains > 1% are significant at p<0.05.
- **Estimated Cost/Time:** 3-5x current compute (30-50 GPU-hours).
- **Expected Paper-Quality Gain:** Substantially increases reviewer confidence in reported improvements.

**P1 Experiment — Cross-modal transfer verification with pre-trained model**
- **Target Claim:** FedCola enables cross-modal knowledge transfer (Section 7).
- **Hypothesis:** The positive correlation holds under the pre-trained ViT-Small setting.
- **Minimal Design:** Vary image patch size (4, 8, 16) under pre-trained ViT-Small with FedCola; measure vision accuracy impact on language accuracy.
- **Controls:** Keep all other hyperparameters identical to main experiments.
- **Metrics:** Language accuracy change per patch size.
- **Success Criterion:** Positive correlation (or at least no negative correlation) between vision capability and language accuracy.
- **Estimated Cost/Time:** ~10 GPU-hours (3 runs × different patch sizes).
- **Expected Paper-Quality Gain:** Validates the collaboration evidence for the actual experimental configuration.

**P2 Experiment — Modality bias diagnosis**
- **Target Claim:** Vanilla MAT's modality bias originates from learning-level dynamics (Appendix C).
- **Hypothesis:** Language gradients dominate shared attention parameters due to larger batch diversity.
- **Minimal Design:** Under Vanilla MAT training, compute per-modality gradient norms for shared attention parameters after each round; plot ratio over rounds.
- **Controls:** Compare with Attention Sharing strategy to isolate cause.
- **Metrics:** Gradient norm ratio (language/vision) per layer.
- **Success Criterion:** Gradient ratio > 1.5 for shared layers under Vanilla MAT.
- **Estimated Cost/Time:** ~5 GPU-hours (reuse existing training logs).
- **Expected Paper-Quality Gain:** Provides mechanistic understanding of the bias, strengthening the motivation for proposed solutions.

```text
ASCII Diagram — Experiment Upgrade Plan
Stage 1 (P0, before resubmission):
  [Statistical significance testing]
      -> Run 3-5 seeds per Table 4 setting
      -> Report mean±std, p-values
      -> Expected: increases confidence in reported gains

Stage 2 (P1, before resubmission):
  [Cross-modal verification with pre-trained ViT-Small]
      -> Vary patch size, measure language acc impact
      -> Expected: validates collaboration evidence for main setting

Stage 3 (P2, optional quality improvement):
  [Modality bias gradient diagnosis]
      -> Compute per-modality gradient norms
      -> Expected: provides mechanistic insight into Vanilla MAT failure
```

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score: 5.5/10** — Evidence-grounded assessment prioritizing research value, novelty, and validity.

**Rationale:**
- **Research value (7/10):** The MCFL setting is well-motivated and practically relevant. The systematic design-space exploration (parameter sharing, aggregation, scheduling) is methodologically sound and provides reusable insights. The paper makes a clear contribution in identifying and partially solving a real problem.
- **Novelty (N/A — deferred):** External literature verification is unavailable in this run. The MCFL setting appears to be a genuine new problem formulation, but the extent to which individual techniques overlap with existing work (VLMo-style attention sharing, model merging) cannot be assessed without retrieval. **Deferred for manual verification.**
- **Validity/Soundness (5/10):** The experimental evaluation is comprehensive but has notable concerns: (a) the theoretical justification for modality compensation overextends a Rademacher bound, (b) the verification experiment uses a mismatched architecture, (c) no statistical significance testing is reported, (d) limitations are under-disclosed. These issues reduce confidence in the reported results.
- **Reproducibility (6/10):** Hyperparameters and implementation details are provided in the appendix, and Algorithm 1 gives a clear pseudocode description. However, single-seed reporting without variance prevents verification of result stability.
- **Presentation/Clarity (6/10):** The paper is clearly written and well-structured. The introduction is slightly verbose in its opening but the problem-solution mapping is clear. The use of figures (pipeline diagrams, ablation tables) is effective. Overclaim in abstract and conclusion detracts from clarity.

**Key factors constraining the score:**
1. Overextension of theoretical argument in the modality compensation section (Issue 1)
2. Incomplete limitations disclosure (Issue 2)
3. Architectural mismatch in verification experiment (Issue 3)
4. Absence of statistical significance testing
5. Overclaim in abstract and conclusion (Issue 4)

**Post-Revision Target: [6.5, 7.5]/10** — If P0 and P1 issues are fully addressed (theoretical reframing, limitations expansion, bounded claims, variance reporting, verification experiment caveat or reproduction), the paper could reach a strong acceptance-level score. The core research idea and experimental design are solid; the main deficits are in scientific framing and evidence transparency, which are fixable.