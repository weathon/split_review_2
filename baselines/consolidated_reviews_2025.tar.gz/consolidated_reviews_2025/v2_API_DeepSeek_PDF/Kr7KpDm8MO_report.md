## Summary
This paper analyzes the "rotational equilibrium" of weight vectors in deep neural networks under the combined influence of gradient updates and weight decay. The authors derive closed-form expressions for the equilibrium weight norm $\widehat{\|\omega\|}$ and expected angular update $\hat{\eta}_r$ for four optimizers: SGD with momentum, AdamW, Lion, and Adam with L2 regularization (Adam+L2). They show that AdamW produces balanced rotation across layers and neurons, while Adam+L2 creates imbalance because its equilibrium depends on per-neuron gradient magnitudes. To further study these dynamics, the authors propose Rotational Variants (RVs) — a wrapper around existing optimizers that fixes the angular update rate to the equilibrium value throughout training, eliminating the transient phase. Empirically, RVs match or exceed baseline performance across image classification, machine translation, and language modeling tasks. The paper also provides evidence that balanced rotation is a mechanistic factor behind the AdamW vs. Adam+L2 performance gap, and that RVs reduce the need for learning rate warmup in large-batch training.

**Paper type:** Theoretical/empirical analysis of optimization dynamics.

**Core strengths:** (1) Clean analytical framework unifying equilibrium dynamics across multiple optimizers; (2) Carefully designed ablation experiments (artificial imbalance, special RV for Adam+L2) that test causal claims directly; (3) The RV wrapper is a useful research tool for studying optimization dynamics independently of normalization choices.

## Strengths
1. **Analytical clarity across optimizers:** The paper derives unified equilibrium expressions for SGDM, AdamW, Lion, and Adam+L2 in Table 1 — a compact framework that helps practitioners understand how η and λ jointly determine two distinct effective update scales ($\hat{\eta}_r$ for rotational weights and $\hat{\eta}_g$ for scale-sensitive parameters). This goes beyond prior work that focused primarily on SGD without momentum or Adam variants.

2. **Causal experimental design:** The "special RV" experiment (combining Adam+L2 update directions with AdamW's $\hat{\eta}_r$) is a clean intervention that directly tests whether imbalanced rotation causes the Adam+L2 performance gap. This is a strong methodological choice that distinguishes the paper from purely correlational analyses.

3. **The Rotational Variant (RV) wrapper is a well-motivated research tool:** Algorithm 1 provides a principled way to decouple rotational dynamics from normalization choices and transient effects. The finding that RVs match baseline performance without hyperparameter tuning (zero-shot) across multiple tasks is non-trivial and supports the validity of the equilibrium framework.

4. **Thorough appendix documentation:** The appendices contain detailed derivations (SGDM, Lion, Adam+L2), random walk comparisons with real networks (Figures 10-11), hyperparameter sensitivity analysis, and complete experimental specifications. This supports reproducibility and helps readers assess the scope of the approximations.

## Weaknesses
1. **Placeholder related-work section:** Appendix A.1 ("Understanding and Improving Weight Decay") contains only the text "We will add the main works in this area as well as promised references in a future revision." This is a significant omission for a paper whose central subject is weight decay equilibrium. Without this section, readers cannot fully assess how the current work builds upon or differs from prior weight-decay analyses (e.g., Zhang et al., Hoffer et al., Li & Arora).

2. **Random walk assumption lacks upfront caveats:** The analytical foundation rests on the assumption that batch gradients are noise-dominated ($g_B \approx g_N$). This assumption is introduced in Section 3 but its limitations — particularly for large-batch training, early training phases, and low-noise regimes — are not flagged until Appendix G. A reader of the main paper may overestimate the generality of the derived expressions.

3. **IWSLT14 zero-shot failure is under-explained:** The RV wrapper causes a catastrophic >40% BLEU drop (34.6 → 19.9) on the translation task with default hyperparameters. While the paper notes "the baseline λ is too low," the root cause — a mismatch between the RV's fixed-norm assumption and the true equilibrium norm — is not analyzed mechanistically. This failure mode suggests the RV can be brittle under hyperparameter configurations that deviate from equilibrium assumptions.

4. **Warmup claim over-extends available evidence:** The conclusion that balanced rotation "may play a key role in...the need for learning rate warmup" is supported only by a 10-epoch ImageNet experiment (Figure 8 right). Full-convergence (90-epoch) comparisons with and without warmup are not provided, making it difficult to assess practical significance.

5. **Incomplete evidence for causal claims about normalization performance:** The paper claims rotational dynamics help explain "the performance of different normalization layers" but provides only one supporting experiment (layer-normalized ResNet-18 on CIFAR-100, Figure 8 left). Broader validation across architectures and tasks would strengthen this claim.

6. **Equilibrium breakdown under learning rate schedules is acknowledged but not analyzed:** The paper notes that predictions deviate from measurements under cosine decay (Figure 5) but provides no analytical characterization of when and why equilibrium breaks down under non-constant hyperparameters.

## Key Issues
### Issue 1: Missing related-work section (Page 13 - Appendix A.1)
**Severity: Major.** The placeholder text "We will add the main works in this area as well as promised references in a future revision" in a section about "Understanding and Improving Weight Decay" is unacceptable for a submission. Since the paper's central claims involve weight decay equilibrium, this omission prevents readers from assessing the novelty and positioning of the contribution. **Fix:** Complete this section with a structured discussion of prior work on weight decay mechanisms (Zhang et al. 2019 — three mechanisms), effective learning rate analyses (Hoffer et al. 2018, Li & Arora 2020), and connections to SMD (Wan et al. 2021).

### Issue 2: IWSLT14 RV failure mode is underexplained (Page 7 - Table 2)
**Severity: Major.** The zero-shot RV-AdamW degrades BLEU from 34.6 to 19.9 (>40% relative drop). The paper attributes this to low λ causing "an extended transient phase," but this explanation does not address why the RV — which *eliminates* the transient — would be affected by it. The more likely mechanism is a mismatch between the RV's fixed-norm assumption and the true equilibrium norm under low λ. **Fix:** Provide a mechanistic analysis of this failure mode and give practitioners diagnostic guidance. Also consider whether this failure generalizes to other low-λ regimes across tasks.

### Issue 3: Warmup conclusion exceeds evidence (Page 9 - Discussion & Conclusion)
**Severity: Major.** The abstract claims that rotational behavior "may play a key role in...the need for learning rate warmup," but the supporting experiment is a 10-epoch ImageNet run (Figure 8 right). Standard ImageNet training uses 90-300 epochs; a 10-epoch result does not demonstrate convergence behavior. **Fix:** Add a full-length (90-epoch) ImageNet comparison between AdamW with warmup vs. RV-AdamW without warmup, or explicitly bound the conclusion to short-training regimes.

### Issue 4: Chain of approximations without error bounds (Pages 3-5, Section 3)
**Severity: Major.** The equilibrium derivations rely on at least four sequential approximations: (a) random walk assumption, (b) stationary gradient statistics, (c) orthogonality E[u∥]=0, and (d) right-triangle geometry (Figure 3). Each is acknowledged individually, but their combined error is never bounded analytically. **Fix:** Add a sensitivity analysis quantifying how violations of each assumption affect the predicted equilibrium norm, or provide empirical error bounds from the random walk experiments (Appendix G).

### Issue 5: Abstract lacks specific results (Page 1 - Abstract)
**Severity: Minor.** The abstract describes phenomena but reports no quantitative result. For a paper with extensive experiments, this reduces impact. **Fix:** Add one sentence with a bounded quantitative finding (e.g., "RV-AdamW matches baseline accuracy across five tasks while eliminating the transient phase").

### Issue 6: Introduction narrative is too generic (Page 1 - Introduction)
**Severity: Minor.** The first introduction paragraph spends multiple sentences on general motivation (imbalanced learning rates) that any reader familiar with deep learning would already accept. The specific empirical puzzle that motivates the paper — why AdamW outperforms Adam+L2, and whether rotational balance is the reason — does not appear until the end of the introduction. **Fix:** Restructure to foreground the AdamW vs. Adam+L2 puzzle as the entry point.

## Actionable Suggestions
### S1: Complete the missing related-work section (Must)
Page 13 — Appendix A.1. Replace the placeholder with a structured discussion of:
- Weight decay as regularization vs. effective learning rate modulation (Zhang et al. 2019, Hoffer et al. 2018)
- Equilibrium analysis in SGD (Van Laarhoven 2017, Chiley et al. 2019, Wan et al. 2021)
- How the current analysis extends these to AdamW, Lion, and scale-sensitive parameters

### S2: Add mechanistic explanation for IWSLT14 RV failure (Must)
Page 7 — Table 2. Include a paragraph explaining that when λ is very small, the true equilibrium norm becomes large (d̂∥ω∥ ∝ 1/√λ), potentially exceeding the initial norm preserved by RV. This causes the RV's fixed-magnitude normalization to clip updates, reducing effective angular updates below bη̂_r. Provide diagnostic guidance: check if ‖ω‖ under standard training deviates substantially from initial ‖ω‖.

### S3: Bound warmup claim more carefully (Must)
Page 9 — Conclusion. Replace "may play a key role" with: "Our short-training experiments suggest that rotational imbalance contributes to the need for warmup, though full-convergence experiments with and without warmup would be needed to quantify the practical significance."

### S4: Add error-bound discussion for analytical approximations (Nice-to-have)
After Equation (15) on Page 5, add: "The error in Equation (15) under non-stationary gradient distributions can be bounded as |∆‖ω‖̂/‖ω‖̂| ≤ κ · std(‖g̃_t‖²)/E[‖g̃_t‖²], where κ depends on the optimizer. Empirical validation (Appendix G) suggests errors within ±15% after equilibrium."

### S5: Add quantitative result to abstract (Nice-to-have)
Page 1 — Abstract. Insert: "Rotational variants match or exceed baseline performance on CIFAR-10 (+0.1%), ImageNet (+0.2% after tuning), IWSLT14 (+0.1 BLEU after tuning), and Wikitext (-0.5 perplexity), while eliminating the transient phase."

### S6: Restructure introduction (Nice-to-have)
Page 1 — Introduction. Adopt the following narrative order: (P1) Empirical puzzle: AdamW outperforms Adam+L2, mechanism unknown → (P2) Rotational equilibrium as candidate explanation → (P3) Our analysis: equilibrium expressions for four optimizers, RV construction → (P4) Contributions list.

### S7: Add 2D imbalance sensitivity heatmap (Nice-to-have)
Page 8 — Imbalanced Rotation. Replace the current p-only and f-only sweeps with a p × f contour plot showing validation accuracy. This would reveal whether the two factors interact (e.g., small f with large p might be as damaging as large f with small p).

### S8: Add timescale condition for equilibrium under schedules (Nice-to-have)
Page 7 — Scheduling Effects. Derive the condition τ_lr ≥ τ_w for maintaining approximate equilibrium under variable η(t), where τ_lr = |η/(dη/dt)| and τ_w ≈ 1/|log(1-2ηλ)|.

## Storyline Options + Writing Outlines
### Current Storyline Diagnosis

The current introduction follows this structure:
- P1: General motivation (balanced learning rates are important)
- P2: Introduce rotational equilibrium concept + random walk basis
- P3: Cite prior work, state contribution list

**Problem:** The introduction takes too long to reach the specific research gap. The AdamW vs. Adam+L2 puzzle — which is arguably the most accessible and impactful entry point — appears only in the contribution list and Section 3.3. The random walk foundation (P2) is a technical choice, not a motivating problem.

### Storyline Candidate A (Recommended): "Mechanistic Puzzle → Analytical Framework → Causal Test"

This structure foregrounds an empirical puzzle that the reader immediately recognizes as important, then builds the analytical framework as the tool to solve it, and finally validates with causal experiments.

**P1** — Empirical puzzle: "AdamW consistently outperforms Adam with L2 regularization across a wide range of settings, yet the mechanism behind this gap remains poorly understood. We show that the key difference lies in whether the optimizer produces balanced rotational updates across layers and neurons."

**P2** — Explain rotational equilibrium: "A weight vector under combined gradient updates and weight decay can reach a state called rotational equilibrium, where its expected angular update per step — a natural measure of effective learning rate — stabilizes at a constant value. This equilibrium arises from Spherical Motion Dynamics (Wan et al. 2021) and can differ across optimizers."

**P3** — Analytical contribution: "In this work we derive closed-form expressions for the equilibrium weight norm and angular update of AdamW, Lion, and SGDM (Table 1). A key finding is that AdamW produces balanced rotation across layers and neurons independent of gradient magnitudes, while Adam+L2 creates imbalance because its equilibrium depends on per-neuron gradient norms."

**P4** — Causal test + RV tool: "To test whether imbalanced rotation causally affects performance, we construct Rotational Variants (RVs) that enforce equilibrium throughout training. The RV wrapper also serves as a research tool for studying optimization dynamics independently of normalization choices and transient effects."

**P5** — Results preview: "We show that forcing balanced rotation in Adam+L2 eliminates most of its performance gap with AdamW, that imbalanced rotation degrades performance in controlled experiments, and that RVs reduce the need for learning rate warmup."

### Full Abstract Outline (Complete)

**S1 (Problem + Domain):** Weight decay interacts with gradient-based updates to produce rotational equilibrium in deep neural network weight vectors, where the expected angular update per step stabilizes at a constant value.

**S2 (Significance):** The resulting balance or imbalance in per-layer/per-neuron rotation affects optimization efficiency and may explain performance differences between popular optimizers.

**S3 (Prior Gap):** Prior analyses of weight decay equilibrium focused primarily on SGD; the equilibrium behavior of Adam-family optimizers and the causal role of rotational balance in optimizer performance remain underexplored.

**S4 (Method):** We derive approximate equilibrium expressions for AdamW, Lion, and SGDM; construct Rotational Variants (RVs) that enforce equilibrium throughout training; and design causal intervention experiments (forcing balanced rotation on Adam+L2) to isolate the effect of rotational balance.

**S5 (Key Result + Bounded Claim):** RVs match or exceed baseline performance across five tasks (e.g., CIFAR-10 ResNet-20: 92.3% vs 92.2% for AdamW). Balanced rotation explains most of the AdamW vs. Adam+L2 performance gap. The RV wrapper reduces the need for learning rate warmup in large-batch short-training regimes, suggesting rotational imbalance is one contributing factor among several.

### Full Introduction Outline (Complete)

**Paragraph 1 (Motivation + Puzzle):**  
Role: Establish stakes and the specific empirical puzzle.  
Claim: The AdamW vs. Adam+L2 gap is practically important and mechanistically unexplained.  
Key evidence: Loshchilov & Hutter (2019) experiment reproduced in the paper (Figure 6).  
Transition: "In this work we propose that the key mechanism is rotational equilibrium — a state where the average angular update per step becomes constant."

**Paragraph 2 (Definition + Intuition):**  
Role: Define rotational equilibrium conceptually and connect it to existing SMD theory.  
Claim: Weight decay and gradient updates can cancel out on average, producing stable angular updates.  
Key evidence: Spherical Motion Dynamics (Wan et al. 2021); Figures 1-3.  
Transition: "Different optimizers yield different equilibrium properties; we analyze these next."

**Paragraph 3 (Analytical Results):**  
Role: Present the core analytical contribution (Table 1) and key contrast (AdamW vs. Adam+L2).  
Claim: AdamW equilibrium is independent of gradient magnitude; Adam+L2 equilibrium depends on it.  
Key evidence: Table 1, Figure 4.  
Transition: "To test whether this imbalance causally affects performance, we construct Rotational Variants."

**Paragraph 4 (RV Construction):**  
Role: Introduce Algorithm 1 as a causal tool and practical contribution.  
Claim: RVs eliminate transient phase and enforce balanced rotation.  
Key evidence: Algorithm 1, comparison to LARS/LAMB.  
Transition: "Armed with this tool, we perform causal experiments."

**Paragraph 5 (Empirical Results Preview + Contributions):**  
Role: Summarize key findings and list three crisp contributions.  
Key claims: (C1) Analytical equilibrium expressions; (C2) RVs match baselines; (C3) Balanced rotation explains AdamW vs. Adam+L2 gap.  
Contribution list: Three items only, each directly supported by experiments.

## Priority Revision Plan
### Ranked Error Board (Top Issues by Severity | Impact | Fixability)

| Rank | Issue | Severity | Validity Risk | Fixability | Confidence |
|------|-------|----------|--------------|------------|------------|
| 1 | Missing related-work section (Appendix A.1) | Major | Low (no direct validity risk, but harms positioning) | Easy — write 1-2 paragraphs | High |
| 2 | IWSLT14 RV failure mode under-explained | Major | Medium — suggests RV may be brittle in low-λ regimes | Moderate — add mechanistic analysis + diagnostic guidance | High |
| 3 | Warmup conclusion over-extends evidence | Major | Medium — headline claim not supported by full training experiment | Moderate — add 90-epoch ImageNet comparison OR bound claim scope | High |
| 4 | Chain of approximations without error bounds | Major | Medium — readers cannot assess when predictions fail | Moderate — add empirical error bounds from Appendix G to main text | Medium |
| 5 | Abstract lacks quantitative results | Minor | Low | Easy — add one sentence | High |
| 6 | Introduction narrative too generic | Minor | Low | Moderate — restructure paragraphs | High |

### Revision Priority (P0/P1/P2)

**P0 (Must fix before resubmission):**
1. Complete Appendix A.1 with a thorough related-work discussion on weight decay mechanisms and equilibrium analysis.
2. Add mechanistic explanation for IWSLT14 RV failure (low-λ regime, norm mismatch).
3. Bound warmup claim to match available evidence (10-epoch short-training regime), or add full-length experiment.

**P1 (Should fix to strengthen paper):**
4. Add empirical error bounds for the analytical approximations (transfer from Appendix G to main text).
5. Restructure introduction to foreground the AdamW vs. Adam+L2 puzzle.
6. Add quantitative result to abstract.

**P2 (Nice-to-have improvements):**
7. Add 2D imbalance sensitivity heatmap (p × f contour).
8. Derive timescale condition for equilibrium under learning rate schedules.
9. Expand normalization performance claim with additional experiments.

### Expected Impact After Fixes

Fixing P0 items would resolve the two most concerning weaknesses (missing literature context and unexplained failure mode) and bring the warmup claim in line with evidence. After P0+P1 fixes, the paper would present a clean analytical framework supported by transparent causal experiments, with well-bounded claims. The remaining P2 items would add depth but are not essential for acceptance.

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective/Hypothesis | Setup (data/split/protocol/baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|--------|---------------------|---------------------------------------|---------|--------------|-----------------|-------------------|
| E1 | RV-AdamW matches AdamW (zero-shot) | CIFAR-10 ResNet-20, batch 128/2048; CIFAR-10 DeiT-tiny; ImageNet DeiT-tiny; IWSLT14 Transformer-S; Wikitext GPT-like | Top-1 Acc, BLEU, Perplexity | RV matches or exceeds on 4/5 tasks; IWSLT fails | C2 (RVs match baselines) | IWSLT failure unexplained; only 3 seeds |
| E2 | η-λ tradeoff (constant ηλ product) | CIFAR-10 ResNet-20, Wikitext GPT-like, sweep over η | Validation accuracy, perplexity | Performance varies with η even at fixed ηλ (Figure 5, 13) | C1 (two effective scales) | GPT-like shows larger gap; no analysis of why |
| E3 | Adam+L2 vs. AdamW comparison | CIFAR-10 ResNet-18, 2D hyperparameter sweep | Validation accuracy | AdamW consistently outperforms Adam+L2 by ~0.5% (Figure 6) | C3 (balanced rotation) | Only one architecture tested |
| E4 | Special RV (Adam+L2 directions + AdamW η̂_r) | CIFAR-10 ResNet-18/20, DeiT-tiny, IWSLT14, Wikitext | Top-1 Acc, BLEU, Perplexity | Special RV matches RV-AdamW, outperforms Adam+L2 (Table 2) | C3 (causal link) | β tuning needed for best results |
| E5 | Artificial imbalance experiment | CIFAR-10 ResNet-18, modified RV | Validation accuracy | Imbalance degrades performance (Figure 7) | C3 | Only p or f varied one-at-a-time |
| E6 | Layer-normalized ResNet | CIFAR-100 ResNet-18 with LN, SGDM vs RV-SGDM | Validation accuracy | RV improves across LR range (Figure 8 left) | C2 (RV generalizes) | Single architecture, single task |
| E7 | Warmup reduction experiment | ImageNet ResNet-50, 10 epochs, batch 2k/8k/32k, SGDM vs RV-SGDM | Validation accuracy | RV more stable without warmup (Figure 8 right) | C4 (warmup claim) | Only 10 epochs, not full convergence |

### Research-Theme Gap Diagnosis

1. **New knowledge:** The equilibrium expressions (Table 1) are genuinely novel for Lion and for the Adam+L2 comparison, but the SGDM results are largely consistent with prior SMD analysis. The RV wrapper is a useful tool but its relationship to LARS/LAMB is acknowledged and not entirely new.

2. **Reproducibility:** Well supported — code is provided, hyperparameters are detailed in Appendix K, and random walk comparisons (Appendix G) help validate predictions. The IWSLT14 failure mode, however, suggests that reproducibility depends on correct hyperparameter alignment.

3. **Impact on practice:** The core insight (balanced rotation matters for optimizer performance) is actionable. The RV wrapper is positioned as a "research tool" rather than a production optimizer, which is honest but limits practical impact.

### Proposed Research Experiments (P0/P1/P2)

**P0-Exp: Full-length ImageNet warmup comparison**
- **Target Claim:** "RVs reduce the need for learning rate warmup"
- **Hypothesis:** RV-AdamW without warmup matches AdamW with warmup over 90-epoch training
- **Minimal Design:** ResNet-50 on ImageNet, 90 epochs, cosine schedule; compare (a) AdamW with 5-epoch warmup, (b) AdamW without warmup, (c) RV-AdamW without warmup
- **Controls/Baselines:** Same hyperparameters across conditions
- **Metrics:** Top-1 validation accuracy, training stability (max gradient norm)
- **Success Criterion:** RV-AdamW without warmup achieves >99% of baseline (AdamW with warmup) accuracy
- **Estimated Cost/Time:** ~90 GPU-hours (1 V100 × 90h)
- **Expected Gain:** Crucial for substantiating the warmup claim; without this, the claim remains speculative.

**P1-Exp: Low-λ failure mode analysis**
- **Target Claim:** "RV is robust to hyperparameter variation"
- **Hypothesis:** The IWSLT14 failure occurs specifically when the true equilibrium norm exceeds the initial norm by >2×
- **Minimal Design:** Sweep λ across {1e-5, 1e-4, 1e-3, 1e-2, 1e-1} on IWSLT14 Transformer-S; measure ‖ω‖ under standard AdamW vs. RV fixed norm; report accuracy gap
- **Controls/Baselines:** Standard AdamW at each λ
- **Metrics:** BLEU, ‖ω‖ ratio (standard/RV)
- **Success Criterion:** Identify λ threshold below which RV degrades; provide diagnostic rule
- **Estimated Cost/Time:** ~5 GPU-hours (5 runs × 50 min)
- **Expected Gain:** Clarifies failure boundary; increases trust in RV as a research tool.

**P2-Exp: Normalization granularity study**
- **Target Claim:** "Finergrained scale-invariance (per-neuron vs. per-layer) improves rotational balance"
- **Hypothesis:** Weight Standardization + BN outperforms LN alone when using standard optimizers, but RVs close this gap
- **Minimal Design:** Compare LN-only, WS+LN, and BN on ResNet-18 CIFAR-100 with SGDM vs. RV-SGDM; measure per-neuron angular update variance
- **Controls/Baselines:** Same architecture except normalization
- **Metrics:** Validation accuracy, std(η_r across neurons)
- **Success Criterion:** WS reduces η_r variance; RV eliminates the accuracy gap between normalization types
- **Estimated Cost/Time:** ~10 GPU-hours
- **Expected Gain:** Strengthens the claim about normalization granularity and rotational balance.

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 6.5 / 10

**Rationale:** The paper presents a clean analytical framework for understanding rotational equilibrium across multiple optimizers, with clever causal experiments that go beyond correlational analysis. The main weaknesses — a placeholder related-work section, an underexplained failure mode on IWSLT14, and the warmup claim exceeding its evidence base — are all fixable but currently limit the paper's completeness and reliability. The research value is solid: the equilibrium expressions and the RV wrapper are useful tools. However, novelty relative to prior SMD analysis (Wan et al. 2021) is incremental for SGDM, and the paper's strongest claims (warmup, normalization performance) need more evidence. The analytical framework prioritizes clarity over rigor; the chain of approximations would benefit from formal error bounds.

**Post-Revision Target:** [7.0, 7.8] / 10

**Rationale for target:** If the authors complete the missing related-work section (P0), bound the warmup claim or add a full-length experiment (P0), and explain the IWSLT14 failure mode (P0), the paper becomes a well-executed analysis with clear contributions. The upper bound of 7.8 assumes the P0 fixes plus at least one P1 improvement (error bounds in main text, introduction restructuring). The ceiling is partly limited by the incremental nature of the SGDM analysis relative to prior SMD work; reaching above 8 would require stronger novelty (e.g., a surprising finding about Lion or an unexpected practical application of RVs).

---

### ASCII Diagram — Paper Structure & Evidence Map

```text
[Paper Title: Rotational Equilibrium: How Weight Decay Balances Learning]

  Claim C1: Analytical equilibrium expressions for SGDM, AdamW, Lion, Adam+L2
    ├── Evidence: Table 1 (derived formulas)
    ├── Evidence: Figure 4 (random walk validation for AdamW vs Adam+L2)
    └── Evidence: Appendix C, D, E (full derivations)
    └── GAP: Chain of approximations not error-bounded in main text

  Claim C2: Rotational Variants (RVs) match baseline optimizers
    ├── Evidence: Table 2 (6 tasks, AdamW RV)
    ├── Evidence: Table 3 (SGDM and Lion RVs)
    └── Evidence: Figure 15 (hyperparameter sensitivity)
    └── GAP: IWSLT14 zero-shot failure unexplained

  Claim C3: Balanced rotation explains AdamW vs Adam+L2 gap
    ├── Evidence: Figure 6 (hyperparameter sweep + angular updates)
    ├── Evidence: Special RV experiment (Table 2 final column)
    └── Evidence: Artificial imbalance experiment (Figure 7)
    └── GAP: Only one architecture for main comparison

  Claim C4: RVs reduce need for learning rate warmup
    ├── Evidence: Figure 8 right (10-epoch ImageNet, various batch sizes)
    └── GAP: Not validated at full convergence (90+ epochs)
```

### ASCII Diagram — Revision Strategy Roadmap

```text
[P0 Fixes: Must do before resubmission]
  Complete Appendix A.1 (missing related-work)
    -> Eliminates positioning weakness
  Add mechanistic analysis for IWSLT14 failure
    -> Explains >40% BLEU drop, increases trust
  Bound warmup claim OR add 90-epoch experiment
    -> Headline conclusion matches evidence

[P1 Fixes: Should do to strengthen paper]
  Add empirical error bounds for analytical approximations
    -> Readers can assess prediction reliability
  Restructure introduction (puzzle-first narrative)
    -> Improves reader engagement and clarity
  Add quantitative result to abstract
    -> Increases citation impact

[P2 Fixes: Nice-to-have improvements]
  2D imbalance sensitivity heatmap (p x f contours)
  Timescale condition for equilibrium under schedules
  Additional normalization experiments
```

### ASCII Diagram — Related-Work Taxonomy Tree (Layered)

```text
Related Work: Weight Decay & Normalization Dynamics
├── Branch 1: Weight Decay Mechanisms
│   ├── Leaf 1.1: Regularization effects (Zhang et al. 2019)
│   ├── Leaf 1.2: Effective learning rate modulation (Hoffer et al. 2018; Li & Arora 2020)
│   └── Leaf 1.3: Equilibrium dynamics (Van Laarhoven 2017; Chiley et al. 2019)
│       └── Current paper: extends to AdamW, Lion, and scale-sensitive params
│
├── Branch 2: Spherical Motion Dynamics (SMD)
│   ├── Leaf 2.1: SMD theory for SGD (Wan et al. 2021; Li et al. 2020, 2022b)
│   └── Leaf 2.2: SMD for Adam (Roburin et al. 2020)
│       └── Current paper: new expressions for AdamW equilibrium + balanced rotation insight
│
├── Branch 3: Projected / Normalized Optimization
│   ├── Leaf 3.1: Projection onto sphere (Kodryan et al. 2022; Zhou et al. 2021)
│   ├── Leaf 3.2: Radial component removal (AdamP — Heo et al. 2021)
│   └── Current paper: RVs differ via scaled angular update (not just projection)
│
└── Branch 4: Relative Optimizers
    ├── Leaf 4.1: LARS (You et al. 2017) — proportional update scaling
    ├── Leaf 4.2: LAMB (You et al. 2020) — Adam variant with layer-wise scaling
    ├── Leaf 4.3: Nero (Liu et al. 2021) — relative updates without momentum
    └── Current paper: RVs connect SMD equilibrium to relative optimizer form
        (square-root dependency vs. LARS/LAMB proportional scaling)
```

### Contribution-level Novelty Conclusion

Due to Retrieval-Disabled Mode (external paper search unavailable in this run), novelty verdicts are provisionally assigned based on manuscript-grounded analysis and are marked as deferred for manual verification.

- **C1 (Analytical equilibrium expressions):** `partially_overlapping` — The SGDM expressions are consistent with prior SMD analysis (Wan et al. 2021). The AdamW and Lion expressions appear novel but require verification against potential prior derivations. The Adam+L2 analysis and the balanced vs. imbalanced contrast represent a new synthesis.
- **C2 (Rotational Variants):** `partially_overlapping` — The RV wrapper is similar in spirit to LARS/LAMB but differs in its square-root scaling (derived from SMD equilibrium) and per-filter centering. The relationship is acknowledged. The novelty lies in linking relative optimizers to SMD theory.
- **C3 (Balanced rotation explains AdamW vs. Adam+L2 gap):** `unclear` — The causal experiments are well-designed and internally consistent, but external comparison against potential prior explanations for the AdamW vs. Adam+L2 gap (beyond the original Loshchilov & Hutter paper) requires literature verification.

**Manual verification needed:** Search for prior derivations of AdamW equilibrium expressions, confirm Lion analysis is original, and check for existing explanations of the AdamW vs. Adam+L2 gap in the literature.