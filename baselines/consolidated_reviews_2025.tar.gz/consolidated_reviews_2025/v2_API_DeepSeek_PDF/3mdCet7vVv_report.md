## Summary
# Final Review Report

## Summary

This paper presents MAESTRO, a framework for trainable low-rank decomposition of Deep Neural Networks (DNNs). The core idea is to factorize each layer's weight matrix as W^i = U^i V^{i⊤} and apply a generalized variant of Ordered Dropout (OD) directly on the decomposed factors, combined with hierarchical group-lasso (HGL) directly on the decomposed factors, combined with hierarchical group-lasso (HGL) regularization to progressively prune redundant ranks during training. This replaces the standard practice of applying SVD-based decomposition either post-training or periodically during training.

The paper makes three key claims: (C1) a novel layer decomposition technique that fuses factorization with Ordered Dropout and HGL for progressive low-rank training; (C2) theoretical guarantees showing MAESTRO recovers SVD for linear mappings under uniform data and PCA for identity mappings; and (C3) empirical demonstrations across multiple architectures (FC, CNN, Transformer) and modalities (image classification, translation) showing competitive or better accuracy versus SVD-based baselines at lower computational cost.

**Strengths:** The idea of embedding Ordered Dropout into factorized weights is technically interesting and addresses a real limitation of SVD-based methods (computational cost, data-agnostic decomposition). The theoretical connection to PCA/SVD under linear assumptions provides a principled foundation. The evaluation covers diverse architectures and datasets.

**Key Weaknesses:** (1) The theoretical guarantees only hold for linear mappings—the DNN extension relies on an unproven sampling heuristic; (2) The baseline comparisons are not fully controlled (unmatched parameter budgets, missing variance for competitors); (3) The layer independence assumption ignores error propagation across layers; (4) The conclusion overclaims relative to evidence; (5) Related work is organized as dense citation lists rather than comparison-driven analysis.

**Novelty/Comparison Note:** External literature retrieval was unavailable in this run. All novelty and comparative positioning claims in this report are deferred for manual verification. The assessment below is based solely on manuscript-internal evidence.

## Strengths
1. **Technically Interesting Core Idea:** Embedding Ordered Dropout directly into factorized weight matrices is a conceptually clean way to learn rank importance during training. The fusion of factorization (U^i V^{i⊤}) with stochastic rank sampling and HGL regularization is well-motivated and addresses a genuine limitation of SVD-based methods, which require a priori rank selection or periodic expensive recomputation.

2. **Theoretical Grounding for Simplified Settings:** Theorem 4.1 connecting MAESTRO's objective to PCA on transformed data (and recovering SVD under uniform data) provides a principled foundation. Even though it only covers linear mappings, this gives readers confidence that the method has sensible limiting behavior.

3. **Broad Empirical Coverage:** The experiments span three architecture families (fully-connected via LeNet, CNN via ResNet-18/VGG-19, Transformer for translation) across four datasets (MNIST, CIFAR-10, Tiny ImageNet, Multi30k). This breadth strengthens the claim of general applicability. The ablation study (Table 4) cleanly isolates the effects of HGL and progressive shrinking.

4. **Practical Deployment Perspective:** The "train-once, deploy-everywhere" mechanism (Section 3.4) and the accuracy-latency trade-off analysis (Section 5.5) address real-world deployment constraints. The ability to extract multiple footprint models from a single training run without fine-tuning is practically valuable.

5. **Reproducibility Infrastructure:** The paper provides Algorithm 1 (complete pseudocode), lists hyperparameter ranges (λ_gl, ε_ps), and specifies software/hardware (PyTorch, A100 GPUs). Training dynamics plots (Figure 3) give insight into convergence behavior.

## Weaknesses
1. **Theoretical-Practice Gap (Major):** The paper's theoretical guarantees (Section 4) only cover linear mappings with specific data distributions. The core training efficiency mechanism—sampling one rank per forward pass—is explicitly acknowledged as "unclear" whether it holds for the DNN objective (Eq 4). The paper relies on empirical observation without convergence analysis. This gap is underplayed in the narrative-wise.

2. **Baseline Comparison Fairness (Major):** Comparisons in Tables 2-3 use unmatched parameter/MAC budgets (e.g., MAESTRO at 4.08M params vs. Pufferfish at 3.3M params). Some baselines lack variance reporting, making significance unclear (differences as small as +0.02pp). Pruning and quantization baselines lack GMACs, preventing full efficiency comparison.

3. **Layer Independence Assumption (Major):** The Method section states that decompositions across layers "do not directly interact" (Page 4). This ignores error propagation through the forward pass. The nested rank observation in Figure 3b actually hints at global order across layers, partially contradicting the independence claim.

4. **Related Work as Citation List (Moderate):** Related Work (Section 2) reads as dense citation lists without comparison-driven organization. The strongest baselines (Pufferfish, Cuttlefish, FjORD) are mentioned but not systematically compared on technical axes (rank selection strategy, computational overhead, data adaptivity).

5. **Overclaiming in Conclusion (Moderate):** The conclusion states MAESTRO "outperforms competitive compression methods at a lower cost," which over-extends the evidence given unmatched budgets and missing baseline variance. Key limitations (linear-only theory, sampling heuristic, error propagation) are not acknowledged.

6. **Introduction Narrative (Moderate):** The introduction's opening paragraph is generically about DL growth rather than specifically about the low-rank decomposition challenge. The transition paragraph announcing the solution uses "non-trivially extend" without concretely explaining what makes the extension non-trivial.

7. **Ablation Study Incomplete (Minor):** The "w/out GL" ablation removes HGL but also increases capacity to 11.2M params (full rank), confounding regularization with capacity change. The "w/ full-training" ablation shows overlapping confidence intervals, not clear evidence that sampling is equally effective.

8. **Theorem Presentation Too Thin (Minor):** Theorem 4.1 is stated informally without proof sketch, without stating precise assumptions beyond a brief mention of uniform data. The formal version is deferred to an appendix not included in the provided pages.

## Key Issues
### Issue 1: Sampling Heuristic Without DNN Convergence Guarantee (Major)
**Location:** Page 5 - "Efficient training via sampling" paragraph
**Problem:** The paper's central training efficiency mechanism—sampling one rank per forward pass—is theoretically justified only for linear mappings (Eq 3). For the DNN objective (Eq 4), the authors explicitly state "it is unclear whether this property still holds." Despite this, the method is presented as a core contribution without adequate caveat.
**Risk:** If sampling does not preserve the optimization landscape, the trained model may converge to a suboptimal solution, or the rank ordering may be unreliable.
**Required Fix:** Add a dedicated limitations paragraph acknowledging this gap. Provide controlled experiments comparing (a) full-rank training, (b) single-rank sampling, and (c) multi-rank sampling for convergence speed and final accuracy.

### Issue 2: Uncontrolled Baseline Comparisons (Major)
**Location:** Page 7-8 - Section 5.2 Performance Comparison
**Problem:** Baseline comparisons use unmatched parameter/MAC budgets (MAESTRO 4.08M vs. Pufferfish 3.3M params). Some baselines lack variance. GMACs missing for pruning/quantization methods.
**Risk:** Claims of superiority are not statistically validated. At exactly matched budgets, rankings could change.
**Required Fix:** Add matched-budget comparisons (interpolated rank configurations). Report variance for all baselines.

### Issue 3: Layer Independence Ignoring Error Propagation (Major)
**Location:** Page 4 - DNN low-rank approximation paragraph
**Problem:** The statement that decompositions "do not directly interact" across layers ignores that errors from low-rank approximation in earlier layers propagate through the forward pass.
**Risk:** Per-layer independent rank selection may be globally suboptimal. The nested rank observation (Figure 3b) hints at global structure that contradicts this claim.
**Required Fix:** Qualify the claim and add analysis of inter-layer error propagation effects.

### Issue 4: Conclusion Overclaim (Moderate)
**Location:** Page 9 - Conclusion
**Problem:** "Outperforms competitive compression methods at a lower cost" is too strong given unmatched budgets and missing key limitations.
**Risk:** Reduces reviewer trust and may require correction during review.
**Required Fix:** Restructure conclusion to three parts: validated findings (scoped), limitations, and future work.

## Actionable Suggestions
### S1: Add Sampling Convergence Analysis (Must - P0)
**Target:** Page 5, "Efficient training via sampling" paragraph
**Action:** Add one controlled experiment comparing three training modes: (a) single-rank sampling (current method), (b) multi-rank sampling (2-3 ranks per step), and (c) full-rank training (all ranks per step), measuring convergence curves and final accuracy on CIFAR-10 with ResNet-18. Report whether sampling introduces accuracy degradation and quantify training time savings.
**Why:** The core efficiency claim rests on the validity of single-rank sampling; without this comparison, reviewers cannot assess the accuracy-efficiency trade-off.

### S2: Add Matched-Budget Baseline Comparisons (Must - P0)
**Target:** Page 7-8, Section 5.2, Tables 2-3
**Action:** For each baseline in Tables 2-3, provide a MAESTRO configuration at the same parameter budget (by interpolating rank configurations via threshold sweeps). Report all baselines with ±std over at least 3 random seeds; where baseline variance is unavailable from original papers, explicitly state this limitation.
**Why:** Without matched budgets, the claim "MAESTRO outperforms baselines" is not rigorously supported. A +0.02pp advantage at dissimilar budgets is not convincing.

### S3: Qualify Layer Independence Claim (Must - P1)
**Target:** Page 4, "DNN low-rank approximation" paragraph
**Action:** Replace "decompositions across layers do not directly interact" with: "The factorized parameters U^i, V^i do not share variables across layers. However, low-rank approximation errors in one layer propagate to subsequent layers through the forward pass; we analyze the practical impact of this coupling empirically in Section 5.3."
**Why:** The current wording is technically misleading and contradicts the nested rank observation.

### S4: Restructure Related Work into Comparison Axes (Nice-to-have - P2)
**Target:** Section 2, Pages 2-3
**Action:** Reorganize into 3-4 comparison-driven paragraphs: (i) low-rank factorization methods (Pufferfish, Cuttlefish, Spectral Init) — focus on rank selection strategy; (ii) training-time subnet sampling (FjORD, HeteroFL, Ordered Dropout) — focus on uniform vs. heterogeneous width; (iii) ordered representations (Nested Dropout) — novelty of applying to factorized weights. End each paragraph with "In contrast, MAESTRO..."  
**Why:** Improves readability and helps readers quickly assess novelty.

### S5: Expand Conclusion with Limitations (Must - P1)
**Target:** Page 9, Section 6
**Action:** Restructure into three concise parts: (a) validated findings (scoped to tested settings), (b) key limitations (theory gap for DNNs, sampling heuristic, error propagation), (c) concrete next steps (convergence analysis, global rank optimization, federated learning).  
**Why:** Current conclusion overclaims and omits limitations that affect interpretation.

### S6: Improve Introduction Opening (Nice-to-have - P1)
**Target:** Page 1, Introduction first paragraph
**Action:** Replace generic DL growth narrative with a problem-specific opening that directly motivates trainable low-rank decomposition. See annotation on Page 1 for a Mentor Revised Version.  
**Why:** A sharper opening improves reader engagement and novelty perception.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)

**Target Structure (4-5 sentences):**

**S1 (Problem + Domain):** "Deep Neural Network training produces large models that are costly to deploy on resource-constrained devices, and low-rank factorization methods such as SVD offer compression but require a priori rank selection and do not adapt to data distribution."

**S2 (Gap):** "Existing SVD-based low-rank methods are computationally expensive, rely on linearity assumptions, and cannot tailor the decomposition to the target data distribution during training."

**S3 (Method):** "We propose MAESTRO, a framework that embeds low-rank decomposition directly into training by factorizing each layer and applying a generalized variant of Ordered Dropout with hierarchical group-lasso regularization, progressively pruning redundant ranks without requiring explicit SVD."

**S4 (Theory):** "Theoretically, MAESTRO recovers SVD of linear mappings under uniform data and PCA for identity mappings."

**S5 (Result + Bounded Implication):** "On image classification (CIFAR-10, Tiny ImageNet) and machine translation (Multi30k), MAESTRO preserves accuracy while reducing model footprint by up to 10x, and enables a graceful accuracy-latency trade-off for deployment to devices with varying capabilities."

### Introduction Outline (Complete)

**P1 (Stakes + Specific Gap):** Open with the specific challenge of low-rank decomposition for DNNs, not generic DL growth. State that SVD-based methods are expensive, require a priori rank selection, and are data-agnostic. End with the need for a trainable alternative.

**P2 (Prior Work Limitations):** Briefly survey compression techniques (quantization, pruning, low-rank) but focus on why low-rank methods specifically fail: SVD is computed on learned weights without considering data distribution, periodic SVD recomputation is expensive, and rank selection is heuristic.

**P3 (Proposed Solution):** Introduce MAESTRO: factorize each layer as W^i = U^i V^{i⊤}, apply Ordered Dropout on the decomposed factors, use HGL regularization for progressive rank pruning. Explicitly state the three key differences from prior work: (i) heterogeneous per-layer rank search, (ii) data-adaptive decomposition, (iii) no SVD calls during training.

**P4 (Contributions):** Three concise bullet points (see annotation on Page 2 for Mentor Revised Version).

**P5 (Roadmap):** One sentence: "Section 2 discusses related work; Section 3 details the method; Section 4 provides theoretical analysis; Section 5 presents experiments; Section 6 concludes."

### Alternative Storyline Candidates

**Candidate A (Current - Problem-First):** Generic DL growth -> techniques survey -> low-rank focus -> solution -> contributions. *Weakness: Opening is too broad; reader doesn't know why low-rank specifically matters until paragraph 3.*

**Candidate B (Gap-First - Recommended):** Specific low-rank challenge (SVD limitations) -> why existing solutions fail -> MAESTRO solution -> contributions. *Strength: Immediately establishes the problem niche and makes the contribution clear from the first paragraph.*

**Candidate C (Application-First):** Deployment constraints (mobile, IoT) -> compression need -> low-rank as solution -> SVD limitations -> MAESTRO. *Strength: Practical motivation is strong; risk: may feel like an engineering paper.*

**Recommended: Candidate B.** It aligns best with the three alignment checks: (a) problem alignment — the stated challenge (SVD limitations) directly matches the proposed solution (trainable decomposition); (b) variable alignment — core concepts (factorization, Ordered Dropout, HGL) appear as key method variables; (c) contribution-evidence alignment — the claims about data-adaptive decomposition are directly tested in experiments.

## Priority Revision Plan
### Ranked Error Board (Top-5)

| Rank | Issue | Severity | Validity Risk | Fixability | Impact on Score |
|------|-------|----------|--------------|------------|-----------------|
| 1 | Sampling heuristic unproven for DNNs | Major | High: core efficiency claim ungrounded | Medium: requires new experiments | -1.5 |
| 2 | Unmatched baseline comparisons | Major | High: superiority claim unsupported | High: add controlled comparisons | -1.0 |
| 3 | Layer independence ignores error propagation | Major | Medium: potential suboptimal rank allocation | High: wording fix + analysis | -0.5 |
| 4 | Conclusion overclaim | Major | Medium: reduces objectivity | High: rewrite | -0.5 |
| 5 | Related Work as citation list | Moderate | Low: weakens novelty positioning | High: restructure | -0.3 |

### Revision Order (P0 → P1 → P2)

**P0 (Must, Before Resubmission):**
1. Add sampling convergence experiment (S1) — directly addresses the core theoretical gap.
2. Add matched-budget baseline comparisons (S2) — required to support the central empirical claim.
3. Qualify layer independence claim (S3) — prevents misleading interpretation.

**P1 (Must, During Revision):**
4. Restructure conclusion with explicit limitations (S5).
5. Improve introduction opening to sharpen problem focus (S6).

**P2 (Nice-to-have, Quality Improvement):**
6. Restructure Related Work into comparison axes (S4).
7. Add OOD generalization test to strengthen robustness claims.
8. Expand Theorem 4.1 with proof sketch and explicit assumptions in main text.

### Expected Impact After Fixes

- P0 fixes resolve the two most critical validity concerns (sampling justification, baseline fairness), which currently reduce confidence in the core claims. After P0, the paper's main thesis (trainable low-rank decomposition is viable) would be adequately supported.
- P1 fixes improve objectivity and narrative quality, making the paper more reviewer-resistant.
- After all P0+P1 fixes, the paper would be suitable for acceptance at a top-tier venue with minor additional review. Estimated score improvement: from ~5.5/10 to ~7.0/10.

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|--------|---------------------|-------|---------|-----------------|-------------------|
| E1 | Accuracy vs. baselines (ResNet-18, VGG-19 on CIFAR-10) | CIFAR-10, ResNet-18/VGG-19, vs. Pufferfish/Cuttlefish/IMP/RareGems/XNOR-Net | Accuracy, GMACs, Params | C3 (partially) | Unmatched budgets; missing baseline variance |
| E2 | Accuracy vs. baselines (Transformer on Multi30k) | Multi30k, 6-layer Transformer, vs. Pufferfish | Perplexity, GMACs, Params | C3 (partially) | Single baseline comparison |
| E3 | Ablation study (HGL, PS, full-training) | ResNet-18 on CIFAR-10 | Accuracy, GMACs, Params | C3 Params | C1 (partially) | Confounded "w/out GL" condition; overlapping CIs |
| E4 | Training dynamics (rank convergence) | ResNet-18 on CIFAR-10 | Total rank over time, per-layer ranks | C1 | No comparison to alternative rank schedules |
| E5 | Accuracy-latency trade-off (greedy pruning) | VGG-19 on CIFAR-10 | Accuracy vs. MACs | C1 (deployment) | Single dataset; no comparison to other pruning strategies |
| E6 | SVD recovery verification (linear case) | Synthetic 9×6 matrix, uniform data | L2 distance to best rank-k | C2 | Synthetic only; no real-data case |
| E7 | PCA recovery verification (identity mapping) | Synthetic, 3-direction data | Singular value estimates | C2 | Synthetic only; no-data case |

### Research-Theme Gap Diagnosis

1. **New Knowledge:** The core new knowledge claim is that trainable low-rank decomposition via Ordered Dropout on factorized weights is viable and beneficial. This is partially supported by experiments, but the lack of convergence guarantees for DNNs weakens the theoretical novelty.

2. **Reproducibility/Reusability:** The paper provides Algorithm 1 and hyperparameter ranges, which is good. However, the sampling strategy (line 3 of Algorithm 1) is underspecified—the distribution over (i,b) pairs is not defined (uniform? proportional to rank?). This must be clarified for exact reproducibility.

3. **Potential to Change Practice:** The "train-once, deploy-everywhere" capability is practically valuable, but the paper does not demonstrate deployment on actual hardware (latency, energy measurements). The MACs proxy is useful but incomplete.

### Proposed Research Experiments

**P0 Experiment: Sampling Convergence Analysis**
- **Target Claim:** C1 (sampling efficiency)
- **Hypothesis:** Single-rank sampling achieves comparable convergence to full-rank training at lower cost.
- **Minimal Design:** Train ResNet-18 on CIFAR-10 with three variants: (a) single-rank sampling (current), (b) 3-rank sampling per step, (c) full-rank (all ranks) per step. Keep all other hyperparameters identical.
- **Controls:** Same initialization, optimizer, epochs, batch size.
- **Metrics:** Final accuracy, convergence speed (epochs to target accuracy), training time per epoch.
- **Success Criterion:** Single-rank sampling achieves accuracy within ±0.2pp of full-rank training while reducing per-epoch time by ≥2x.
- **Estimated Cost:** ~3 GPU-hours on A100.
- **Expected Quality Gain:** Directly addresses the core theoretical gap; would significantly increase confidence in the method.

**P1 Experiment: Matched-Budget Baseline Comparison**
- **Target Claim:** C3 (superiority over baselines)
- **Hypothesis:** MAESTRO matches or exceeds baseline accuracy at the same parameter budget.
- **Minimal Design:** For each baseline in Table 2, find the MAESTRO configuration (via ε_ps sweep) that matches the baseline's parameter count within ±2%. Report accuracy with 3 seeds.
- **Controls:** Same data splits, preprocessing, and evaluation protocol.
- **Metrics:** Accuracy, GMACs, params.
- **Success Criterion:** MAESTRO achieves accuracy within ±0.5pp of each baseline at matched budget.
- **Estimated Cost:** ~5 GPU-hours on A100.
- **Expected Quality Gain:** Removes the main fairness concern in the experimental section.

**P2 Experiment: Inter-Layer Error Propagation Analysis**
- **Target Claim:** C1 (layer independence assumption)
- **Hypothesis:** Independent per-layer rank selection is near-optimal compared to globally-coordinated rank allocation.
- **Minimal Design:** Compare MAESTRO's per-layer independent rank selection against a global rank budget allocated by (a) uniform rank across layers, (b) SVD-based importance ranking, (c) oracle rank search. Measure accuracy at matched total rank budget.
- **Controls:** Same total parameter count across all variants.
- **Metrics:** Accuracy, per-layer rank distribution.
- **Success Criterion:** MAESTRO's independent selection is within ±0.3pp of the best global allocation.
- **Estimated Cost:** ~8 GPU-hours on A100.
- **Expected Quality Gain:** Validates or refutes the layer independence assumption, which is currently unexamined.

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score: 5.5/10**

**Rationale:** The paper presents a technically interesting idea (trainable low-rank decomposition via Ordered Dropout on factorized weights) with some empirical support across diverse architectures. However, the score is constrained by the following factors, prioritized as per the scoring policy (research value + novelty first):

- **Novelty (deferred verification, manuscript-internal assessment):** The core idea is a plausible incremental extension of Ordered Dropout (Horváth et al., 2021) from uniform-width subnetwork sampling to heterogeneous-rank factorization. The paper's claim of "non-trivial extension" lacks concrete differentiation detail. External literature verification was unavailable; thus novelty cannot be fully assessed. **Contribution to novelty: moderate.**

- **Research Value:** The practical capability of "train-once, deploy-everywhere" with graceful accuracy-latency trade-off is valuable for edge deployment. However, the central theoretical gap (sampling convergence unproven for DNNs) limits the scientific contribution. **Contribution to research value: moderate.**

- **Validity/Soundness:** The experiments show plausible results, but unmatched baseline budgets, missing variance for competitors, and the unexamined sampling heuristic reduce confidence. The theoretical analysis is rigorous but limited to linear settings. **Score contribution: -1.5 due to sampling gap and uncontrolled comparisons.**

- **Reproducibility:** Algorithm 1 is provided, but the sampling distribution over (i,b) pairs is underspecified. Hyperparameter ranges are given but without precise tuning protocols. **Score contribution: -0.5 due to missing sampling details.**

**Post-Revision Target: [6.5, 7.5]/10**

If the authors address the P0 issues (sampling convergence experiment, matched-budget comparisons, layer independence qualification) and P1 issues (conclusion rewrite, introduction sharpening), the paper would present a more convincing case. The upper bound assumes that the matched-budget comparisons confirm MAESTRO's competitiveness and the sampling analysis shows no meaningful degradation. The lower bound accounts for the possibility that sampling introduces some degradation that requires additional mitigation.