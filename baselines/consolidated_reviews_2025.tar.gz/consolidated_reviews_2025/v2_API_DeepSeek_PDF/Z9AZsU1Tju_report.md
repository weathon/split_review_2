## Summary
# Final Review Report

## Summary

This paper presents ITHP (Information-Theoretic Hierarchical Perception), a multimodal fusion model that applies the information bottleneck (IB) principle in a hierarchical architecture. The key idea is to designate one modality as the "prime" input and treat remaining modalities as "detectors" that distill information into compact latent states via successive IB objectives. The model is evaluated on sarcasm detection (MUStARD) and sentiment analysis (CMU-MOSI, CMU-MOSEI) benchmarks.

**Strengths**: The hierarchical IB formulation is a conceptually interesting departure from symmetric fusion approaches; the empirical results on MOSI/MOSEI are strong relative to baselines; the paper includes useful ablation studies on hyperparameters and latent dimensions; code is provided for reproducibility.

**Core Weaknesses**: (1) The optimization problem in Eq.(2) has constraints that are automatically satisfied by the data processing inequality, making the formulation vacuous; (2) The final loss scaling factor 2/(β+γ) lacks principled derivation; (3) The main results confound backbone improvement (DeBERTa vs BERT) with fusion innovation; (4) No statistical significance or variance is reported; (5) The variational derivation in Eq.(9) has a subtle bound-direction issue; (6) Contribution 2 ("compatibility with most existing solutions") is too vague to be a verifiable contribution.

**Novelty verdict**: Deferred (external literature verification unavailable in this run). The combination of hierarchical IB with prime-modality design appears novel within the scope of the manuscript, but a full novelty assessment requires systematic comparison against prior IB-based multimodal methods (e.g., MIB) and other asymmetric fusion approaches.

## Strengths
1. **Conceptually novel fusion paradigm**: The hierarchical IB approach with prime-modality designation is a structurally distinctive idea. Most existing multimodal fusion methods treat all modalities symmetrically (concatenation, tensor fusion, cross-modal attention). ITHP's asymmetric design—compressing the primary modality while using secondary modalities as "detectors"—offers a new perspective that is well-motivated by neuroscience findings about hierarchical brain processing.

2. **Strong empirical results**: On CMU-MOSI, ITHP-DeBERTa achieves 88.7% BA, 88.6% F1, 0.643 MAE, and 0.852 Corr, outperforming DeBERTa-based baselines (MAG_d: 86.1 BA) and BERT-based baselines by meaningful margins. On CMU-MOSEI (87.3% BA, 87.4% F1), the improvements are also consistent. The MUStARD sarcasm detection results (75.3% precision, 75.2% F-score with V-T-A ordering) show clear gains over MSDM (71.9%/71.5%) and HFM (69.4%/68.9%).

3. **Comprehensive ablation and sensitivity analysis**: The paper provides hyperparameter sweeps for Lagrange multipliers (β, γ) with a full 6×6 grid, analyzes latent state dimension sensitivity, and tests all 6 possible modality orderings for sarcasm detection. This thoroughness strengthens the empirical foundation and helps readers understand the method's behavior.

4. **Code and data availability**: The GitHub repository is provided, and the method is built on standard components (MAG-BERT, BERT, DeBERTa), enhancing reproducibility potential. The pseudo-code in Algorithm 1 provides a clear reference implementation.

5. **Honest limitations section**: The paper acknowledges the modality-ordering dependency and discusses the challenge of primary modality insufficiency, which shows scientific maturity and helps readers understand the method's boundary conditions.

6. **N-modality extension**: The paper provides a general formulation (Appendix C.2) for extending ITHP beyond 3 modalities, with explicit loss functions and pseudo-code. This demonstrates the framework's potential generality beyond the specific experiments conducted.

## Weaknesses
### Major Weaknesses

1. **Vacuous constrained optimization (Page 4, Eq.2)**: The constrained minimization problem in Eq.(2) has three constraints that are each automatically satisfied by the data processing inequality (B0 is a function of X0, B1 is a function of B0). The first constraint I(X0;X1) - I(B0;X1) ≤ ε1 is always non-negative since I(B0;X1) ≤ I(X0;X1) by DPI. Similarly for the third constraint. Therefore Eq.(2) does not impose meaningful restrictions on the optimization, making the Lagrangian derivation in Eq.(3) a purely heuristic construction rather than a principled relaxation.

2. **Unjustified scaling factor in final loss (Page 6, Eq.7)**: The factor 2/(β+γ) appears without derivation or motivation. For the sarcasm detection setting (β=32, γ=8), this factor equals 0.05, heavily downweighting the IB objective. This raises the concern that the model is primarily trained by the task loss while the IB regularization is negligible, undermining the claimed contribution of the hierarchical IB mechanism. The paper does not report the relative magnitudes of loss terms during training.

3. **Backbone confound in main results (Page 8-9, Tables 2-3)**: The comparison tables mix BERT-based and DeBERTa-based baselines without separating the effect of the text encoder upgrade from the ITHP fusion module. The strongest DeBERTa baseline (MAG_d: 86.1 BA) is only 2.6% below ITHP-DeBERTa (88.7 BA), while BERT-based models are 4.5-4.7% lower. Without reporting ITHP with BERT backbone or MAG with DeBERTa+ITHP fusion head, the reader cannot attribute the gains to the hierarchical IB method vs. the more powerful DeBERTa encoder.

4. **Missing statistical significance (throughout experiments)**: No variance, confidence intervals, or significance tests are reported for any experiment. The MUStARD experiment uses 5-fold CV but reports only point estimates. The MOSI/MOSEI experiments run 5 repeats but report only mean values. Given that performance differences between strong baselines are often within 1-3%, variance reporting is essential for reliability assessment.

5. **Variational bound derivation issue (Page 16, Eq.9)**: The derivation replaces log p(B0|X0) with log q_θ0(B0|X0) and log p(B0) with log q(B0) simultaneously. Since the first replacement decreases the term and the second increases its negative contribution, the overall inequality direction is not guaranteed without stronger assumptions about the quality of the variational approximations. The standard VIB approach avoids this by only replacing the marginal while keeping the conditional exact.

6. **Vague second contribution (Page 2)**: "Design ITHP model on top of recent neural network architectures, enhancing its accessibility and compatibility with most existing multimodal learning solutions" is not a falsifiable or verifiable contribution. It does not specify which architectures, what compatibility means, or demonstrate it experimentally.

### Minor Weaknesses

7. **Neuroscience motivation not operationalized**: The extensive neuroscience discussion (Pages 1-2) is never connected back to specific model design choices. The paper does not test whether ITHP actually exhibits properties claimed to be brain-like (hierarchical processing, reciprocal feedback, sequential integration). This makes the neuroscience framing feel ornamental rather than functional.

8. **IB objective mismatch**: The paper uses standard IB loss (compress X, preserve Y) but replaces Y with X1 and X2 (high-dimensional modalities) without discussing the difference. Standard IB typically preserves low-dimensional labels; reconstructing high-dimensional modalities is a harder problem that may require different architectural considerations.

9. **Related work is a flat list**: The multimodal learning related work paragraph enumerates methods chronologically without organizing them into comparison axes or explicitly stating how ITHP differs from each category.

10. **Modality ordering heuristic unvalidated**: The sentiment analysis ordering (T→A→V) is justified only by feature dimensionality, not by mutual information or task-relevance measures. This is a key design choice without empirical backing.

## Key Issues
Based on the analysis, the following issues are ranked by combined severity (validity risk × research-value impact):

| Rank | Issue | Location | Severity | Validity Risk | Fixability |
|------|-------|----------|----------|---------------|------------|
| 1 | Vacuous optimization constraints in Eq.(2) | Page 4, Section 2.1 | Major | High: The formal optimization problem does not impose meaningful constraints, weakening the theoretical foundation | Fixable: Remove Eq.(2) and present Eq.(3) as the directly proposed loss |
| 2 | Backbone confound in results | Page 8-9, Tables 2-3 | Major | High: Core claim of outperforming SOTA conflates backbone improvement with fusion innovation | Fixable: Add BERT-based ITHP results and statistically controlled comparisons |
| 3 | Unjustified scaling factor 2/(β+γ) | Page 6, Eq.(7) | Major | Medium: The loss weighting is heuristic, potentially making IB regularization negligibly weak | Fixable: Provide derivation or remove scaling factor |
| 4 | Missing statistical significance | Throughout experiments | Major | Medium: Without variance, improvements cannot be assessed for reliability | Fixable: Add multi-seed std dev and significance tests |
| 5 | Variational bound derivation issue | Page 16, Appendix C.1 | Major | Medium: The inequality direction in Eq.(9) is not guaranteed | Fixable: Adopt standard VIB derivation (Alemi et al., 2017) |

### Key Issue 1: Theoretical foundation gap (Eq.2)
The constrained optimization problem is meant to formally ground ITHP, but its constraints are automatically satisfied by the data processing inequality. This means the formal apparatus does not contribute anything beyond the heuristic Lagrangian in Eq.(3). The paper should either (a) remove Eq.(2) and present Eq.(3) directly as the proposed loss, or (b) reformulate the constraints as meaningful lower bounds (e.g., I(B0;X1) ≥ τ1, I(B1;X2) ≥ τ2).

### Key Issue 2: Unfair comparison setup
Tables 2 and 3 compare ITHP-DeBERTa against both BERT-based and DeBERTa-based baselines without controlling for the text encoder. Since DeBERTa is known to outperform BERT on sentiment analysis, the improvements of ITHP over BERT-based models do not isolate the fusion mechanism's contribution. A controlled experiment with ITHP + BERT vs. MAG + BERT is essential.

### Key Issue 3: Heuristic loss design
The scaling 2/(β+γ) in Eq.(7) and the use of β, γ for dual purposes (IB trade-off in Eq.4/5 and scaling in Eq.7) creates conceptual ambiguity. The paper should clarify the derivation or adopt a simpler weighted sum.

### Key Issue 4: Lack of statistical reliability
None of the three experiments report standard deviations or confidence intervals. The MOSI/MOSEI experiments mention "5 repeats" but only the mean is reported. In areas where gains are 1-3%, this is insufficient for confidence.

### Key Issue 5: Variational bound gap
The derivation of the variational bound for I(X0;B0) in Eq.(9) replaces both p(B0|X0) and p(B0) with variational approximations simultaneously. This does not guarantee an upper bound on mutual information (see annotation on Page 16).

## Actionable Suggestions
### S1 (Must): Fix the optimization problem formulation (Page 4, Eq.2)
**Problem**: The constrained minimization problem is vacuous because all constraints are automatically satisfied by the data processing inequality.
**Action**: Either (a) remove Eq.(2) entirely and present Eq.(3) as the direct loss function inspired by the IB Lagrangian, or (b) replace the constraints with meaningful lower bounds such as:
- I(B0; X1) ≥ τ1 (rather than I(X0;X1) - I(B0;X1) ≤ ε1)
- I(B1; X2) ≥ τ2
These can be converted into the same Lagrangian form as Eq.(3) but with correct inequality direction.

### S2 (Must): Add controlled comparison to isolate fusion contribution (Page 8-9, Tables 2-3)
**Problem**: Results conflate backbone (DeBERTa vs BERT) improvement with ITHP fusion improvement.
**Action**: Add the following controlled experiments:
- ITHP + BERT backbone on CMU-MOSI and CMU-MOSEI (to compare against BERT-based baselines on equal footing).
- Report results in a new table column: "Backbone | Fusion | BA | F1 | MAE | Corr" to separate the effects.
- Explicitly state in text which gains come from the backbone and which from the ITHP module.

### S3 (Must): Report statistical significance (throughout experiments)
**Problem**: No variance or confidence intervals are reported.
**Action**: Report mean ± std over at least 3 random seeds for all metrics (BA, F1, MAE, Corr). For the MUStARD 5-fold CV, report the per-fold results and the mean ± std across folds. Add paired significance tests (e.g., Wilcoxon signed-rank) against the strongest baseline for each dataset.

### S4 (Must): Clarify or derive the scaling factor 2/(β+γ) (Page 6, Eq.7)
**Problem**: The scaling factor is unexplained and may be incorrect.
**Action**: Replace Eq.(7) with a straightforward weighted sum: L = L_overall + α·L_task, where L_overall = L_IB0 + λ·L_IB1 (or add separate weights for each term). If the authors insist on keeping the 2/(β+γ) factor, provide a clear derivation in Appendix showing how it arises from the Lagrangian dual of a constrained optimization problem.

### S5 (Should): Revise variational bound derivation (Page 16, Appendix C.1)
**Problem**: The inequality direction in Eq.(9) is not guaranteed.
**Action**: Follow the standard VIB derivation (Alemi et al., 2017): I(X;B) = E_x[KL(p(B|X)||r(B))] - KL(p(B)||r(B)), where the second term is non-negative, giving I(X;B) ≤ E_x[KL(p(B|X)||r(B))]. By approximating p(B|X) ≈ qθ(B|X) and r(B) ≈ q(B), the upper bound is E_x[KL(q(B|X)||q(B))], which is the same as the paper's final expression but derived with a correct inequality chain.

### S6 (Should): Improve contribution 2 (Page 2, Section 1.1)
**Action**: Replace the vague second contribution with a specific architectural contribution, e.g.: "We integrate ITHP with DeBERTa as a concrete instantiation (ITHP-DeBERTa), showing that the hierarchical IB module can be trained end-to-end with a modern pretrained language encoder."

### S7 (Should): Strengthen related work structure (Page 3)
**Action**: Reorganize the multimodal learning related work into 2-3 thematic categories (symmetric fusion, hierarchical fusion, information-theoretic fusion) with explicit comparison to ITHP for each category. Add a paragraph discussing MIB (Multimodal Information Bottleneck) to position ITHP's hierarchical structure as the key differentiator.

### S8 (Nice-to-have): Validate modality ordering (Page 8)
**Action**: For the sentiment analysis experiments, provide an ordering sensitivity analysis (similar to Table 11 for MUStARD) testing all 6 modality orders on CMU-MOSI. This would either confirm the T→A→V ordering choice or reveal better alternatives.

### S9 (Nice-to-have): Add OOD/robustness experiments
**Action**: While the paper demonstrates strong in-distribution results, adding one robustness experiment (e.g., testing on noisy modalities, missing modality scenarios, or cross-dataset evaluation) would significantly strengthen the claim that ITHP produces "compact latent state representations that retain relevant information while minimizing redundancy."

## Storyline Options + Writing Outlines
### Current Storyline Assessment

The current introduction follows this structure:
- P1: Neuroscience background (hierarchical brain processing, synaptic reciprocity)
- P2: Sarcasm example to illustrate individual primary modality sensitivity
- P3: Multimodal learning challenges + brief mention of prior work → ITHP solution

**Problem**: The first 1.5 pages discuss neuroscience and sarcasm examples before clearly stating the research problem and approach. The gap in prior multimodal fusion methods is only vaguely identified ("deviate from information-processing mechanism"), not concretely linked to specific technical limitations of existing methods.

### Recommended Storyline: "Problem-Gap-Solution-Evidence"

**Abstract Outline**:

S1 (Problem & Domain): "Integrating heterogeneous information from text, audio, and visual modalities is essential for robust perception in autonomous systems."
S2 (Challenge): "Existing fusion methods treat modalities symmetrically, ignoring the asymmetric importance of different modalities in a given task."
S3 (Gap): "This symmetric approach can lead to information redundancy and suboptimal distillation of task-relevant cross-modal cues."
S4 (Method): "We propose ITHP, a hierarchical information bottleneck model that designates a prime modality and progressively compresses its representation while preserving information from secondary modalities."
S5 (Results & Bounded Claim): "On three benchmarks (MUStARD, CMU-MOSI, CMU-MOSEI), ITHP with DeBERTa achieves consistent gains over strong baselines, including 88.7% BA on CMU-MOSI. These results highlight the potential of asymmetric, compression-driven fusion."

**Introduction Outline**:

P1 (Stakes & Motivation): "Multimodal understanding is critical for autonomous systems that must process diverse sensory streams—language, audio, and vision. However, the high dimensionality and intricate correlations across modalities make effective fusion a fundamental challenge."

P2 (Concrete Gap): "Current fusion methods fall into two categories: symmetric approaches that concatenate or tensor-multiply modality features [Zadeh et al., 2017, Tsai et al., 2019], and attention-based methods that compute cross-modal interactions [Lv et al., 2021]. Both treat all modalities as equally important. This overlooks the fact that for a given task, one modality (e.g., text in sentiment analysis) often carries substantially more discriminative power, and naively combining all modalities can introduce noise rather than signal."

P3 (Proposed Idea): "Inspired by neuroscience evidence that the brain processes multimodal information hierarchically—starting with a primary sensory stream and integrating secondary cues sequentially—we propose ITHP. Our model first compresses the primary modality X0 into a compact latent B0 using the Information Bottleneck (IB) principle, while preserving information about X1 (a secondary modality). It then further compresses B0 into B1 while preserving information about X2. This hierarchical design gradually distills task-relevant information while discarding modality-specific noise."

P4 (Evidence Preview & Contribution): "We evaluate ITHP on three standard benchmarks. On CMU-MOSI, ITHP-DeBERTa achieves 88.7% accuracy, surpassing comparable DeBERTa-based baselines. Ablation studies confirm that the hierarchical structure outperforms single-level IB and concatenation baselines. The key contributions are: (C1) a hierarchical IB fusion framework with prime-modality design, (C2) an end-to-end instantiation with DeBERTa, and (C3) empirical results with thorough hyperparameter analysis."

### Comparison with Current Storyline

| Alignment Check | Current | Recommended |
|----------------|---------|-------------|
| Problem alignment | Vague ("deviate from neural synapses") | Specific (symmetric fusion ignores modality importance) |
| Variable alignment | Neuroscience terms not used later | IB terms (B0, B1) directly introduced |
| Contribution-evidence alignment | Claims "first to beat human" without backbone control | Bounded claim tied to DeBERTa-based comparison |

### Title Suggestion
Current: "NEURO-INSPIRED INFORMATION-THEORETIC HIERARCHICAL PERCEPTION FOR MULTIMODAL LEARNING"

Improved: "Asymmetric Information Bottleneck Fusion: Hierarchical Multimodal Learning with Prime-Modality Compression"

Rationale: The improved title states the core technical idea (asymmetric, prime-modality compression) upfront rather than focusing on neuroscience inspiration.

## Priority Revision Plan
### P0 (Must-Do Before Re-Submission)

| Priority | Task | Location | Expected Impact | Effort |
|----------|------|----------|-----------------|--------|
| P0.1 | Fix Eq.(2) - remove or reformulate vacuous optimization constraints | Page 4, Section 2.1 | Eliminates theoretical flaw that could be rejected by reviewers | Low (text revision) |
| P0.2 | Add controlled comparison: ITHP + BERT vs MAG + BERT on MOSI/MOSEI | Page 8-9, Tables 2-3 | Isolates fusion contribution from backbone; addresses the strongest critique | Medium (additional experiments) |
| P0.3 | Report mean±std over ≥3 seeds for all main experiments | Throughout Section 3 | Adds statistical credibility to all claims | Medium (re-run experiments) |
| P0.4 | Clarify scaling factor 2/(β+γ) or adopt simpler weighting | Page 6, Eq.(7) | Resolves ambiguity about loss function design | Low (text revision) |

### P1 (Should-Do for Strong Submission)

| Priority | Task | Location | Expected Impact | Effort |
|----------|------|----------|-----------------|--------|
| P1.1 | Revise variational bound derivation to follow standard VIB | Page 16, Appendix C.1 | Fixes potential inequality direction error | Low (text revision) |
| P1.2 | Replace vague Contribution 2 with specific architectural claim | Page 2, Section 1.1 | Strengthens contribution list | Low (text revision) |
| P1.3 | Restructure related work into thematic categories | Page 3, Section 1.2 | Improves positioning and clarity | Low (text revision) |
| P1.4 | Tone down "first to outperform human-level" claim | Conclusion Page 9 | Avoids overclaim; improves credibility | Low (text revision) |

### P2 (Nice-to-Have for Quality Improvement)

| Priority | Task | Location | Expected Impact | Effort |
|----------|------|----------|-----------------|--------|
| P2.1 | Add modality ordering sensitivity analysis for sentiment tasks | Page 8, Section 3.2 | Validates key design choice | Medium |
| P2.2 | Add OOD/robustness evaluation (noise, missing modality) | New experiment | Strengthens generalization claim | High |
| P2.3 | Discuss IB objective mismatch when preserving high-dimensional modalities | Page 4, Section 2 | Strengthens theoretical positioning | Low |

### Revision Order

```text
ASCII Diagram — Revision Strategy Roadmap
[P0.1: Fix Eq.(2) constraints] + [P0.4: Clarify Eq.(7) scaling]
    → (text revisions, low effort)
    ↕
[P0.2: Add ITHP+BERT control] + [P0.3: Multi-seed std reporting]
    → (experiments, medium effort)
    ↕
[P1.1: Fix VI derivation] + [P1.2: Fix Contribution 2] + [P1.3: Restructure related work] + [P1.4: Tone down claims]
    → (text revisions, low effort, done in parallel)
    ↕
[P2: Optional robustness/ordering experiments]
    → (quality improvement)
```

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|--------|---------------------|-------|---------|-------------|-----------------|-------------------|
| E1: MUStARD Sarcasm Detection (3.1) | ITHP outperforms MSDM on multimodal sarcasm detection | MUStARD, 5-fold CV, V→T→A ordering | Weighted Precision, Recall, F-Score | ITHP: 75.3/75.2/75.2 vs MSDM: 71.9/71.4/71.5 | Hierarchical IB improves over concatenation fusion | Only compared against MSDM; HFM comparison in appendix; no std reported |
| E2: MUStARD Varying Modalities (3.1) | Single-stage ITP outperforms MSDM on 2-modal combinations | MUStARD, all 2-modal combinations | Precision, Recall, F-Score | ITP outperforms MSDM on V-A but similar on others | ITHP extracts better cross-modal info | Small gains (1-2%) on most combinations |
| E3: Lagrange multiplier sweep (3.1) | Optimal β, γ for sarcasm detection | MUStARD, β/γ ∈ {2,4,8,16,32,64} | Precision, Recall | Optimal at β=32, γ=8 | Higher β (text retention) more important | Grid limited to powers of 2; no finer-grained search |
| E4: Latent size sweep (F.4, Fig.6) | Optimal B0, B1 dimensions | MUStARD, B0/B1 ∈ {8,16,32,64,128,256} | Precision, Recall | Optimal: B0=128, B1=64 | dB=64 sufficient for multimodal representation | Dim 236 used (typo for 256?) in table header |
| E5: CMU-MOSI Sentiment (3.2, Table 2) | ITHP outperforms SOTA on sentiment analysis | CMU-MOSI, T→A→V, DeBERTa | BA, F1, MAE, Corr | ITHP: 88.7/88.6/0.643/0.852 | Outperforms BERT and DeBERTa baselines | Backbone confound (DeBERTa vs BERT); no ITHP+BERT baseline |
| E6: CMU-MOSEI Sentiment (3.2, Table 3) | ITHP generalizes to larger dataset | CMU-MOSEI, T→A→V | BA, F1, MAE, Corr | ITHP: 87.3/87.4/0.564/0.813 | Consistent SOTA outperformance | Same backbone confound; Self-MM_d collapse not explained |
| E7: Modality ordering (F.5, Table 11) | Impact of modality ordering on sarcasm detection | MUStARD, all 6 orders | Precision, Recall, F-Score | V→T→A best (75.3), A→T→V worst (70.8) | Modality order significantly matters | No analysis of why ordering matters; no mutual information analysis |
| E8: Inference latency (G) | ITHP inference cost vs MLP baseline | MUStARD, MLP vs ITHP | ms/sample | MLP: 0.00221ms, ITHP: 0.0120ms | ITHP adds ~5.4× latency | Latency only for sarcasm task; no comparison on MOSI/MOSEI |

### Research-Theme Gap Diagnosis

1. **New Knowledge**: The paper's core claim is that hierarchical IB with prime-modality design improves fusion. The controlled experiment to separate the IB effect from backbone improvement is missing. Without it, the paper does not cleanly establish that the hierarchical IB mechanism itself creates new knowledge.

2. **Reproducibility**: Code is provided, but key design choices (modality ordering, hyperparameter selection for each dataset) are explained heuristically. The loss function derivation issue in Eq.(9) may cause implementation discrepancies.

3. **Impact on Practice/Understanding**: The paper could change how researchers think about fusion (asymmetric vs symmetric), but the current framing emphasizes performance ("beating human") over understanding (why hierarchy helps). The neuroscience motivation is not empirically validated in the model.

### Proposed Research Experiments

#### P0 Experiments (Must-Do Before Re-Submission)

**Exp-R1: ITHP + BERT controlled baseline**
- Target Claim: ITHP fusion module improves over concatenation/multi-head fusion
- Hypothesis: ITHP+BERT will outperform MAG+BERT (or other BERT-based baselines) with the same backbone
- Minimal Design: Replace DeBERTa with BERT in ITHP framework; train on CMU-MOSI and CMU-MOSEI
- Controls: Same training epochs (40), learning rate (1e-5), batch size as DeBERTa variant
- Metrics: BA, F1, MAE, Corr (mean±std over 5 seeds)
- Success Criterion: ITHP+BERT achieves BA≥85.5 on CMU-MOSI (vs MAG_BERT_b 84.2)
- Estimated Cost: ~2 GPU-hours per dataset
- Expected Gain: Isolates ITHP's fusion contribution from backbone upgrade

**Exp-R2: Multi-seed variance reporting**
- Target Claim: All reported improvements are statistically reliable
- Minimal Design: Re-run all main experiments (Tables 1-3) with 5 random seeds, report mean±std
- Success Criterion: Improvements over strongest baseline exceed 2× pooled std
- Estimated Cost: 5× current compute budget
- Expected Gain: Statistical credibility for all claims

#### P1 Experiments (Should-Do)

**Exp-R3: Modality ordering sensitivity on MOSI/MOSEI**
- Target Claim: The T→A→V ordering choice is optimal for sentiment analysis
- Minimal Design: Test all 6 modality orders on CMU-MOSI (as done for MUStARD in Table 11)
- Success Criterion: T→A→V is among top-2 orderings; if not, report best ordering
- Estimated Cost: ~6 GPU-hours
- Expected Gain: Validates key design choice; may improve results

**Exp-R4: Ablation: single-level IB vs hierarchical ITHP**
- Target Claim: The two-level hierarchy outperforms single-level IB
- Minimal Design: Replace ITHP with single IB bottleneck (B0 only, skip B1); compare on all datasets
- Controls: Same encoder architectures and hyperparameters
- Success Criterion: ITHP (2-level) outperforms single-level IB by ≥1% on all metrics
- Estimated Cost: ~4 GPU-hours
- Expected Gain: Directly validates the hierarchical contribution

#### P2 Experiments (Nice-to-Have)

**Exp-R5: OOD / missing-modality robustness**
- Target Claim: ITHP's compact representations are robust to modality noise or absence
- Minimal Design: Zero-out one modality at test time; measure performance degradation vs baselines
- Success Criterion: ITHP shows smaller degradation than concatenation fusion
- Estimated Cost: ~4 GPU-hours
- Expected Gain: Demonstrates robustness advantage of IB compression

```text
ASCII Diagram — Experiment Upgrade Plan
P0 (Before Submission):
  [Exp-R1: ITHP+BERT control] → isolates fusion contribution
  [Exp-R2: Multi-seed reporting] → statistical credibility
      ↕
P1 (This Week):
  [Exp-R3: Ordering sensitivity on MOSI] → validates design choice
  [Exp-R4: 2-level vs 1-level ablation] → validates hierarchical claim
      ↕
P2 (Optional):
  [Exp-R5: OOD/missing modality robustness] → generalization evidence
```

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score: 5.5/10**

Scoring rationale (research value + novelty emphasized):

- **Research Value (5/10)**: The hierarchical IB fusion idea is conceptually interesting, but the paper's core claims are weakened by the backbone confound (DeBERTa vs BERT) and the vacuous optimization formulation. The controlled experiment needed to isolate the ITHP fusion contribution is missing. The paper provides useful empirical results and thorough hyperparameter analysis, but the scientific contribution is partially obscured by methodological ambiguities.

- **Novelty (5/10)**: The prime-modality + hierarchical IB design is a distinctive combination. However, novelty cannot be fully assessed without external literature verification (deferred in this run). The IB principle has been applied to multimodal learning before (MIB), and the paper does not clearly differentiate from prior IB-based fusion methods in the related work section. A conservative assessment places novelty as moderate within the ICLR context.

- **Validity/Soundness (5/10)**: Several technical issues reduce confidence: Eq.(2) constraints are vacuous, Eq.(7) scaling factor is unjustified, the variational bound derivation in Eq.(9) has a direction issue, and no statistical significance is reported. The empirical trends are consistent, but the formal weaknesses require attention.

- **Reproducibility (7/10)**: Code is available, architectures are described, and hyperparameters are reported. Pseudo-code is provided. Minor gaps include the missing variance reporting and the ambiguous loss scaling.

**Post-Revision Target: [6.5, 7.5]/10**

If the authors address the P0 items (fix Eq.2, add ITHP+BERT control, report multi-seed std, clarify Eq.7 scaling), the paper would become a solid conference submission. The conceptual idea is strong enough that with proper controlled experiments and corrected theoretical formulation, it could reach 7+ on the 10-point scale. Addressing P1 items (fix variational bound derivation, restructure related work, improve contribution statements) would further strengthen to the upper end of this range.