## Summary
# Final Review Report

## Summary

This paper presents CBGBench, a benchmark for Structure-Based Drug Design (SBDD) that unifies 12 generative methods under a common "fill-in-the-blank" formulation of the 3D protein-molecule complex binding graph. The benchmark makes three main contributions: (C1) a unified framework that categorizes methods by three dichotomies (voxelized vs continuous positions, one-shot vs auto-regressive generation, domain-knowledge vs data-driven), enabling modular and extensible implementation; (C2) extension of these methods to four lead-optimization subtasks (linker design, fragment growing, side-chain decoration, scaffold hopping); and (C3) a comprehensive evaluation protocol covering substructure, chemical property, interaction, and geometry metrics with Friedman ranking, plus a unified open-source codebase.

The paper is well-motivated by genuine problems in SBDD evaluation — non-standardized data splits, coupled implementations, and narrow task scope. The experimental scope is impressive in breadth (12 methods, 5 tasks, 4 evaluation aspects), and several practical insights emerge (e.g., CNN voxel methods remain competitive, scaffold hopping is most challenging). However, the benchmark has several critical limitations: (1) a systematic confound between generative paradigm and network architecture (GVP for auto-regressive, EGNN for diffusion) undermines causal attribution of performance differences; (2) the ranking system uses an arbitrary weighting scheme (Interaction at 0.4 vs other aspects at 0.2) with insufficient justification; (3) lead-optimization evaluation drops from 12 to 6 methods without addressing selection bias; (4) real-world validation is limited to two GPCR targets. Novelty claims require external literature verification, which was not available in this run. The codebase release is a valuable community resource.

**Final Score: 6.0/10** — Strong engineering contribution and broad evaluation scope, but methodological confounds and limited causal analysis prevent higher confidence.

**Post-Revision Target: [7.0, 8.0]/10** — If the architecture confound is addressed (or explicitly bounded), ranking weights justified, and limitations expanded.

## Strengths
1. **Well-motivated problem and clear gap identification.** The paper correctly identifies real and significant obstacles in SBDD evaluation: non-standardized data splits, different docking programs, coupled model implementations, and lack of a common codebase. The examples provided (GraphBP vs Pocket2Mol using different CrossDocked2020 splits, TargetDiff vs DiffBP using different architectures) are concrete and convincing.

2. **Comprehensive method coverage.** The evaluation of 12 methods spanning multiple architectural families (CNN voxel-based, GNN auto-regressive, GNN diffusion, domain-knowledge-enhanced) on a unified protocol is the most extensive SBDD benchmark to date in terms of method count. The three-axis taxonomy (position representation, generation order, domain knowledge) provides a useful organizational framework.

3. **Extension to lead-optimization subtasks is a genuine value-add.** Going beyond de novo generation to include linker design, fragment growing, side-chain decoration, and scaffold hopping addresses an important gap in the SBDD evaluation landscape. The finding that scaffold hopping is consistently the most challenging subtask across methods is practically relevant for drug discovery researchers.

4. **Thoughtful metric design.** The introduction of LBE (Ligand Binding Efficiency) to correct for molecule size bias in Vina Energy, and the PLIP-based interaction pattern analysis (7 interaction types with JSD/MAE metrics), go beyond standard evaluation. The explicit discussion of LBE's limitations in Appendix B.4 demonstrates awareness of metric validity issues.

5. **Open-source codebase.** The release of a unified codebase with modular architecture (core/algorithm/chemistry/API layers), configuration files, and standardized training pipelines is a significant community contribution that lowers the barrier for future SBDD research.

6. **Real-world disease target validation.** The case study on two GPCR targets (ADRB1, DRD3) with t-SNE visualization and docking energy distributions provides a sanity check showing that benchmark rankings are broadly consistent on held-out pharmaceutically relevant targets.

## Weaknesses
1. **Systematic architecture–paradigm confound (Major).** The training setup standardizes GVP for auto-regressive methods and EGNN for diffusion-based methods (Page 6 - Setup paragraph). This couples generative paradigm with network architecture, making it impossible to determine whether performance differences arise from the generation strategy (one-shot vs auto-regressive) or the message-passing backbone (EGNN vs GVP). Key conclusions — e.g., "diffusion-based models achieve state-of-the-art" and "CNN-based methods remain competitive" — are confounded by this design choice. The paper does not acknowledge this confound anywhere.

2. **Unjustified ranking weights (Major).** The overall ranking (Table 7) uses weights 0.4 for Interaction and 0.2 each for Substructure, Chemical Property, and Geometry. This choice significantly impacts the final rankings (MolCraft #1, VOXBIND #2 largely due to Interaction scores), yet no justification is provided for why Interaction should be double-weighted. Alternative weighting schemes could produce different rankings.

3. **Lead-optimization evaluation drops coverage from 12 to 6 methods without discussing selection bias (Major).** Domain-knowledge methods (D3FG, DecompDiff, FLAG) and voxelized methods (LiGAN, 3DSBDD, VOXBIND) are excluded from lead-optimization subtasks, reducing coverage by 50%. Additionally, auto-regressive methods are fine-tuned from pretrained weights while diffusion methods are trained from scratch — a systematic asymmetry that is mentioned but its impact on comparability is not discussed (Page 8 - Setup paragraph).

4. **Limited real-world validation (Moderate).** The "real-world disease targets" case study uses only two GPCR receptors (ADRB1, DRD3). The claim that "conclusions are mainly consistent with those obtained on real-world disease targets" (Page 2, conclusion bullets) overstates the evidence base. Generalizability to other target families (kinases, proteases, ion channels) is untested.

5. **Novelty claims unverifiable in current run (Moderate).** Contributions C1-C3 (unified framework, task extension, comprehensive evaluation) are benchmark-building contributions that require comparison with existing SBDD benchmarks and toolkits for novelty assessment. External literature verification was unavailable in this run, so novelty verdicts are deferred.

6. **Title and narrative structure need improvement (Minor).** The title "CBGBench: Fill in the Blank of Protein-Molecule Complex Binding Graph" uses the "fill-in-the-blank" metaphor effectively but has a typo (CBGB ENCH). The introduction paragraphs follow a list-like structure ("Firstly... Secondly... Moreover...") rather than a cohesive narrative arc from motivation to gap to solution to evidence.

7. **Conclusion overclaims without evidence anchors (Minor).** The conclusion paragraph (Page 10) is purely descriptive and does not synthesize key benchmark findings into specific, evidence-anchored takeaway messages. Limitations are mentioned but not concretely scoped.

## Key Issues
### Issue 1: Architecture-Paradigm Confound Undermines Core Conclusions (Critical)
**Location**: Page 6 - Training Setup paragraph
**Severity**: Critical
**Evidence**: The paper states: "To eliminate the effect brought about by the architecture of GNNs, in implementation, we use GVP and EGNN with GAT, as message-passing modules of auto-regressive and diffusion-based models, respectively." This creates a perfect confound: GVP ↔ auto-regressive, EGNN ↔ diffusion.
**Impact**: The main conclusions (e.g., "diffusion-based models achieve state-of-the-art," "auto-regressive methods except Pocket2Mol can hardly capture pocket conditions") cannot be attributed to the generative paradigm alone. They may reflect EGNN vs GVP expressivity differences.
**Fix**: Either (a) add a controlled experiment swapping backbones (EGNN for an auto-regressive variant, GVP for a diffusion variant), or (b) explicitly bound all paradigm-level claims to the specific backbone used.

### Issue 2: Unexplained Ranking Weighting Scheme (Major)
**Location**: Page 7-8 - Table 7 and Discussion
**Severity**: Major
**Evidence**: The ranking weights Interaction at 0.4 vs Substructure/Chemical/Geometry at 0.2 each. No justification is given for this 2:1 weighting.
**Impact**: The overall ranking is sensitive to this choice. MolCraft (rank 1) and VOXBIND (rank 2) lead primarily on Interaction scores. A uniform weighting scheme would change rankings.
**Fix**: Provide explicit rationale for weight selection, conduct sensitivity analysis with alternative weights, or use uniform weighting as default.

### Issue 3: Lead-Optimization Evaluation Has Asymmetric Protocol (Major)
**Location**: Page 8 - Extension on Subtasks Setup
**Severity**: Major
**Evidence**: Only 6 of 12 methods are evaluated. Auto-regressive methods are fine-tuned from de novo pretrained weights; diffusion methods are trained from scratch due to zero-center-of-mass shift.
**Impact**: (a) 50% method drop without selection-bias discussion; (b) asymmetric training (pretrained vs scratch) confounds task difficulty comparisons across method families.
**Fix**: Report selection criteria explicitly, discuss confound, and consider training all methods from scratch with matched iterations.

### Issue 4: Weak Conclusion with Missing Synthesis (Moderate)
**Location**: Page 10 - Section 6
**Severity**: Moderate
**Evidence**: The conclusion recaps what CBGBench does rather than synthesizing what was learned. Limitations (voxel methods not in codebase, SA deficiency, 1D/2D methods) are mentioned without concrete scope bounds.
**Impact**: Readers cannot extract a clear, final takeaway about which methods work best, under what conditions, and which open problems remain.
**Fix**: Restructure conclusion as: (a) validated findings with evidence anchors, (b) bounded limitations, (c) prioritized future work.

### Issue 5: Real-World Validation Is Too Narrow (Moderate)
**Location**: Page 9-10 - Section 5.3
**Severity**: Moderate
**Evidence**: Only 2 GPCR targets (ADRB1, DRD3) are tested. The claim of "generalizability and effectiveness of our benchmark" (Page 2, bullet 5) is extrapolated from a single protein family.
**Impact**: The claim overstates the evidence. Performance on GPCRs may not predict performance on other target classes.
**Fix**: Either test additional target families or bound the claim to GPCRs.

## Actionable Suggestions
### S1: Add a Controlled Backbone Ablation (Must, P0)
**Problem**: The GVP↔auto-regressive / EGNN↔diffusion confound makes all paradigm-level conclusions uninterpretable.
**Action**: Implement at least one cross-condition: e.g., replace EGNN with GVP in TargetDiff's diffusion framework, or implement an EGNN-based variant of Pocket2Mol's auto-regressive framework. Compare performance within the same backbone.
**Alternative** (less costly): Explicitly bound all paradigm conclusions. Replace "diffusion-based models achieve state-of-the-art" with "among methods using EGNN backbones, diffusion-based models (MolCraft, TargetDiff) achieve top rankings; whether this advantage holds under GVP backbones remains untested."
**Expected gain**: Claims become scientifically defensible.

### S2: Justify or Replace the Weighted Ranking Scheme (Must, P0)
**Problem**: The 2:1 weighting of Interaction vs other aspects is unexplained.
**Action**: Either (a) justify the weighting with domain-specific rationale (e.g., "binding affinity correlates better with downstream success than chemical properties"), (b) report results under uniform weighting as sensitivity analysis, or (c) use equal weights as default with Interaction weight as a configurable parameter.
**Expected gain**: Ranking becomes transparent and reproducible.

### S3: Address Lead-Optimization Selection Bias (Must, P1)
**Problem**: 12→6 method drop and asymmetric training (finetuned vs scratch).
**Action**: Add a table showing which methods are included/excluded per subtask with explicit reasons. Discuss the finetune-vs-scratch confound in limitations. Consider training all methods from scratch for lead-optimization tasks in a follow-up.
**Expected gain**: Readers can assess result reliability despite reduced coverage.

### S4: Strengthen Conclusion Structure (Nice-to-have, P2)
**Problem**: Conclusion is purely descriptive.
**Action**: Restructure as: (a) paragraph summarizing validated findings (with table/figure references), (b) paragraph with bounded limitations, (c) paragraph with 2-3 prioritized future directions.
**Mentor Revised Version**:
"CBGBench's main findings are: (1) CNN-based voxel methods remain competitive with continuous GNN methods, particularly on interaction metrics (Tables 5, 7); (2) among continuous methods, MolCraft (Bayesian Flow Network) ranks first overall, with TargetDiff a close second; (3) domain-knowledge integration has not yet yielded consistent improvements over data-driven baselines; (4) scaffold hopping is the most challenging lead-optimization subtask (Table 8), with most methods yielding negative MPBG scores. Limitations include the architecture-paradigm confound discussed in Section 5.1.1, reduced evaluation coverage in lead-optimization tasks, and validation on only two GPCR targets. Future work should prioritize disentangling architecture effects from generative paradigm effects, extending the benchmark to additional target families, and incorporating wet-lab validation on selected candidates."

### S5: Improve Title (Nice-to-have, P2)
**Problem**: Title contains a typo (CBGB ENCH) and does not clearly signal that this is a benchmark paper.
**Action**: Fix typo. Consider: "CBGBench: A Unified Benchmark for Structure-Based Drug Design via 3D Binding Graph Completion"

### S6: Add Statistical Significance Information (Nice-to-have, P2)
**Problem**: Tables 3-6 report point estimates without variance or significance.
**Action**: For the next version, report multi-seed runs (at least 3 seeds) with mean±std for key metrics, or note that variance is unavailable due to computational cost.
**Expected gain**: Readers can assess the reliability of reported differences.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)

**Target**: 5-sentence compact abstract.

- **S1 (Problem + Domain)**: "Structure-based drug design (SBDD) aims to generate molecules that bind target proteins, but evaluating and comparing SBDD methods is hampered by non-standardized experimental setups, coupled implementations, and narrow task definitions."

- **S2 (Gap)**: "Existing comparisons are unreliable because methods use different data splits, docking programs, and network architectures, making it impossible to attribute performance differences to algorithmic innovations."

- **S3 (Proposed Method)**: "We propose CBGBench, a benchmark that unifies SBDD as a 3D complex binding graph completion task, enabling systematic categorization of 12 methods by position representation (voxelized vs continuous), generation order (one-shot vs auto-regressive), and prior integration (domain-knowledge vs data-driven)."

- **S4 (Key Results)**: "Across de novo generation and four lead-optimization tasks — linker, fragment, side-chain, and scaffold design — we find that CNN-based voxel methods remain highly competitive on interaction metrics, MolCraft achieves the top overall ranking, and scaffold hopping is the most challenging subtask for all tested methods."

- **S5 (Bounded Implication + Resource)**: "Our results provide a standardized reference for SBDD method comparison and highlight the need for controlled architecture ablation. Codebase and evaluation pipeline are publicly available."

### Introduction Outline (Complete)

**Current storyline**: Background (GNNs+generative models → SBDD) → Gap (lack of benchmark, non-standardized splits/programs, coupled modules) → Task scope limitation → Solution (CBGBench: graph completion formulation, three-dichotomy taxonomy, comprehensive evaluation, task extension) → Bullet conclusions.

**Critique of current storyline**: The gap paragraph mixes two distinct issues (evaluation standardization + task scope limitation) in one flow. The contribution presentation uses "Firstly... Secondly... Moreover..." enumeration. Transition from gap to solution is abrupt.

**Recommended storyline** (Big Picture → Gap → Solution → Evidence → Contribution summary):

| Paragraph | Role | Content |
|-----------|------|---------|
| P1 | Big Picture | SBDD's importance; growing family of methods; challenge: comparing them fairly. |
| P2 | Concrete Gap (Standardization) | Three specific problems: (a) different splits/programs across papers, (b) coupled implementations hide module-level contributions, (c) no unified codebase. |
| P3 | Concrete Gap (Scope) | De novo generation alone is insufficient; lead optimization tasks (linker, scaffold, etc.) are equally important but largely unevaluated. |
| P4 | Solution Overview | CBGBench as answer: graph completion formulation → three-dichotomy taxonomy → modular implementation → comprehensive evaluation → task extension. |
| P5 | Contribution Summary | Three explicit contributions with evidence preview. |

**Paragraph-level Mentor Revised Version for P2 (Gap - Standardization)**:

"Despite the growing number of SBDD methods, the field lacks a standardized evaluation framework. Concretely, different works use different train-test splits of the same dataset (e.g., CrossDocked2020 splits differ between GraphBP and Pocket2Mol), different docking evaluators (AutoDock Vina vs Gnina), and different network architectures (EGNN vs GVP) — making it impossible to determine whether reported improvements reflect genuine algorithmic advances or evaluation design choices. Furthermore, model implementations are tightly coupled, so the contribution of individual modules cannot be isolated. These barriers to fair comparison motivate the need for a unified benchmark with standardized protocols, modular implementations, and comprehensive evaluation."

**Paragraph-level Mentor Revised Version for P4 (Solution Overview)**:

"We propose CBGBench, a benchmark that addresses these gaps through three design choices. First, we reformulate SBDD as a 3D binding graph completion task (fill-in-the-blank), which naturally accommodates both full molecule generation and partial structure optimization. This formulation enables a systematic taxonomy of methods along three independent axes: position representation (voxelized vs continuous), generation order (one-shot vs auto-regressive), and prior knowledge (domain-guided vs data-driven). Second, we implement this taxonomy in a modular codebase that standardizes data processing, training, sampling, and evaluation across methods while allowing component-level swapping. Third, we extend evaluation beyond de novo generation to four lead-optimization subtasks — linker design, fragment growing, side-chain decoration, and scaffold hopping — using a unified protocol covering substructure, chemical property, interaction, and geometry metrics."

### Alignment Checks

- **Problem alignment**: The gap (non-standardized evaluation, narrow task scope) directly motivates the solution (unified benchmark, task extension). ✓
- **Variable alignment**: Core concepts from introduction (fill-in-the-blank, three dichotomies, four evaluation aspects, lead-optimization tasks) appear as section headings and experiment variables. ✓
- **Contribution-evidence alignment**: C1 (unified framework) is supported by the taxonomy and modular codebase; C2 (task extension) by Section 5.2 results; C3 (comprehensive evaluation) by Tables 3-7. Minor gap: the introduction claims "fair ranking" but the weighting scheme justification is missing — see Issue 2.

## Priority Revision Plan
### P0 Items (Must, Publication-Critical)

| Priority | Issue | Action | Expected Gain | Effort |
|----------|-------|--------|---------------|--------|
| P0.1 | Architecture-paradigm confound (Critical) | Add cross-backbone ablation (EGNN in auto-regressive or GVP in diffusion) OR explicitly bound all paradigm claims to the backbone used. | Core conclusions become scientifically defensible. | High (experiment) / Low (bound claims) |
| P0.2 | Ranking weight justification (Major) | Provide rationale for 0.4/0.2/0.2/0.2 weights or switch to uniform weighting with sensitivity analysis. | Ranking transparency. | Low (editing + one table) |

### P1 Items (Must, High Impact)

| Priority | Issue | Action | Expected Gain | Effort |
|----------|-------|--------|---------------|--------|
| P1.1 | Lead-optimization selection bias (Major) | Add exclusion table with reasons; discuss finetune-vs-scratch confound explicitly in limitations. | Evaluation validity. | Low (editing) |
| P1.2 | Weak conclusion (Moderate) | Restructure conclusion into validated findings + bounded limitations + future work. | Reader clarity. | Low (editing) |

### P2 Items (Nice-to-Have, Quality Improvement)

| Priority | Issue | Action | Expected Gain | Effort |
|----------|-------|--------|---------------|--------|
| P2.1 | LBE analysis in main text (Minor) | Move summary of LBE validity discussion from Appendix B.4 to main text. | Metric transparency. | Low |
| P2.2 | Real-world validation scope (Moderate) | Test on 2-3 additional target families (e.g., kinase, protease) or bound claim to GPCRs. | Claim defensibility. | Medium |
| P2.3 | Task decomposition justification (Minor) | Report fraction of molecules excluded by linker/fragment criteria and justify thresholds. | Dataset transparency. | Low |
| P2.4 | Related-work reorganization (Minor) | Restructure around three-dichotomy taxonomy rather than chronological listing. | Readability. | Low |
| P2.5 | Statistical significance (Minor) | Add multi-seed variance for key metrics in appendix. | Result reliability. | Medium |

### Revision Execution Map

```text
ASCII Diagram — Revision Strategy Roadmap

[P0.1: Architecture confound]
  → Option A: Add cross-backbone experiment (high effort, highest impact)
  → Option B: Bound all paradigm claims explicitly (low effort, acceptable)
  → Expected: Claims become defensible

[P0.2: Ranking weights]
  → Add justification or sensitivity table
  → Expected: Transparent ranking

[P1.1: Lead-optimization bias]
  → Add exclusion table + discussion
  → Expected: Readers can assess reliability

[P1.2: Conclusion restructure]
  → Rewrite as findings + limitations + future work
  → Expected: Clear takeaway message

[P2.x: Polish items]
  → Implement in parallel with P0/P1
  → Expected: Overall quality improvement
```

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory

| Exp ID | Objective/Hypothesis | Setup (data/split/protocol/baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|--------|---------------------|---------------------------------------|---------|--------------|-----------------|-------------------|
| E1 | De novo generation: compare 12 methods on CrossDocked2020 | CrossDocked2020 (LiGAN/3DSBDD split), 99,900 train / 100 test, 5M iterations, default hyperparameters per method | Substructure (JSD, MAE), Chemical (QED, SA, LogP, LPSK), Interaction (Vina Score/Min/Dock, MPBG, LBE, PLIP), Geometry (JSDBL, JSDBA, clash ratios), Friedman ranking | MolCraft #1, VOXBIND #2, TargetDiff #3 overall; CNN methods competitive on interaction | C1, C3 | Architecture-paradigm confound (GVP↔AR, EGNN↔diffusion); no multi-seed variance |
| E2 | Lead optimization: linker/fragment/side-chain/scaffold design | CrossDocked2020 splits; 6 methods (continuous GNN, no domain knowledge); finetune AR, scratch diffusion | Vina Score/Min/Dock, MPBG, LBE, QED, LogP, SA, LPSK | Scaffold hopping hardest; linker design easiest; performance gaps smaller than de novo | C2 | 6/12 method coverage; finetune-vs-scratch confound; no domain-knowledge methods included |
| E3 | Real-world disease target validation | ADRB1, DRD3 (GPCRs); 200 actives each; pretrained de novo models; 8 methods + GEOM-DRUG control | t-SNE chemical distribution overlap, Vina Dock Energy, LBE distribution | Rankings broadly consistent with de novo; D3FG shows strong performance on ADRB1 | Generalizability claim | Only 2 GPCR targets; no non-GPCR validation |
| E4 | Validity analysis | 100 mols/pocket, Refine+OpenBabel reconstruction; valid if largest fragment >85% atoms | Validity rate (Table 23, Appendix E.4) | TargetDiff 0.96, MolCraft 0.95, DecompDiff 0.89 highest validity | Supplementary | Validity metric (85% threshold) not standard; missing molecule-level analysis |
| E5 | Interaction pattern analysis (Appendix E.1.2) | PLIP profiling of 7 interaction types across methods | Frequency and distribution of hydrophobic/H-bond/π-stack/etc. | Most models capture hydrophobic + H-bond patterns; some over-generate hydrophobic interactions | Interaction evaluation | Reference molecules have only 2 interaction types (hydrophobic, H-bond) — limited ground truth diversity |

### Research-Theme Gap Diagnosis

**Gap 1 (New Knowledge)**: The benchmark's main scientific value is providing reliable cross-method comparisons. However, the architecture-paradigm confound means that the strongest claimed findings ("diffusion models achieve SOTA", "CNN methods are competitive") cannot be causally attributed to the claimed mechanisms. Without controlled ablation, the benchmark generates descriptive rankings rather than mechanistic insight.

**Gap 2 (Reproducibility/Reusability)**: The unified codebase is a strong asset. Missing elements include: (a) multi-seed variance reporting, (b) explicit configuration files for lead-optimization tasks (currently only referenced for de novo), (c) Docker environment specification for exact reproduction.

**Gap 3 (Impact on Practice)**: The finding that scaffold hopping is most challenging and that current domain-knowledge integration shows limited gains are actionable insights for method developers. However, the narrow validation (2 GPCR targets) limits practical confidence.

### Proposed Research Experiments

| Exp ID | Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost/Time | Paper-Quality Gain |
|--------|-------------|------------|----------------|---------------------|---------|-------------------|----------------|-------------------|
| P-E1 | Architecture vs paradigm disentanglement | EGNN-backbone auto-regressive method will close gap with diffusion methods | Implement EGNN-based version of Pocket2Mol (replace GVP with EGNN), retrain | Original Pocket2Mol (GVP), TargetDiff (EGNN+diffusion) | Vina Dock, QED, JSDfg, Validity | Performance gap between EGNN-Pocket2Mol and TargetDiff narrows vs GVP-Pocket2Mol vs TargetDiff | High (engineering ~2-4 weeks) | Resolves the most critical confound; enables causal attribution |
| P-E2 | Multi-family real-world validation | Benchmark rankings on non-GPCR targets are consistent with de novo | Redock on 3 additional targets from different families (e.g., kinase: EGFR, protease: HIV-1 protease, nuclear receptor: AR) | De novo rankings from Table 7 as reference | Vina Dock Energy, LBE, validity | Rank correlation (Spearman ρ) >0.7 with de novo rankings | Medium (1-2 weeks compute) | Strengthens generalizability claim beyond 2 GPCRs |
| P-E3 | Weighting sensitivity analysis | Uniform weighting produces similar rankings | Recompute overall ranking with uniform weights (0.25 each) and alternative weighting schemes | Original 0.4/0.2/0.2/0.2 weighting | Spearman rank correlation between weighting schemes | ρ > 0.9 between schemes | Low (<1 day) | Validates ranking robustness |
| P-E4 | Multi-seed variance reporting | Performance differences across methods are larger than within-method variance | Run 3 seeds for top-3 methods (MolCraft, VOXBIND, TargetDiff) plus one AR method (Pocket2Mol) on de novo task | Single-seed results from current paper | Mean±std for key metrics | Within-method std < cross-method gap | Medium (1-2 weeks) | Enables statistical reliability assessment |

```text
ASCII Diagram — Experiment Upgrade Plan

P0: Publication-Critical
├── P-E1: EGNN-based Pocket2Mol (architecture confound resolution)
└── P-E3: Weighting sensitivity analysis

P1: High Impact
├── P-E2: Multi-family real-world validation (kinase, protease, nuclear receptor)
└── P-E4: Multi-seed variance (top 3-4 methods)

P2: Quality Enhancement
├── Task decomposition statistics
├── Lead-optimization exclusion table
└── Dockerized reproduction environment

Timeline: P0 before resubmission; P1 for next revision; P2 ongoing
```

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score: 6.0/10**

*Research Value (primary dimension): 6/10* — The benchmark addresses a genuine need for standardized SBDD evaluation and provides the broadest method coverage to date (12 methods, 5 tasks). However, the architecture-paradigm confound limits the scientific conclusions that can be drawn from the comparison. The codebase release and task extension are practically valuable.

*Novelty (primary dimension): Deferred* — C1-C3 (unified framework, task extension, comprehensive evaluation) are benchmark-building contributions whose novelty cannot be assessed without external literature comparison. External verification was unavailable in this run. See Novelty Verification section above.

*Validity/Soundness: 5/10* — The confound between generative paradigm and network architecture is the most serious validity concern. The ranking weighting is arbitrary. Lead-optimization evaluation has significant selection bias. These issues reduce confidence in the reported rankings and conclusions.

*Reproducibility: 8/10* — The unified codebase, configuration files, standardized training pipelines, and detailed hyperparameter tables (Table 13) are strong assets for reproducibility. Missing: multi-seed variance and Docker environment specification.

*Presentation: 7/10* — The paper is clearly written and well-organized, but the introduction's list-like structure, the conclusion's descriptive rather than synthetic nature, and the title typo reduce readability.

**Post-Revision Target: [7.0, 8.0]/10**

If P0 items are addressed (architecture confound resolved or bounded, ranking weights justified) and P1 items implemented (lead-optimization bias discussed, conclusion restructured), the paper could achieve 7.0-8.0/10. The main remaining limitation would be the narrow real-world validation (2 GPCR targets), which would still bound the generalizability claims. Adding multi-family validation (P-E2) could further raise the target to 7.5-8.0/10.

**Scoring Rubric Reference:**
- 10: Groundbreaking, no significant weaknesses
- 9: Excellent, minor weaknesses
- 8: Very good, some weaknesses
- 7: Good, moderate weaknesses
- 6: Fair, significant weaknesses
- 5: Marginal, major weaknesses
- ≤4: Reject, critical flaws