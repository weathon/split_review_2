## Summary
# Final Review Report

## Summary

This paper investigates the in-context few-shot learning capabilities of encoder-decoder (seq2seq) models, which have been historically overshadowed by decoder-only architectures. The authors propose two key adaptations to improve seq2seq few-shot performance: (1) objective-aligned prompting, which aligns inference-time prompt structures (e.g., sentinel tokens, mode tags) with pretraining objectives, and (2) fusion-based approaches (early- and late-fusion) inspired by FiD and RAG, which independently encode few-shot examples to mitigate sequence length constraints and permutation bias. Extensive experiments across NLU and generation benchmarks demonstrate that T5-11B with these adaptations can outperform significantly larger decoder-only models (e.g., OPT-66B) and exhibit robust performance across varying shot settings.

**Core Audit Findings:** The paper presents a valuable empirical investigation and practical toolkit for seq2seq in-context learning. However, the novelty claims are overstated, particularly regarding the "first-ever" comparison and the omission of directly relevant prior work (e.g., Patel et al., 2022). The methodological formulations for fusion lack critical implementation details (probability normalization, positional embeddings), and several performance claims lack statistical validation. The limitations section is overly generic. With targeted revisions to bound novelty claims, clarify mathematical formulations, and strengthen statistical rigor, the paper can make a solid contribution to the ICL literature.

## Strengths
1. **Comprehensive Empirical Evaluation:** The paper provides a systematic and extensive comparison of seq2seq models across diverse NLU and generation tasks, filling a notable gap in the literature where seq2seq few-shot learning has been underexplored compared to decoder-only models.
2. **Practical Prompting Insights:** The investigation into objective-aligned prompting (sentinel tokens, mode tags) offers actionable guidance for practitioners working with T5-family models, demonstrating that aligning inference prompts with pretraining objectives yields substantial performance gains.
3. **Effective Fusion Adaptation:** The adaptation of early- and late-fusion mechanisms to seq2seq few-shot learning is a creative and effective solution to sequence length constraints and permutation bias. The empirical results showing robust performance and reduced variance are compelling.
4. **Toolkit Contribution:** The development and planned release of a unified in-context evaluation toolkit for seq2seq models will benefit the community by standardizing evaluation protocols for encoder-decoder architectures.

## Weaknesses
1. **Overstated Novelty and Missing Prior Work:** The abstract and introduction claim this is a "first-ever extensive experiment" comparing decoder-only and seq2seq few-shot learning, omitting Patel et al. (2022), which directly explores bidirectional models for few-shot learning. This creates a false research gap and undermines the paper's novelty positioning.
2. **Incomplete Mathematical Formulations:** The formulas for late-fusion and early-fusion lack critical details. Late-fusion sums probabilities without explicit normalization, and early-fusion concatenates hidden states without specifying how positional embeddings are handled. This hinders reproducibility and theoretical clarity.
3. **Lack of Statistical Validation:** Key performance claims, such as T5-early/late outperforming OPT-66B by up to 3.6%, are presented without standard deviations or significance tests across tasks. This makes it difficult to assess whether the margins are robust or within variance noise.
4. **Speculative Mechanistic Explanations:** The explanation for early-fusion outperforming late-fusion ("implicitly selects examples") is speculative and lacks supporting evidence (e.g., attention weight visualization or controlled ablations). Similarly, the claim that early-fusion eliminates permutation bias is theoretically inaccurate, as concatenated sequences retain positional dependencies.
5. **Generic Limitations Section:** The limitations discussion is vague, mentioning "discrepancies between benchmark performance and qualitative effectiveness" and "mismatches in pretraining data" without concrete examples or quantitative context. This reduces transparency regarding the boundaries of the findings.

## Key Issues
1. **Novelty Overclaim & Literature Gap (Critical):** The omission of Patel et al. (2022) in the motivation and gap statement fundamentally misrepresents the state of the field. This must be corrected to accurately position the paper's contributions relative to existing bidirectional few-shot learning research.
2. **Mathematical Reproducibility Risks (Major):** The fusion formulas require explicit normalization for late-fusion and positional embedding specifications for early-fusion. Without these, independent reproduction is ambiguous, and the theoretical soundness of the aggregation mechanisms is unclear.
3. **Statistical Rigor Deficit (Major):** Performance comparisons against much larger decoder-only models lack variance reporting and significance testing. Given the small average margins (e.g., 3.6%), statistical validation is essential to rule out chance fluctuations or dataset-specific biases.
4. **Theoretical Inaccuracy on Permutation Bias (Major):** Claiming that early-fusion eliminates permutation bias is theoretically incorrect due to sequential concatenation and positional embeddings. The distinction between mathematical invariance (late-fusion) and empirical robustness (early-fusion) must be clarified to avoid misleading readers.

## Actionable Suggestions
1. **Revise Novelty Positioning:** Acknowledge Patel et al. (2022) in the introduction and related work. Reframe the gap to focus on the lack of *structured prompt alignment* and *fusion-based mechanisms* for seq2seq ICL, rather than claiming the first comparison.
2. **Clarify Fusion Formulations:** 
   - For late-fusion, explicitly add a normalization term (e.g., averaging probabilities or applying softmax over summed logits).
   - For early-fusion, specify how positional embeddings are assigned to the concatenated hidden states (e.g., sequential indexing or learned fusion positions).
3. **Add Statistical Validation:** Report standard deviations or confidence intervals for average scores across tasks. Include a paired significance test (e.g., t-test or bootstrap) when comparing T5-early/late against OPT-66B to validate the 3.6% margin.
4. **Correct Permutation Bias Claims:** Distinguish between late-fusion's theoretical permutation invariance and early-fusion's empirical robustness. Provide a brief analysis of probability variance before metric rounding to substantiate the claim that positional effects are negligible.
5. **Strengthen Limitations Section:** Quantify pretraining data/token mismatches between baselines. Specify which tasks show the largest performance-qualitative gaps. Discuss architectural constraints that might limit fusion adaptation to BART-like models.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem/Domain):** In-context learning (ICL) has predominantly been explored in decoder-only models, leaving the few-shot potential of encoder-decoder (seq2seq) architectures underutilized.
- **S2 (Significance/Challenge):** Seq2seq models offer bidirectional context encoding but face structural limitations in few-shot settings, including sequence length constraints and prompt-pretraining misalignment.
- **S3 (Prior Gap):** While recent studies hint at bidirectional few-shot capabilities, systematic evaluations and targeted prompt adaptations remain lacking.
- **S4 (Proposed Method):** We introduce objective-aligned prompting strategies and adapt fusion-based mechanisms (early- and late-fusion) to independently encode few-shot examples, mitigating length constraints and permutation bias.
- **S5 (Key Result/Implication):** Extensive experiments demonstrate that T5-11B with these adaptations outperforms significantly larger decoder-only baselines (e.g., OPT-66B) across diverse NLU and generation tasks, establishing seq2seq models as robust few-shot learners.

### Introduction Outline (Complete)
- **P1 (Big Picture):** Introduce ICL as a paradigm shift in LLM utilization, highlighting its prevalence in decoder-only models.
- **P2 (Gap & Motivation):** Acknowledge prior explorations of seq2seq ICL (e.g., Patel et al., 2022) but identify the lack of structured prompt alignment and efficient fusion mechanisms to overcome architectural constraints.
- **P3 (Proposed Solution):** Present objective-aligned prompting (sentinel tokens/mode tags) and fusion-based approaches (early/late) as targeted adaptations for seq2seq few-shot learning.
- **P4 (Evidence Preview):** Summarize key empirical findings: performance gains from prompt alignment, robustness of fusion methods, and competitive results against larger decoder-only models.
- **P5 (Contributions):** List contributions clearly: (1) systematic evaluation toolkit, (2) objective-aligned prompting insights, (3) fusion adaptation for seq2seq ICL, and (4) empirical demonstration of seq2seq competitiveness.

## Priority Revision Plan
| Priority | Action Item | Expected Impact | Effort |
|---|---|---|---|
| **P0** | Acknowledge Patel et al. (2022) and reframe novelty claims in Abstract/Intro. | Fixes critical literature gap and prevents rejection for overstated novelty. | Low |
| **P0** | Clarify fusion formulas: add normalization for late-fusion, specify positional embeddings for early-fusion. | Ensures mathematical reproducibility and theoretical soundness. | Low |
| **P1** | Add statistical validation (std/CI) for average scores and significance tests vs. OPT-66B. | Strengthens credibility of performance claims against larger models. | Medium |
| **P1** | Correct permutation bias claims: distinguish theoretical invariance (late) vs. empirical robustness (early). | Prevents theoretical inaccuracies and reviewer criticism. | Low |
| **P2** | Expand limitations section with concrete examples of data mismatches and qualitative gaps. | Improves transparency and scientific rigor. | Low |
| **P2** | Provide attention weight visualization or ablation to support early-fusion selection hypothesis. | Adds mechanistic depth to the analysis. | Medium |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Target input placement (encoder vs decoder) | SuperGLUE, 1/5/10-shot, T5-family | Accuracy | Encoder placement yields +20.5%p gain | Design principle validated | Gain reflects expected behavior, not novel breakthrough |
| E2 | Objective-aligned prompting (sentinel/mode tags) | SuperGLUE, 0-10-shot | Accuracy | Aligning with pretraining improves scores | Prompt alignment insight | Lacks analysis of why T5-LM/T0 benefit despite no sentinel pretraining |
| E3 | Fusion-based approaches (early/late) | 11 NLU tasks, T5 vs OPT/BLOOM | Accuracy | T5-early/late outperform OPT-66B by ~3.6% avg | Fusion effectiveness | Lacks statistical significance testing |
| E4 | Generation task validation | XSum, WebNLG, 1/5/32-shot | ROUGE | Fusion improves generation performance | Robustness across task types | Lower performance than decoder-only on WebNLG |
| E5 | Permutation bias analysis | 4 tasks, 5-shot, 120 permutations | Avg/Std | Fusion methods show ~0 std | Permutation robustness | Early-fusion theoretical invariance not fully addressed |

### Research-Theme Gap Diagnosis
The core research-value claims (seq2seq competitiveness, fusion efficacy) are well-supported empirically but lack statistical rigor and mechanistic validation. The novelty claim is weakened by incomplete literature positioning.

### Proposed Research Experiments (P0/P1/P2)
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| Statistical robustness of T5 vs OPT-66B | Performance margin is statistically significant | Run 5 seeds across all tasks, compute CI | OPT-66B, T5-early/late | Accuracy, 95% CI | Non-overlapping CIs | Low | Validates core performance claim |
| Early-fusion attention mechanism | Early-fusion implicitly weights relevant examples | Visualize cross-attention weights per example | Late-fusion, Original | Attention entropy | Lower entropy in early-fusion | Low | Supports mechanistic explanation |
| Normalization sensitivity | Unnormalized loss introduces length bias | Compare normalized vs unnormalized scoring | Same models/tasks | Accuracy delta | Delta < 1% | Low | Justifies methodological choice |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 6/10  
**Post-Revision Target:** [7, 8]/10

**Scoring Rationale:** The paper presents a valuable empirical investigation and practical toolkit for seq2seq in-context learning, with compelling results demonstrating the competitiveness of smaller encoder-decoder models against larger decoder-only baselines. The fusion-based adaptation is creative and effective. However, the score is moderated by overstated novelty claims (omission of Patel et al., 2022), incomplete mathematical formulations for fusion mechanisms, and a lack of statistical validation for key performance comparisons. Addressing these issues through bounded novelty positioning, formula clarification, and variance reporting would significantly strengthen the paper's scientific rigor and impact.

---

### ASCII Diagram — Paper Structure & Evidence Map
```text
[Problem: Seq2seq ICL underexplored vs Decoder-only]
    -> [Gap: Lack of structured prompt alignment & fusion mechanisms]
    -> [Method: Objective-aligned prompting + Early/Late Fusion]
    -> [Evidence: SuperGLUE/NLU/Generation benchmarks, T5 vs OPT/BLOOM]
    -> [Claim: Seq2seq outperforms 6x larger models, eliminates permutation bias]
    -> [Risk: Novelty overclaim, missing stats, formula ambiguity]
    -> [Fix: Bound claims, add normalization/positional details, report CI]
```

### ASCII Diagram — Revision Strategy Roadmap
```text
Stage 1 (Immediate): Reframe novelty claims, acknowledge Patel et al. (2022)
Stage 2 (This Week): Clarify fusion formulas (normalization, positional embeddings)
Stage 3 (Before Submission): Add statistical validation (std/CI), correct permutation bias claims
```

### ASCII Diagram — Related-Work Taxonomy Tree (Layered)
```text
In-Context Learning Taxonomy (Root)
├── Branch 1: Decoder-Only ICL
│   ├── Leaf 1.1: Autoregressive prompting (Brown et al., 2020)
│   └── Leaf 1.2: Structured prompting (Hao et al., 2022)
├── Branch 2: Seq2seq / Bidirectional ICL
│   ├── Leaf 2.1: Zero-shot multitask prompting (Sanh et al., 2022)
│   ├── Leaf 2.2: Bidirectional few-shot exploration (Patel et al., 2022)
│   └── Leaf 2.3: Objective-aligned & Fusion adaptation (This Paper)
└── Branch 3: Retrieval-Augmented Generation
    ├── Leaf 3.1: Probability aggregation (RAG, Lewis et al., 2020)
    └── Leaf 3.2: Encoder fusion (FiD, Izacard & Grave, 2021)
```