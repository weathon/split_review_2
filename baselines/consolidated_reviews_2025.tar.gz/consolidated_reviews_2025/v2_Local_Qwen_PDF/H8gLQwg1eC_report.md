## Summary
# Final Review Report

## Summary
This paper addresses the impact of noisy human feedback on preference optimization for large language models (LLMs). Unlike prior works that assume noise-free feedback or analyze asymptotic convergence, the authors establish finite-step generalization guarantees for a broad family of preference optimization losses (GPO, including DPO, IPO, SLiC). By modeling reward margin dynamics under a von Mises-Fisher (vMF) distribution assumption, the authors derive a theoretical risk model showing that expected risk grows quadratically as $1/(1-c\epsilon)^2$ for low noise rates, transitioning to linear decline near $\epsilon=0.5$. Empirical validation on controlled settings and the real-world HH-RLHF dataset confirms these theoretical predictions. The work provides valuable theoretical insights into the robustness of preference optimization under noise, offering a predictive framework for finite-step fine-tuning.

## Strengths
1. **Novel Finite-Step Theoretical Framework:** The paper successfully moves beyond asymptotic convergence analysis, which often yields vacuous bounds for overparameterized LLMs. The finite-step reward margin dynamics provide a more realistic and tractable analysis for practical fine-tuning regimes.
2. **Unified GPO Analysis:** By framing DPO, IPO, and SLiC within a generalized preference optimization (GPO) family, the theoretical results are broadly applicable, enhancing the paper's impact and reusability across different alignment methods.
3. **Actionable Risk Model:** The derived risk model, predicting a transition from quadratic to linear risk growth near $\epsilon=0.5$, offers a concrete, testable hypothesis. The close match between theoretical predictions and empirical observations on HH-RLHF demonstrates strong practical relevance.
4. **Rigorous Mathematical Derivation:** The use of von Mises-Fisher distribution assumptions and concentration inequalities provides a solid mathematical foundation for bounding generalization error under noisy feedback.

## Weaknesses
1. **Theory-Experiment Gap (Fixed Encoder vs. Full Fine-Tuning):** The theoretical bounds are derived under a fixed-encoder assumption (last-layer tuning), yet the empirical validation on HH-RLHF uses full fine-tuning. This mismatch is not explicitly reconciled, potentially overstating the direct applicability of the bounds to the reported experiments.
2. **Restrictive Validity Range for Noise Rate:** The high-probability bound in Theorem 3.1 is valid only for relatively small noise rates $\epsilon$, depending on concentration $\gamma$ and separation $\theta$. The bound can become vacuous if the denominator approaches zero, and the transition to linear growth near $\epsilon=0.5$ relies on symmetry arguments rather than the high-probability bound itself.
3. **Vague Finite-Step Stopping Criterion:** The paper mentions analyzing generalization "when the loss is within a constant factor of its initial value" but lacks a precise mathematical definition (e.g., number of steps $T$ or relative loss threshold), weakening the rigor of the finite-step claim.
4. **Confounding SFT Noise in Real-World Experiments:** The experimental setup performs SFT on noisy preferred responses before DPO. This initialization noise is not modeled theoretically and may confound the isolation of DPO-specific noise effects.
5. **Strong Assumption for Theoretical Fit:** The assumption that "the true noiseless risk deviates from the observed average test error by no more than 1%" is used to force the theoretical fit but lacks empirical justification or sensitivity analysis.

## Key Issues
1. **Non-Vacuous Bound Conditions:** The risk bound $R(P) \le \frac{R_0}{(1 - \sqrt{R_0 \gamma (\epsilon + \dots)})^2}$ becomes vacuous if the denominator approaches zero. The paper must explicitly state the conditions on $\gamma$, $\theta$, and $\epsilon$ required to keep the bound informative.
2. **Reconciliation of Linear Transition:** The claim that risk transitions to linear growth near $\epsilon=0.5$ is supported by the symmetry argument (Eq. 17) and empirical results, but falls outside the strict validity range of Theorem 3.1. This gap needs explicit acknowledgment to avoid misleading readers about the theorem's scope.
3. **SFT Noise Confounding:** Performing SFT on noisy labels introduces initialization bias not captured by the theoretical model. This confounds the empirical validation of DPO-specific noise dynamics and should be addressed via ablation or explicit discussion.
4. **Justification of 1% Deviation Assumption:** The theoretical fit relies on assuming the noiseless risk deviates by at most 1% from observed error. Without reporting the variance of noiseless runs or providing a sensitivity analysis, this assumption appears ad hoc.

## Actionable Suggestions
1. **Clarify Finite-Step Criterion:** Replace the vague "constant factor of initial loss" with a precise definition, such as a fixed number of gradient steps $T$ or a relative loss decrease threshold (e.g., $\mathcal{L}_T \le (1-\delta)\mathcal{L}_0$).
2. **Explicitly Bound Theory Scope:** Add a remark after Theorem 3.1 stating the conditions on $\gamma$ and $\theta$ required for the bound to remain non-vacuous. Clarify that the linear transition near $\epsilon=0.5$ is derived from symmetry (Eq. 17) and empirical validation, not the high-probability bound.
3. **Address SFT Noise Confounding:** Acknowledge that SFT on noisy labels introduces initialization bias. If possible, provide an ablation comparing DPO initialized from a noiseless SFT vs. noisy SFT to isolate DPO-specific noise effects.
4. **Justify 1% Deviation Assumption:** Report the variance of noiseless test error across multiple seeds in Appendix A. Use this variance to justify the 1% deviation assumption or provide a sensitivity analysis showing how the fit changes under different deviation bounds.
5. **Expand Limitation Section:** Explicitly list the fixed-encoder assumption, vMF distribution simplification, and symmetric noise model as core limitations. Discuss how relaxing these assumptions could be directions for future work.

## Storyline Options + Writing Outlines
### Abstract Outline
- **S1 (Problem):** Aligning LLMs with human preferences via preference optimization is crucial, but human feedback is inherently noisy.
- **S2 (Gap):** Existing theoretical analyses assume noise-free feedback or asymptotic convergence, yielding vacuous bounds for practical finite-step fine-tuning.
- **S3 (Method):** We establish finite-step generalization guarantees for a broad family of preference optimization losses (GPO) under noisy feedback, modeling reward margin dynamics.
- **S4 (Key Insight):** We derive a risk model showing expected error grows quadratically as $1/(1-c\epsilon)^2$ for low noise, transitioning to linear decline near $\epsilon=0.5$.
- **S5 (Validation):** Empirical validation on controlled settings and HH-RLHF confirms these predictions, offering a predictive framework for robust alignment.

### Introduction Outline
- **P1 (Big Picture):** LLM alignment via preference optimization (DPO, IPO, SLiC) relies on human feedback, which is inevitably noisy due to annotator inconsistency.
- **P2 (Gap):** While empirical studies show performance degradation under noise, they lack predictive power. Existing theory assumes convergence, ignoring the finite-step dynamics of LLM fine-tuning.
- **P3 (Solution):** We analyze finite-step reward margin dynamics under a vMF distribution assumption, deriving generalization bounds for the GPO family.
- **P4 (Evidence):** Our theory predicts a quadratic-to-linear risk transition, validated empirically on synthetic and real-world datasets.
- **P5 (Contributions):** (1) First finite-step generalization guarantees for noisy GPO. (2) A practical risk model describing noise impact. (3) Comprehensive empirical validation.

## Priority Revision Plan
| Priority | Action | Expected Impact |
|---|---|---|
| **P0** | Clarify finite-step stopping criterion (e.g., fixed steps $T$ or relative loss threshold). | Resolves vagueness in theoretical scope; strengthens rigor. |
| **P0** | Explicitly state non-vacuous conditions for Theorem 3.1 bound and reconcile linear transition claim. | Prevents misinterpretation of theorem validity range; improves scientific transparency. |
| **P1** | Acknowledge SFT noise confounding in real-world experiments and justify 1% deviation assumption. | Isolates DPO-specific noise effects; validates empirical fit objectivity. |
| **P1** | Expand limitation section to include fixed-encoder, vMF, and symmetric noise assumptions. | Sets clear boundaries for theoretical claims; guides future work. |
| **P2** | Streamline abstract and introduction to highlight the derived risk model and practical implications. | Improves readability and immediate grasp of core novelty. |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Verify risk bound under controlled vMF distribution | Synthetic data, d=512, varying $\gamma, \theta$, DPO loss | Test accuracy vs $\epsilon$ | Accuracy decreases quadratically then linearly; matches theory | Yes | Fixed encoder only |
| E2 | Validate theory on real-world dataset | HH-RLHF, Llama-2-7B full fine-tuning, DPO | Test accuracy vs $\epsilon$ | Near-linear decline due to initial 30% noise; fits theory | Yes | SFT noise confounding |
| E3 | Verify theory on alternative GPO loss | Synthetic data, IPO loss | Test accuracy vs $\epsilon$ | Matches theoretical fit | Yes | Fixed encoder only |

### Research-Theme Gap Diagnosis
The core claim of finite-step generalization under noise is well-supported, but the gap between fixed-encoder theory and full-fine-tuning experiments remains. Additionally, the impact of SFT initialization noise is not isolated.

### Proposed Research Experiments
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Estimated Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| DPO-specific noise effect | SFT noise contributes significantly to observed degradation | Compare DPO initialized from noiseless SFT vs. noisy SFT | Noiseless SFT baseline | Test accuracy vs $\epsilon$ | Clear separation of curves | Low (reuse runs) | Isolates DPO dynamics |
| Full fine-tuning dynamics | Qualitative risk trends hold under full fine-tuning | Extend theoretical analysis to tunable $g(x)$ or empirical proxy | Fixed encoder bound | Risk bound tightness | Qualitative match | High (theory) | Bridges theory-experiment gap |
| Asymmetric noise robustness | Symmetric noise assumption limits practical applicability | Introduce instance-dependent noise rates | Symmetric noise baseline | Test accuracy vs $\epsilon$ | Model adapts to noise variance | Medium | Enhances practical relevance |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
Final Score: 6.5/10
Post-Revision Target: [7.5, 8.5]/10

**Rationale:** The paper presents a novel and theoretically rigorous analysis of finite-step generalization under noisy feedback, with strong empirical validation. The derived risk model offers practical value for understanding alignment degradation. However, the score is moderated by the theory-experiment gap (fixed encoder vs. full fine-tuning), the restrictive validity range of the high-probability bound, and the lack of explicit reconciliation for the linear transition claim. Addressing these issues by clarifying assumptions, bounding the theorem's scope, and justifying experimental choices would significantly strengthen the paper's scientific transparency and impact.