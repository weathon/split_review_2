## Summary
This paper introduces MIRReS, a two-stage inverse rendering framework that jointly reconstructs explicit geometry, materials, and lighting from multi-view images. Unlike prior implicit methods that suffer from representation biases or lack physical constraints, MIRReS extracts an initial coarse mesh and refines it using trainable vertex offsets guided by both radiance field and physically-based rendering (PBR) losses. The framework incorporates multi-bounce path tracing for accurate indirect illumination estimation and utilizes reservoir sampling to reduce Monte Carlo variance and accelerate convergence. Evaluated on the TensoIR and OWL datasets, the method achieves state-of-the-art performance in decomposition and relighting, particularly in scenes with complex shadows. The paper provides a solid methodological foundation for explicit mesh-based inverse rendering with global illumination, though it acknowledges limitations regarding initial geometry dependence and gradient detachment for indirect rays.

## Strengths
- **Explicit Mesh-Based PBR Framework:** The proposal of a two-stage framework that refines explicit triangular meshes using physically-based rendering is highly valuable for downstream graphics applications. The stable vertex-offset refinement strategy effectively addresses the topological instabilities common in prior mesh-based inverse rendering methods (e.g., NVdiffrec-MC).
- **Multi-Bounce Path Tracing for Indirect Illumination:** Integrating explicit multi-bounce path tracing into the inverse rendering pipeline is a strong technical contribution. It provides a more physically accurate estimation of indirect lighting compared to implicit radiance field caching, leading to cleaner albedo recovery and more realistic relighting in shadowed regions.
- **Reservoir Sampling for Convergence Acceleration:** The adaptation of reservoir sampling (ReSTIR) for direct illumination significantly reduces Monte Carlo variance. This enables stable gradient-based optimization with low sample counts, addressing a critical bottleneck in differentiable path tracing.
- **Comprehensive Empirical Validation:** The method is evaluated on both synthetic (TensoIR) and real-world (OWL) datasets, demonstrating consistent improvements over strong baselines (TensoIR, GS-IR, NVdiffrec-MC) in geometry reconstruction, albedo decomposition, and relighting quality. The ablation studies effectively isolate the contributions of reservoir sampling and multi-bounce tracing.

## Weaknesses
- **Gradient Detachment for Indirect Rays:** The manuscript explicitly states that gradients of indirect rays are detached due to GPU memory constraints. This means the optimization does not backpropagate through the recursive multi-bounce path tracing. Consequently, the claimed improvements in intrinsic decomposition may stem primarily from more accurate rendering estimates during loss computation rather than true multi-bounce gradient flow. This limits the physical optimization capability of the method.
- **Dependence on Initial Coarse Geometry:** The performance of the second-stage optimization heavily relies on the quality of the initial mesh extracted by NeuS2. In areas with high specularity or fine details, initial geometric errors propagate into incorrect material estimation and compromised novel view synthesis, as shown in the limitations section.
- **Unbounded Novelty and SOTA Claims:** The claim of being the "first inverse rendering framework that supports multi-bounce raytracing" is potentially vulnerable, as implicit methods (e.g., TensoIR, NeILF++) do estimate indirect illumination. Additionally, SOTA claims in the abstract and conclusion lack specific quantitative highlights or dataset bounding, reducing defensibility.
- **Missing Variance Reporting in Ablations:** The ablation studies report single-point metrics without variance (mean ± std) over multiple random seeds. Given the stochastic nature of Monte Carlo rendering and neural optimization, variance reporting is essential to assess the statistical reliability of the component contributions.
- **Lack of Training Budget Fairness Details:** The experimental setup does not explicitly report training time, samples per pixel (SPP), or GPU memory usage for the baselines. Since different methods have varying convergence dynamics, this omission makes it difficult to fully assess the fairness of the SOTA comparisons.

## Key Issues
1. **Gradient Flow Limitation in Multi-Bounce Tracing:** The detachment of indirect ray gradients fundamentally changes the nature of the optimization. The method should clearly distinguish between *unbiased rendering estimates* (which improve loss computation) and *differentiable multi-bounce optimization* (which backpropagates through bounces). Overstating the latter risks misleading readers about the method's physical optimization capabilities.
2. **Claim-Evidence Alignment for Novelty:** The "first" claim for multi-bounce raytracing needs precise scoping to "explicit mesh-based" to avoid conflict with implicit indirect lighting methods. Similarly, SOTA claims should be bounded to the evaluated benchmarks and supported by concrete metric deltas.
3. **Reproducibility and Fairness in Comparisons:** The absence of variance reporting in ablations and explicit training budget details (time, SPP, memory) for baselines reduces the reproducibility and perceived fairness of the empirical evaluation.

## Actionable Suggestions
- **Clarify Gradient Detachment Implications:** In Section 4.2, explicitly state that the performance gains from multi-bounce tracing primarily arise from unbiased rendering estimates during loss computation, rather than recursive gradient backpropagation. Frame fully differentiable multi-bounce tracing as a future direction.
- **Bound Novelty and SOTA Claims:** Qualify the "first" claim in the Related Work to specify "explicit mesh-based multi-bounce path tracing." In the Abstract and Conclusion, add concrete metric highlights (e.g., "improving albedo PSNR by X dB on TensoIR") and bound SOTA claims to the evaluated benchmarks.
- **Add Variance Reporting:** Report mean ± standard deviation over at least three random seeds for all ablation studies (Table 4) and main comparisons to ensure statistical reliability.
- **Detail Training Budgets:** Include a table or paragraph in the experimental setup specifying training time, SPP, and approximate GPU memory for MIRReS and all baselines to validate fairness.
- **Integrate Limitations into Conclusion:** Add a brief 2-3 sentence summary of the key limitations (initial mesh dependence, gradient detachment) to the end of the main Conclusion to improve scientific balance.

## Storyline Options + Writing Outlines
## Abstract Outline
- **S1 (Problem & Domain):** Inverse rendering decomposes multi-view images into geometry, materials, and lighting but remains ill-posed, especially under complex global illumination.
- **S2 (Prior Gap):** Implicit methods (NeRF/SDF) lack physical constraints and downstream mesh compatibility, while existing mesh-based methods suffer from topological instability and high-variance gradients.
- **S3 (Proposed Method):** We introduce MIRReS, a two-stage framework that refines explicit triangular meshes using physically-based multi-bounce path tracing and reservoir sampling for stable, low-variance optimization.
- **S4 (Key Results):** Evaluated on TensoIR and OWL datasets, MIRReS achieves state-of-the-art decomposition performance, particularly in highly-shadowed scenes, with improved albedo PSNR and relighting fidelity.
- **S5 (Implication):** The optimized explicit geometry seamlessly integrates with modern graphics engines, enabling practical applications in scene editing and material relighting.

## Introduction Outline
- **P1 (Big Picture & Challenge):** Define inverse rendering and its ill-posed nature. Highlight the shift toward neural implicit representations and their success in view synthesis.
- **P2 (Specific Gap):** Critique implicit methods for lacking strict physical constraints on material optimization and incompatibility with standard graphics pipelines. Note the instability of prior mesh-based approaches (e.g., NVdiffrec-MC) that break path tracing.
- **P3 (Proposed Solution):** Introduce MIRReS: a stable two-stage mesh refinement strategy guided by radiance fields, combined with explicit multi-bounce path tracing for accurate indirect illumination.
- **P4 (Key Technologies):** Detail the three pillars: (a) stable vertex-offset mesh optimization, (b) physically-based multi-bounce path tracing, and (c) reservoir sampling for convergence acceleration.
- **P5 (Evidence & Contributions):** Preview empirical results on TensoIR and OWL, emphasizing gains in shadowed scenes. List contributions explicitly, bounding novelty to explicit mesh-based multi-bounce tracing.

## Priority Revision Plan
| Priority | Action Item | Expected Impact | Effort |
|---|---|---|---|
| **P0** | Clarify gradient detachment implications in Section 4.2 and Conclusion. | Resolves major validity concern regarding multi-bounce optimization claims. | Low |
| **P0** | Bound novelty ("first") and SOTA claims with specific qualifiers and metric highlights. | Improves defensibility against reviewer pushback on prior implicit methods. | Low |
| **P1** | Add variance reporting (mean ± std) to ablation studies (Table 4) and main comparisons. | Strengthens statistical reliability and reproducibility of empirical results. | Medium |
| **P1** | Detail training budgets (time, SPP, memory) for baselines in experimental setup. | Validates fairness of SOTA comparisons across methods with different dynamics. | Medium |
| **P2** | Integrate a brief summary of limitations into the main Conclusion. | Improves scientific balance and reader awareness of method boundaries. | Low |

## Experiment Inventory & Research Experiment Plan
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | MIRReS vs SOTA baselines | TensoIR & OWL datasets; TensoIR, GS-IR, NVdiffrec-MC | CD, MAE, PSNR, SSIM, LPIPS | MIRReS achieves best scores across geometry, albedo, and relighting. | SOTA decomposition & relighting | Lacks variance reporting and explicit budget fairness details. |
| E2 | Ablation: Reservoir Sampling | TensoIR; w/ and w/o reservoir sampling | Albedo PSNR, Relighting PSNR | Reservoir sampling improves PSNR and reduces noise. | Convergence acceleration | Single-seed results. |
| E3 | Ablation: Multi-bounce Tracing | TensoIR; w/ and w/o multi-bounce | Albedo PSNR, Relighting PSNR | Multi-bounce tracing significantly boosts performance in shadowed scenes. | Indirect illumination accuracy | Gradients detached; gains from rendering estimates vs optimization unclear. |
| E4 | Ablation: SPP Sensitivity | Hotdog scene; SPP 4 to 64 | NVS PSNR | 32 SPP balances accuracy and efficiency; higher SPP doesn't necessarily improve. | Default configuration validity | Limited to one scene. |

## Research-Theme Gap Diagnosis
The core research value lies in enabling physically accurate inverse rendering on explicit meshes. However, the gap in *causal attribution* remains: without variance reporting and fully differentiable multi-bounce tracing, it is unclear how much of the gain comes from unbiased loss computation versus true gradient-based material optimization.

## Proposed Research Experiments
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| Statistical Reliability | MIRReS gains are consistent across random seeds. | Run E1 and E2 over 3-5 seeds. | Same baselines. | Mean ± std PSNR/CD | Std < 0.5 PSNR | Medium | Validates robustness of SOTA claims. |
| Gradient Flow Impact | Detached gradients limit material optimization in highly reflective areas. | Compare detached vs. attached gradients (if memory allows) or analyze error distribution in specular regions. | Full model vs. ablation. | Albedo error in specular masks | Quantified error delta | High | Clarifies true multi-bounce optimization capability. |
| Budget Fairness | MIRReS achieves gains with competitive compute budget. | Report training time, SPP, and memory for all methods. | Baselines retrained with matched SPP if possible. | Time/PSNR trade-off curve | Competitive efficiency | Low | Strengthens fairness of comparisons. |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
Final Score: 6.5/10

The paper presents a solid and valuable contribution to explicit mesh-based inverse rendering with global illumination. The integration of multi-bounce path tracing and reservoir sampling is technically sound and yields strong empirical results. However, the score is moderated by the gradient detachment limitation (which restricts true multi-bounce optimization), the lack of variance reporting in ablations, and unbounded novelty/SOTA claims that require tighter scoping. Addressing these issues would significantly strengthen the paper's defensibility and impact.

Post-Revision Target: [7.5, 8.5]/10