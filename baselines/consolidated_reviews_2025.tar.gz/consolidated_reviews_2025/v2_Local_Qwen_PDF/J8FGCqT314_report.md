## Summary
# Final Review Report

## Summary
This paper investigates the limitations of Decision Transformers (DT) in stochastic environments, attributing performance degradation to the accumulating variance of returns-to-go (RTG) signals. The authors provide a theoretical characterization of DT's optimality in deterministic settings and propose D2T2 (Decision Transformer with Temporal Difference via Steering Guidance). D2T2 replaces the RTG conditioning signal with a TD-learned steering guidance vector that directs the policy toward high-value states, effectively shortening the prediction horizon and eliminating the need for manual RTG specification during deployment. Extensive experiments on stochastic benchmarks (Tailgate, FrozenLake, CARLA) and D4RL suites demonstrate that D2T2 significantly improves upon DT and achieves competitive performance against strong offline RL baselines.

## Strengths
1. **Clear Motivation and Theoretical Insight:** The paper correctly identifies RTG variance accumulation as a core bottleneck for DT in stochastic environments. The theoretical characterization of DT's behavior in deterministic settings provides a solid foundation for understanding this limitation.
2. **Effective Methodological Integration:** D2T2 elegantly combines sequence modeling with TD-learned value functions. The shift from scalar return conditioning to state-based steering guidance is intuitive and aligns well with goal-conditioned RL paradigms.
3. **Comprehensive Empirical Evaluation:** The experiments cover a diverse range of environments, from simple stochastic grids (FrozenLake) to complex continuous control (CARLA, D4RL). The consistent improvement over DT and competitive performance against SOTA baselines validate the proposed approach.
4. **Practical Deployment Benefit:** By eliminating the need for manual RTG specification during evaluation, D2T2 addresses a significant practical hurdle of the original DT, making it more robust and easier to deploy in real-world scenarios.

## Weaknesses
1. **Idealized Theoretical Assumptions:** Proposition 1 assumes a "well-trained" DT that perfectly predicts the action maximizing the probability of achieving a target return. This probabilistic guarantee is not directly aligned with standard DT training objectives (e.g., MSE or cross-entropy loss), weakening the theoretical foundation.
2. **Vague VAE Motivation:** The introduction of the Variational Auto-Encoder (VAE) claims to "resolve" error propagation from suboptimal value functions by concentrating knowledge into a latent space. The mechanism is not explained, and the text admits VAE is optional and can hurt performance on simple tasks, suggesting it is a heuristic rather than a core contribution.
3. **Inconsistent Terminology and Notation:** The paper alternates between "Next-State Guidance" and "Steering Guidance". Additionally, PDF extraction artifacts (e.g., `bGt` instead of $\tilde{G}_t$) and naming inconsistencies (Proposition 1 vs. Theorem 1) reduce professional polish.
4. **Overclaimed SOTA Performance:** The abstract and conclusion claim "superior performance compared to the state-of-the-art", but Table 3 shows that baselines like MCQ outperform D2T2 on several Gym-MuJoCo tasks. The claims should be bounded to specific stochastic benchmarks where D2T2 excels.
5. **Experimental Transparency:** The Tailgate experiment omits the worst-performing DT baseline without clear justification, and the CARLA results make strong causal claims ("indicates that steering guidance is a more proper condition variable") based on limited evidence.

## Key Issues
1. **Theoretical-Training Misalignment:** The core theoretical claim (Proposition 1) relies on an idealized prediction assumption that DT maximizes $P(\sum r_k = R_t | \tau_t, a_t)$. Standard DT training minimizes sequence reconstruction loss. The paper does not bridge this gap, leaving the theoretical guarantee unsupported by the actual training procedure.
2. **Contradictory Discount Factor Setup:** Section 2.1 explicitly states "we consider finite-horizon MDPs without discounting factor", yet Equation (1) includes $\gamma^t r_t$. This direct contradiction confuses the mathematical setup and affects the interpretation of subsequent proofs.
3. **Unsubstantiated VAE Error Mitigation:** The claim that VAE encoding "resolves" error propagation from suboptimal $V(s)$ lacks mechanistic explanation. Without ablation or theoretical justification, the VAE appears as an ad-hoc regularization technique rather than a principled component.
4. **Overgeneralized SOTA Claims:** The abstract and conclusion assert global SOTA superiority, but empirical results (Table 3) show D2T2 underperforming MCQ on several MuJoCo tasks. This overclaim risks reviewer skepticism regarding the paper's objectivity.

## Actionable Suggestions
1. **Align Theory and Training:** Explicitly state the idealized prediction assumption in Proposition 1 or reframe it as an intuitive characterization. Add a brief discussion on how standard DT training objectives approximate this probabilistic guarantee.
2. **Fix Mathematical Contradictions:** Remove "without discounting factor" from Section 2.1 or set $\gamma=1$ explicitly in Equation (1). Ensure all subsequent equations and proofs are consistent with this choice.
3. **Reframe VAE as Optional Regularization:** Remove claims that VAE "resolves" error propagation. Instead, describe it as a stochastic regularization technique that benefits complex, high-dimensional tasks, supported by the ablation results in Appendix.
4. **Bound SOTA Claims:** Revise the abstract and conclusion to state that D2T2 achieves "competitive performance against SOTA baselines" or "significantly improves DT in stochastic settings", rather than claiming global superiority.
5. **Improve Experimental Transparency:** Include the omitted DT baseline in an appendix table or explain its exclusion clearly. Soften causal language in the CARLA discussion (e.g., change "indicates that" to "suggests that").
6. **Unify Terminology and Notation:** Consistently use "Steering Guidance" throughout the paper. Clean up notation artifacts (e.g., replace `bGt` with $\tilde{G}_t$) and fix the Proposition/Theorem naming inconsistency.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem & Gap):** Decision Transformers (DT) have shown great promise in offline RL but suffer from performance degradation in stochastic environments due to the accumulating variance of returns-to-go (RTG) signals.
- **S2 (Theoretical Insight):** We theoretically characterize this limitation, showing that while DT can recover optimal trajectories in deterministic settings, its reliance on recursive RTG updates leads to unstable conditioning under stochastic transitions.
- **S3 (Method):** To address this, we propose D2T2 (Decision Transformer with Temporal Difference via Steering Guidance), which replaces RTG with a TD-learned steering signal that guides the policy toward high-value states.
- **S4 (Mechanism & Benefit):** This design mitigates RTG variance, shortens the prediction horizon, and eliminates the need for manual RTG specification during deployment.
- **S5 (Results):** Experiments on stochastic benchmarks and D4RL suites demonstrate that D2T2 significantly improves upon DT and achieves competitive performance against strong offline RL baselines.

### Introduction Outline (Complete)
- **P1 (Motivation & Gap):** Introduce RvS and DT's success via RTG conditioning. Highlight the critical limitation: RTG variance accumulation in stochastic environments degrades policy performance and requires manual tuning.
- **P2 (Theoretical Analysis):** Present the theoretical characterization of DT in deterministic vs. stochastic settings. Explain how recursive RTG updates compound variance, motivating a state-based alternative.
- **P3 (Proposed Solution):** Introduce D2T2, which leverages TD-learned value functions to generate steering guidance signals. Explain how this shifts the problem from long-horizon return prediction to shorter-horizon goal-conditioned prediction.
- **P4 (Empirical Validation):** Summarize the comprehensive evaluation on stochastic tasks (Tailgate, FrozenLake, CARLA) and D4RL suites, highlighting D2T2's robustness and competitive performance.
- **P5 (Contributions):** Clearly list the three main contributions: (1) theoretical insight into DT's stochasticity vulnerability, (2) the D2T2 method with TD-learned steering guidance, and (3) extensive empirical validation demonstrating significant improvements over DT.

## Priority Revision Plan
| Priority | Action Item | Expected Impact | Effort |
|---|---|---|---|
| **P0** | Fix mathematical contradiction in Sec 2.1 (discount factor $\gamma$) and align Eq (1) with text. | Eliminates fundamental setup confusion; ensures theoretical consistency. | Low |
| **P0** | Reframe Proposition 1 to explicitly state the idealized prediction assumption or soften the guarantee. | Strengthens theoretical defensibility; prevents reviewer rejection on validity grounds. | Low |
| **P1** | Bound SOTA claims in Abstract/Conclusion to specific stochastic benchmarks where D2T2 excels. | Improves objectivity; aligns claims with empirical evidence (Table 3). | Low |
| **P1** | Reframe VAE as optional regularization for complex tasks; remove "resolves error propagation" claim. | Clarifies methodological contribution; aligns with ablation results. | Low |
| **P2** | Unify terminology ("Steering Guidance") and clean notation artifacts (`bGt` $\to$ $\tilde{G}_t$). | Enhances professional polish and readability. | Low |
| **P2** | Include omitted DT baseline in appendix or explain exclusion; soften causal language in CARLA discussion. | Improves experimental transparency and rigor. | Medium |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | VDT improves DT in stochastic envs | Tailgate, FrozenLake | Return | VDT > DT | RTG variance degrades DT | Limited to simple stochastic tasks |
| E2 | D2T2 outperforms DT/VDT | Tailgate, FrozenLake | Return | D2T2 > VDT > DT | Steering guidance mitigates variance | No ablation on guidance horizon |
| E3 | D2T2 generalizes to unseen towns | CARLA NoCrash | Success %, Speed | D2T2 > DT(t), IQL | Robustness to OOD scenarios | DT(t) hand-tuned comparison |
| E4 | D2T2 handles complex maneuvers | CARLA Leaderboard | Total Score | D2T2 > SPLT, DT | Effective in high-dim state spaces | Causal claim overreach |
| E5 | D2T2 competitive in near-deterministic | D4RL (MuJoCo, AntMaze, Kitchen) | Normalized Score | D2T2 > DT, ~IQL/CQL | Broad applicability | Underperforms MCQ on some tasks |

### Research-Theme Gap Diagnosis
The core claim that steering guidance is superior to RTG conditioning is well-supported in stochastic settings but lacks rigorous ablation on the guidance horizon and VAE necessity. The theoretical guarantee is disconnected from the training objective, and SOTA claims are not fully backed by all benchmarks.

### Proposed Research Experiments (P0/P1/P2)
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| Guidance Horizon Impact | Shorter guidance horizons reduce prediction error but may lose long-term signal. | Vary context length $k$ in $\bar{g}_\zeta(s_{t-k:t})$ on FrozenLake/Tailgate. | D2T2 with $k \in \{1, 3, 5, 10\}$ | Return | Optimal $k$ identified; trend explained | Low | Clarifies design choice |
| VAE Necessity | VAE provides regularization only in high-dimensional/complex tasks. | Compare D2T2 with/without VAE across all D4RL suites. | D2T2-n vs D2T2 | Normalized Score | VAE benefit correlates with state dim/complexity | Medium | Validates VAE framing |
| Training Objective Alignment | Standard DT loss approximates the idealized probabilistic guarantee. | Analyze gradient alignment between DT MSE loss and target return probability. | Theoretical analysis + empirical probe | Loss/Prob correlation | Correlation > 0.7 | High | Bridges theory-practice gap |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 6/10

**Rationale:** The paper addresses a well-motivated and important limitation of Decision Transformers (RTG variance in stochastic environments) and proposes a practical, effective solution (D2T2) that eliminates manual RTG tuning. The empirical evaluation is comprehensive and demonstrates clear improvements over DT. However, the score is moderated by theoretical gaps (idealized assumptions not aligned with training objectives), contradictory mathematical setup (discount factor), overclaimed SOTA performance, and vague justification for the VAE component. With targeted revisions to bound claims, fix notation/theory inconsistencies, and improve experimental transparency, the paper can significantly strengthen its scientific rigor.

**Post-Revision Target:** [7, 8]/10