## Summary
# Final Review Report

## Summary
This paper proposes RGA-IB, a robust graph attention mechanism inspired by the Information Bottleneck (IB) principle. The authors observe that lower IB loss correlates with higher robustness in attention-based GNNs against adversarial attacks. Motivated by this, RGA-IB explicitly minimizes IB loss by simulating gradient descent on attention weights across layers. Extensive experiments on semi-supervised node classification under Metattack, Nettack, and Topology attacks demonstrate that RGA-IB achieves lower IB loss and improved accuracy compared to existing robust GNNs and attention-based baselines. While the IB-inspired design is intuitive and empirically effective, the manuscript contains critical factual errors in the IB definition, overclaims correlation as causation, and lacks matched-capacity ablations to isolate the contribution of IB minimization from dense attention capacity.

## Strengths
1. **Intuitive Theoretical Motivation**: Linking graph attention robustness to the Information Bottleneck principle provides a compelling theoretical lens. The observation that lower IB loss correlates with higher robustness is empirically validated and offers a new perspective on why attention mechanisms succeed in adversarial settings.
2. **Novel Attention Update Mechanism**: The design of RGA-IB layers, which simulate gradient descent on IB loss to iteratively refine attention weights, is a creative departure from empirical attention designs. The closed-form update rule is computationally efficient and integrates seamlessly into multi-layer GNNs.
3. **Comprehensive Empirical Evaluation**: The paper evaluates RGA-IB across multiple datasets (Cora, Citeseer, Pubmed, Polblogs) and attack types (Metattack, Nettack, Topology), demonstrating consistent improvements over strong baselines. The ablation studies on layer depth and IB loss reduction further support the method's effectiveness.

## Weaknesses
1. **Critical Factual Error in IB Definition**: The introduction incorrectly states that the IB principle encourages maximizing mutual information between representations and input features while minimizing it with class labels. This is inverted; IB aims to minimize $I(Z; X)$ and maximize $I(Z; Y)$. This error undermines the theoretical foundation and must be corrected immediately.
2. **Correlation vs. Causation Overclaim**: The manuscript repeatedly claims that lower IB loss causes or strongly indicates robustness. However, the evidence is correlational. Without matched-capacity controls (e.g., dense attention without IB updates), it is unclear whether gains stem from IB minimization or increased model capacity/dense connectivity.
3. **Ill-Defined Optimization Mechanism**: The method describes RGA-IB layers as simulating "gradient descent" on IB loss, but no backpropagation through the IB loss occurs. The update rule uses a fixed scaling factor $\eta$ without convergence guarantees or learning rate scheduling, making the "gradient descent" analogy misleading.
4. **Missing Normalization and Stability Analysis**: The attention weight matrix $B$ is updated without explicit row-wise normalization (e.g., softmax), risking unbounded weights and training instability. The interaction between structural smoothing via $\tilde{A}$ and dense attention $B$ is also underexplained.
5. **Insufficient Statistical Validation**: Reported improvements are modest (1-2%) with relatively large standard deviations. The absence of statistical significance tests (e.g., paired t-tests) weakens the claim of consistent superiority over baselines.

## Key Issues
1. **Inverted IB Principle Definition (Critical)**: Page 2 incorrectly defines the IB principle as maximizing $I(Z; X)$ and minimizing $I(Z; Y)$. This contradicts the standard formulation and the subsequent loss equation. This factual error must be corrected to preserve theoretical credibility.
2. **Unverified Causal Claim (Major)**: The core contribution relies on the claim that minimizing IB loss directly improves robustness. However, without ablation studies isolating IB minimization from dense attention capacity, the causal link remains unverified. The observed gains could simply reflect the benefits of all-pair attention rather than IB optimization.
3. **Ill-Defined Gradient Simulation (Major)**: Describing the forward update rule as "gradient descent" is misleading since no actual backpropagation through the IB loss occurs. The learning rate $\eta$ is unspecified, and convergence properties are not analyzed, raising reproducibility concerns.
4. **Missing Attention Normalization (Major)**: The attention matrix $B$ lacks explicit normalization constraints, which can lead to unstable gradients and unbounded attention scores. Standard graph attention mechanisms employ softmax normalization; its absence here requires justification or implementation.
5. **Lack of Statistical Significance Testing (Major)**: Improvements over baselines are marginal (1-2%) with overlapping standard deviations. Without statistical tests, the claimed superiority cannot be confidently asserted, especially given the variance across random seeds.

## Actionable Suggestions
1. **Correct IB Definition**: Replace the inverted definition on Page 2 with: "The IB principle encourages minimizing mutual information between representations and input features $I(Z; X)$ while maximizing mutual information with class labels $I(Z; Y)$."
2. **Add Matched-Capacity Ablation**: Introduce a dense attention baseline without the IB gradient update rule. Compare its performance against RGA-IB to isolate the contribution of IB minimization from increased model capacity.
3. **Clarify Update Mechanism**: Rename "gradient descent simulation" to "gradient-inspired forward update" and explicitly define the scaling factor $\eta$ (e.g., fixed value or validation-selected). Discuss convergence behavior empirically.
4. **Implement Attention Normalization**: Apply row-wise softmax normalization to $B$ before computing $Z = BF$. Add a sentence explaining how this ensures stable aggregation and bounded gradients.
5. **Conduct Statistical Significance Tests**: Perform paired t-tests or bootstrap confidence intervals on the accuracy improvements over the strongest baselines. Report p-values to validate statistical reliability.
6. **Expand Limitations Discussion**: Add a paragraph in the conclusion addressing computational complexity ($O(N^2)$ for dense attention) and sensitivity of IB estimation to centroid initialization, guiding future scalability improvements.

## Storyline Options + Writing Outlines
### Abstract Outline
- **S1 (Problem)**: GNNs are vulnerable to adversarial attacks due to reliance on graph structure.
- **S2 (Gap)**: Attention-based GNNs improve robustness but lack theoretical grounding linking attention to robustness.
- **S3 (Insight)**: We observe that lower Information Bottleneck (IB) loss correlates with higher robustness, suggesting representations adhering to IB are less sensitive to perturbations.
- **S4 (Method)**: We propose RGA-IB, a graph attention mechanism that explicitly minimizes IB loss via gradient-inspired forward updates on attention weights.
- **S5 (Result)**: Extensive experiments show RGA-IB achieves lower IB loss and consistently improves accuracy under various attacks compared to state-of-the-art baselines.

### Introduction Outline
- **P1 (Motivation)**: Establish GNN vulnerability to adversarial attacks and the rise of attention mechanisms as a defense.
- **P2 (Gap)**: Highlight that existing attention methods are empirically designed without theoretical support, and the connection to IB principle remains unexplored.
- **P3 (Insight)**: Introduce the observation that lower IB loss correlates with robustness, framing IB as a principled lens for attention design.
- **P4 (Method)**: Present RGA-IB, explaining how it simulates IB gradient descent to iteratively refine attention weights across layers.
- **P5 (Contributions)**: Summarize three contributions: (1) IB-robustness correlation insight, (2) RGA-IB method design, (3) comprehensive empirical validation.

## Priority Revision Plan
| Priority | Action | Expected Impact |
|---|---|---|
| P0 (Critical) | Correct inverted IB definition in Introduction and Abstract. | Restores theoretical credibility and prevents fundamental misunderstanding. |
| P0 (Critical) | Add matched-capacity dense attention baseline without IB updates. | Isolates IB minimization effect from capacity gains, validating causal claim. |
| P1 (Major) | Clarify "gradient descent" as gradient-inspired forward update; specify $\eta$. | Improves reproducibility and theoretical transparency. |
| P1 (Major) | Implement row-wise softmax normalization for attention matrix $B$. | Ensures training stability and bounded gradients. |
| P1 (Major) | Conduct statistical significance tests (paired t-tests) on accuracy gains. | Validates reliability of marginal improvements over baselines. |
| P2 (Minor) | Expand conclusion with limitations (complexity, centroid sensitivity). | Enhances scientific rigor and guides future work. |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | RGA-IB improves robustness under untargeted attacks | Metattack on Cora/Citeseer/Pubmed/Polblogs | Accuracy ± Std | Consistent gains over baselines | Robustness claim | Lacks statistical tests |
| E2 | RGA-IB improves robustness under targeted attacks | Nettack on 4 datasets | Accuracy ± Std | Superior performance at high budgets | Robustness claim | Modest margins |
| E3 | IB loss decreases across RGA-IB layers | 2-layer vs 4-layer RGA-IB | IB Loss, ACC | Lower IB loss at deeper layers | IB reduction claim | Negative IB values undefined |
| E4 | Global attention benefits IB reduction | RGA-IB vs RGA-IB_local | IB Loss, ACC | Dense attention yields lower IB | Global correlation claim | Only tested on 3 datasets |

### Research-Theme Gap Diagnosis
The core claim that IB minimization causally drives robustness is weakly supported due to the absence of matched-capacity controls. Additionally, the theoretical grounding of the IB estimator and gradient update rule lacks convergence analysis.

### Proposed Research Experiments
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| Causal IB effect | IB update, not capacity, drives gains | Dense attention GNN without IB rule | RGA-IB vs Dense-Attn-Baseline | Accuracy, IB Loss | RGA-IB significantly outperforms baseline | Low | Validates core mechanism |
| Statistical reliability | Improvements are statistically significant | 10 seeds, paired t-tests | RGA-IB vs Top-2 baselines | p-values | p < 0.05 | Low | Strengthens empirical claims |
| Stability analysis | Normalization prevents training collapse | Add softmax to B | RGA-IB (normalized) vs original | Training loss, ACC | Stable convergence | Low | Improves reproducibility |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score**: 5.5/10  
The paper presents an intuitive IB-inspired attention mechanism with solid empirical results, but critical factual errors in the IB definition, overclaims regarding correlation vs. causation, and missing matched-capacity ablations significantly undermine theoretical credibility and novelty validation. The method is promising but requires substantial revision to establish causal links and ensure reproducibility.

**Post-Revision Target**: [7.0, 8.0]/10  
If the authors correct the IB definition, add matched-capacity controls to isolate the IB effect, clarify the update mechanism, and provide statistical significance tests, the paper would achieve strong theoretical grounding and empirical rigor, warranting a competitive score for publication.