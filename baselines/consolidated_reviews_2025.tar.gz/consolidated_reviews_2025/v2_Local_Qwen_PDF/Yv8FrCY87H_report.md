## Summary
# Final Review Report

## Summary

This paper introduces **Tree-of-Table**, a framework designed to enhance large language models' (LLMs) reasoning capabilities over large-scale, interconnected tabular data. The authors identify a critical gap in existing methods: while LLMs have shown promise on small-scale tables, they struggle with the context limits and complex relational dependencies found in real-world datasets like BIRD. To address this, Tree-of-Table integrates three core components: (1) **Table Condensation**, which uses schema-linking to distill relevant sub-tables and reduce context bloat; (2) **Table-Tree Construction**, which decomposes complex queries into a hierarchical tree of sub-problems inspired by Tree-of-Thought; and (3) **Table-Tree Execution**, which traverses the tree via depth-first search to systematically derive solutions. Experiments on WikiTQ, TableFact, FeTaQA, and BIRD demonstrate that Tree-of-Table consistently outperforms strong baselines, particularly improving accuracy on large-scale relational datasets while reducing reasoning steps.

The paper presents a compelling intuition for applying hierarchical decomposition to table reasoning. However, the current manuscript suffers from several key weaknesses: (1) the related work and motivation sections rely on vague critiques and promotional language rather than precise technical failure modes; (2) the mathematical formulation of tree decomposition lacks clear variable definitions and algorithmic pseudocode, hindering reproducibility; (3) the experimental results lack variance reporting and statistical significance tests, making it difficult to validate the robustness of marginal gains; and (4) the limitations section is overly generic, failing to specify concrete failure conditions. Addressing these issues through precise rewriting, algorithmic clarification, and rigorous statistical validation would significantly strengthen the paper's scientific credibility and impact.

## Strengths
1. **Novel Hierarchical Reasoning Paradigm:** The core idea of adapting Tree-of-Thought principles to table decomposition is highly intuitive and well-motivated. By isolating sub-problems into independent branches, Tree-of-Table effectively mitigates the context bloat and error accumulation inherent in linear chain-based methods (e.g., Chain-of-Table). This structural innovation directly addresses a key bottleneck in large-scale table understanding.

2. **Comprehensive Empirical Evaluation:** The paper evaluates the method across a diverse set of benchmarks, ranging from small-scale web tables (WikiTQ, TabFact) to large-scale relational databases (BIRD). The inclusion of BIRD is particularly valuable, as it provides a rigorous testbed for real-world, multi-table reasoning scenarios where context limits are a primary constraint.

3. **Effective Table Condensation Module:** The integration of schema-aware condensation before reasoning is a practical and impactful contribution. By reducing the input token count and focusing on relevant relational schemas, the method significantly improves the signal-to-noise ratio for LLMs, making the subsequent tree decomposition more tractable and accurate.

4. **Clear Visualizations and Case Studies:** The paper provides clear figures (e.g., Figure 1 and Figure 2) that effectively illustrate the contrast between generic reasoning, linear chains, and the proposed tree structure. The case studies in the appendix further demonstrate the method's ability to handle complex, multi-step queries that confuse linear baselines.

## Weaknesses
1. **Vague Motivation and Superficial Related Work Critique:** The introduction and related work sections rely on broad, promotional language ("pivotal form", "opened new vistas") and list-style summaries rather than a precise technical analysis. The failure modes of existing methods (e.g., why linear chains fail on multi-branch logic, why SQL generation is brittle) are not mechanistically explained. This weakens the novelty positioning and leaves readers without a clear understanding of the specific technical gap Tree-of-Table fills.

2. **Lack of Reproducibility in Method Formulation:** The mathematical formulation of tree decomposition (Eq. 4-6) is dense and lacks clear variable definitions (e.g., the exact nature of relational dependencies `r1`, how `MAXDegree` is dynamically determined). The transition from question decomposition to tree construction is described abstractly without pseudocode or algorithmic steps. This makes it difficult for readers to verify the implementation or reproduce the tree generation process.

3. **Insufficient Statistical Validation of Results:** The main results report point estimates without variance (mean ± std over multiple seeds) or statistical significance tests. Given that LLM outputs are stochastic and the improvements over strong baselines like Chain-of-Table are sometimes marginal (e.g., +1.17 on WikiTQ), it is unclear whether the gains are statistically significant or due to prompt variance. This undermines the claim of "superior performance."

4. **Generic Limitations and Overclaimed Efficiency:** The limitations section is overly vague, stating only that "tree-based reasoning may need careful calibration" without specifying concrete failure modes (e.g., schema-linking errors, latency overhead, global aggregation limits). Additionally, the efficiency analysis (Table 5) claims fewer "generated samples" but does not account for the increased inference latency from multi-step tree traversal, presenting an incomplete picture of computational cost.

## Key Issues
1. **Statistical Reliability of Main Claims (Critical):** The absence of variance reporting and significance testing across multiple seeds is a critical validity risk. LLM-based methods are inherently stochastic; without standard deviations and p-values, the reported improvements (especially marginal ones like +1.17 on WikiTQ) cannot be distinguished from random fluctuations. This directly threatens the core claim of "superior performance."

2. **Reproducibility of Tree Decomposition Mechanism (Major):** The method section lacks algorithmic pseudocode and clear definitions for key variables (e.g., `r1`, `MAXDegree`, leaf-node stopping conditions). The mathematical notation is dense and does not map cleanly to the prompting strategy described in the appendix. This opacity prevents independent verification and limits the method's reusability.

3. **Incomplete Efficiency and Cost Analysis (Major):** The efficiency analysis focuses solely on the number of generated samples, ignoring the increased inference latency and computational overhead of multi-step tree traversal. Table 6 in the appendix shows Tree-of-Table takes 7.8s vs. 5.7s for Chain-of-Table, but this trade-off is not discussed in the main text. A complete efficiency claim must account for both token count and wall-clock time.

4. **Vague Failure Modes and Limitations (Major):** The limitations section fails to specify concrete conditions under which Tree-of-Table degrades (e.g., schema-linking errors, excessive tree depth, global aggregation queries). Without this transparency, readers cannot properly scope the method's applicability or assess its robustness in real-world deployment scenarios.

## Actionable Suggestions
1. **Add Statistical Rigor to Experiments:** Re-run main experiments on WikiTQ, TabFact, FeTaQA, and BIRD using at least 3 random seeds. Report results as mean ± standard deviation. Perform paired significance tests (e.g., t-test or bootstrap) against the strongest baseline (Chain-of-Table) to validate that improvements are statistically significant (p < 0.05).

2. **Clarify Method Formulation with Pseudocode:** Replace the dense mathematical notation in Section 3.4 with a clear algorithmic pseudocode block (e.g., Algorithm 1: Tree-of-Table Construction). Explicitly define all variables (e.g., `r1` as relational dependency, `MAXDegree` as branching factor) and specify the LLM prompting strategy for determining leaf nodes and stopping conditions.

3. **Reorganize Related Work Around Decision-Relevant Axes:** Restructure the Related Work section into three categories: (1) Program-Aided Methods, (2) Context-Expansion/Condensation Methods, and (3) Reasoning Decomposition Methods. For each category, explicitly state the mechanistic limitation that Tree-of-Table addresses (e.g., linear chain context bloat, SQL brittleness on free-form text).

4. **Specify Concrete Failure Modes in Limitations:** Rewrite the Limitations section to detail specific conditions where Tree-of-Table degrades: (a) performance drops when schema-linking fails to identify critical foreign keys; (b) increased inference latency due to multi-step traversal; (c) difficulty handling queries requiring global table aggregation that cannot be cleanly decomposed. This improves scientific transparency and scopes the contribution accurately.

5. **Balance Efficiency Claims with Latency Analysis:** Integrate the time cost analysis from Appendix Table 6 into the main text. Discuss the trade-off between reduced token count and increased wall-clock latency. If latency is higher, frame the efficiency gain in terms of "reasoning steps per correct answer" rather than absolute speed, and acknowledge the computational overhead.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem & Domain):** Tables are ubiquitous semi-structured data, yet large language models (LLMs) struggle with large-scale tabular data due to context limits and complex relational dependencies.
- **S2 (Significance/Challenge):** Real-world applications require reasoning across interconnected tables, but existing methods often fail on the intricate, multi-hop logic needed for comprehensive understanding.
- **S3 (Prior Gap):** Current approaches either rely on brittle program generation (e.g., SQL) or linear reasoning chains that accumulate context bloat and error propagation as table size grows.
- **S4 (Proposed Method):** We introduce Tree-of-Table, a framework that enhances LLM reasoning via schema-aware Table Condensation and hierarchical Table-Tree Construction, isolating sub-problems to prevent context overflow.
- **S5 (Key Result & Bounded Implication):** Experiments on WikiTQ, TableFact, FeTaQA, and BIRD show that Tree-of-Table consistently outperforms strong baselines, particularly improving accuracy on large-scale relational datasets while reducing reasoning steps.

### Introduction Outline (Complete)
- **P1 (Motivation & Core Tension):** Start directly with the tension between LLM context windows and the exponential complexity of multi-table relational schemas. State clearly that dense, interconnected tables exceed current model capabilities.
- **P2 (Failure Modes of Prior Work):** Explicitly categorize and critique existing methods: (1) Program-aided methods fail on semantic nuances and free-form text; (2) Context-expansion methods hit token limits; (3) Linear decomposition methods (e.g., Chain-of-Table) suffer from history accumulation and error propagation on multi-branch logic.
- **P3 (Proposed Solution & Intuition):** Introduce Tree-of-Table as a hierarchical alternative. Explain the intuition: by condensing relevant schemas and decomposing queries into a tree structure, we isolate sub-problems, reduce context load, and enable systematic depth-first execution.
- **P4 (Key Contributions):** Provide a bulleted list of contributions: (1) Table Condensation mechanism for schema-aware reduction; (2) Tree-Tree Construction algorithm for hierarchical decomposition; (3) Comprehensive evaluation demonstrating robust gains on large-scale benchmarks like BIRD.
- **P5 (Evidence Preview):** Briefly preview the main empirical outcomes, emphasizing the statistical reliability and efficiency trade-offs, setting up the experimental section.

## Priority Revision Plan
| Priority | Action Item | Effort | Impact | Expected Gain |
|---|---|---|---|---|
| **P0** | **Add Variance & Significance Tests:** Re-run main experiments over ≥3 seeds, report mean±std, and add paired t-tests against Chain-of-Table. | Medium | Critical | Validates statistical reliability of marginal gains; prevents rejection for lack of rigor. |
| **P0** | **Clarify Method with Pseudocode:** Add Algorithm 1 for Tree Construction, define all variables (`r1`, `MAXDegree`), and specify leaf-node stopping conditions. | Low | Major | Improves reproducibility and clarifies the core technical contribution. |
| **P1** | **Rewrite Introduction & Related Work:** Remove hype language; reorganize related work around decision-relevant axes (Program-Aided, Context-Expansion, Decomposition) with mechanistic critiques. | Medium | Major | Strengthens motivation, clearly carves out the novelty niche, and improves narrative flow. |
| **P1** | **Integrate Latency Analysis:** Move time cost analysis (Appendix Table 6) to main text; discuss trade-off between token reduction and wall-clock latency. | Low | Major | Provides a complete, honest efficiency picture; addresses reviewer concerns about computational cost. |
| **P2** | **Specify Concrete Limitations:** Detail failure modes (schema-linking errors, global aggregation limits, latency overhead) to scope the contribution accurately. | Low | Minor | Improves scientific transparency and defensibility against edge-case critiques. |

**Execution Strategy:** Begin with P0 items to secure the empirical foundation. Once variance is reported, proceed to P1 writing revisions to align the narrative with the validated results. Finally, address P2 limitations to polish the conclusion.

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup (Data/Split/Baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Tree-of-Table outperforms baselines on small/large tables. | WikiTQ, TabFact, FeTaQA, BIRD; vs Chain-of-Table, Dater, etc. | Accuracy, BLEU, ROUGE | Consistent improvements, especially on BIRD. | Superior performance | No variance/significance reported. |
| E2 | Generalization across table sizes. | WikiTQ, BIRD (Small/Medium/Large splits). | Accuracy | Gradual performance decline, less severe than baselines. | Robustness to scale | No statistical tests on size buckets. |
| E3 | Tree structure efficiency. | WikiTQ, TabFact, BIRD. | Tree Height, Node Number | Lower height than Chain-of-Table chain length. | Structural efficiency | Does not account for latency. |
| E4 | Table format impact. | WikiTQ. | Accuracy | Markdown performs best. | Format sensitivity | Limited to one dataset. |
| E5 | Sample efficiency. | BIRD. | Generated Samples | Fewer samples needed than Dater/Chain-of-Table. | Reasoning efficiency | Ignores wall-clock time. |
| E6 | Condensation effectiveness. | WikiTQ, TabFact, FeTaQA, BIRD. | Cell count reduction | Significant reduction post-condensation. | Context reduction | No accuracy delta for condensation ablation. |

### Research-Theme Gap Diagnosis
The core research value (hierarchical reasoning for large tables) is supported by point estimates but lacks statistical validation. The reproducibility of the tree construction mechanism is weak due to missing pseudocode. The efficiency claim is incomplete without latency analysis.

### Proposed Research Experiments (P0/P1/P2)
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost/Time | Expected Gain |
|---|---|---|---|---|---|---|---|
| Statistical Reliability | Gains are not due to stochastic variance. | Re-run E1 over 3 seeds. | Chain-of-Table (3 seeds). | Mean±std, p-value | p < 0.05 vs baseline | Medium (1-2 days API) | Validates core performance claim. |
| Latency Trade-off | Tree traversal increases latency but reduces tokens. | Measure wall-clock time for E1. | Chain-of-Table. | Time (s), Tokens | Clear token-time trade-off | Low (existing runs) | Completes efficiency analysis. |
| Condensation Ablation | Condensation is critical for large tables. | Remove condensation step, run full tables. | Full Tree-of-Table. | Accuracy drop | Significant drop on BIRD | Medium | Isolates condensation contribution. |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 6.0/10

**Rationale:** The paper presents a compelling and intuitive method (Tree-of-Table) that addresses a real and important bottleneck in LLM-based table understanding: context bloat and linear reasoning failure on large relational datasets. The empirical results on BIRD are promising and the condensation module is a practical contribution. However, the score is held back by critical validity gaps: the lack of variance reporting and significance tests makes the marginal gains statistically unverifiable, and the method formulation lacks the pseudocode/definitions needed for reproducibility. The promotional writing style and vague limitations further reduce scientific credibility. With rigorous statistical validation and clearer algorithmic exposition, this work has strong potential.

**Post-Revision Target:** [7.5, 8.5]/10

**Path to Target:** Achieving this target requires (1) re-running main experiments over multiple seeds with significance tests to validate the core performance claim, (2) adding algorithmic pseudocode and clear variable definitions to ensure reproducibility, and (3) rewriting the introduction/related work to precisely carve out the novelty niche without hype. Addressing these issues will transform the paper from a promising but unverified proposal into a robust, defensible contribution.