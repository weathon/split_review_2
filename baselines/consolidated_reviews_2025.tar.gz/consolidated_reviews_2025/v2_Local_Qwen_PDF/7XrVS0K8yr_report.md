## Summary
# Final Review Report

## Summary
This paper proposes Secure-FLOATING, a decentralized framework for real-time trust establishment among Connected and Autonomous Vehicles (CAVs) and Vulnerable Road Users (VRUs). The framework integrates Verifiable Federated Learning (VFL), lightweight Secure Multi-Party Computation (SMPC), and blockchain consensus to validate trajectory data while preserving privacy. Evaluated on realistic NYC trajectory data for up to 8,000 nodes, the authors claim reduced communication overhead, linear scalability, and robust performance against malicious data injection. While the integration of VFL and SMPC for V2X trust is promising, the manuscript suffers from critical mathematical contradictions in theoretical proofs, missing verification mechanisms in the SMPC protocol, and overstated novelty claims. Significant revisions are required to align theoretical claims with evidence, clarify the security protocol, and improve empirical rigor.

## Strengths
1. **Relevant and Timely Problem:** The paper addresses a critical safety challenge in CAV and V2X networks: establishing trust in shared trajectory data without compromising privacy. The focus on real-time validation for safety-critical applications is highly relevant to current autonomous transportation research.
2. **Comprehensive System Integration:** Secure-FLOATING effectively combines multiple advanced techniques (VFL, SMPC, blockchain/IPFS) into a unified framework. The architectural design demonstrates a clear understanding of the trade-offs between privacy, security, and computational overhead.
3. **Realistic Empirical Evaluation:** The use of SUMO and NS3 to simulate realistic NYC traffic scenarios with up to 8,000 heterogeneous nodes provides a strong empirical foundation. The evaluation covers multiple dimensions (accuracy, FLOPs, CPU utilization, communication overhead, and robustness against attackers), offering practical insights into system scalability.
4. **Lightweight Model Advocacy:** The emphasis on lightweight trajectory prediction models (RNN, LSTM, GRU) aligns well with the resource-constrained nature of edge devices in V2X networks. The empirical comparison with heavier models (Transformer, ODA) justifies the design choice from an efficiency perspective.

## Weaknesses
1. **Critical Mathematical Contradiction in Theoretical Analysis:** Theorem 4.2 claims linear communication overhead $f(n) = 2n - 1$, but the inductive proof incorrectly uses $f(n) = 3n - 2$. This fundamental inconsistency invalidates the theoretical scalability guarantee and suggests a lack of rigorous proofreading.
2. **Missing Verification Mechanism in VFL/SMPC Protocol:** The manuscript describes how nodes split and share model updates using SMPC but fails to explain how malicious or manipulated shares are detected or rejected. Without a cryptographic verification step (e.g., zero-knowledge proofs or commitment schemes), the "Verifiable" aspect of VFL is unsupported, undermining the core security claim.
3. **Overstated Novelty and Hype Language:** The introduction and conclusion use promotional phrasing ("paradigm shift", "first ones to set the basis", "provable linear complexity") that is not fully backed by the provided evidence or literature comparison. The novelty claims require tighter scoping and citation-backed verification.
4. **Counter-Intuitive Empirical Claims Without Explanation:** Table 3 shows that SMPC-based VFL training time is lower than vanilla ML for $n > 1$, which contradicts the typical overhead of SMPC. The text does not provide a mechanistic explanation (e.g., parallelization, reduced rounds) for this speedup, making the result appear suspicious or methodologically flawed.
5. **Selective Reporting and Lack of Statistical Rigor:** The results analysis emphasizes lightweight models while downplaying the significantly higher accuracy of the Transformer (MAE 0.7 vs ~6.0). Tables lack variance or standard deviation reporting, preventing assessment of statistical reliability. The endorsement threshold $\omega$ is never quantified, leaving the safety margin undefined.

## Key Issues
1. **Theorem 4.2 Proof Contradiction (Critical):** The theorem statement defines overhead as $f(n) = 2n - 1$, but the proof uses $f(n) = 3n - 2$. This mathematical error must be corrected to validate the linear scalability claim.
2. **Undefined Verification Mechanism (Critical):** The VFL/SMPC protocol lacks a concrete method for detecting malicious shares. Without cryptographic verification or a robust aggregation protocol (e.g., SecAgg), the framework cannot guarantee integrity against Byzantine nodes.
3. **Unexplained VFL Training Speedup (Major):** Table 3 shows VFL training time is lower than vanilla ML, which is counter-intuitive for SMPC. A detailed breakdown of computation vs. communication overhead is required to justify this result.
4. **Missing Endorsement Threshold $\omega$ (Major):** The trajectory validation relies on an error threshold $\omega$, but its value and derivation are never specified. This leaves the safety margin and false-positive/negative rates undefined.
5. **Overstated Theoretical Claims in Conclusion (Major):** The conclusion asserts "provable linear complexity" and "formal proofs for privacy, security, and scalability" despite the contradictions in Theorem 4.2 and incomplete privacy derivation. Claims must be bounded to match the provided evidence.

## Actionable Suggestions
1. **Correct Theorem 4.2 and Proof:** Align the proof with the theorem statement. If $f(n) = 2n - 1$, update the base case to $f(1) = 1$ and the inductive step to show $f(k+1) = f(k) + 2$. Clarify whether overhead is per-node or network-wide.
2. **Detail the Verification Mechanism:** Explicitly describe how malicious shares are detected. Integrate cryptographic commitments or zero-knowledge proofs into the SMPC protocol description. If verification is out of scope, rename the section to "Privacy-Preserving Federated Learning" to align claims with evidence.
3. **Explain VFL Training Speedup:** Provide a breakdown of training time components (computation vs. communication) to justify why VFL is faster than vanilla ML. Discuss parallelization, reduced synchronization rounds, or early stopping mechanisms.
4. **Quantify Endorsement Threshold $\omega$:** Specify the value of $\omega$ and explain how it was derived (e.g., based on sensor noise characteristics or safety margins). Report false-positive and false-negative rates under different attack scenarios.
5. **Add Variance and Statistical Tests:** Report mean $\pm$ standard deviation over multiple seeds for all tables. Add paired significance tests to validate performance differences between VFL and vanilla ML.
6. **Bound Novelty and Theoretical Claims:** Remove hype language ("paradigm shift", "first ones") and replace with evidence-backed statements. Tone down the conclusion to reflect empirical validation and preliminary theoretical analysis, acknowledging areas for future formal verification.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem & Domain):** The safety of CAVs and VRUs depends on trusting shared trajectory data for real-time navigation, but malicious inputs pose fatal risks.
- **S2 (Significance/Challenge):** Verifying this data without compromising privacy is challenging, as centralized models create single points of failure and heavy encryption introduces prohibitive latency.
- **S3 (Prior Gap):** Existing decentralized trust mechanisms lack real-time capability or fail to provide formal privacy guarantees during collaborative learning.
- **S4 (Proposed Method):** We propose Secure-FLOATING, a framework integrating lightweight SMPC, Verifiable Federated Learning (VFL), and blockchain consensus to validate trajectories securely and efficiently.
- **S5 (Key Result & Implication):** Evaluated on 8,000 NYC nodes, Secure-FLOATING reduces communication overhead by up to 60% and maintains 75% trust endorsement under 50% attacker penetration, demonstrating scalable, privacy-preserving validation for safety-critical V2X networks.

### Introduction Outline (Complete)
- **P1 (Motivation & Threat):** Establish the vision of coordinated CAV/VRU navigation. Highlight the critical threat of malicious trajectory injection and the need for real-time trust.
- **P2 (Limitations of Prior Work):** Critique centralized trust models (privacy risks, single point of failure) and heavy encryption methods (latency overhead). Cite representative works to ground the gap.
- **P3 (Proposed Solution & Intuition):** Introduce Secure-FLOATING. Explain the intuition: combining VFL for collaborative learning, lightweight SMPC for privacy, and blockchain for immutable consensus.
- **P4 (Key Contributions):** List contributions clearly: (1) Lightweight SMPC protocol for real-time validation, (2) VFL aggregation with linear scalability, (3) Extensive NYC simulation demonstrating robustness and efficiency.
- **P5 (Paper Organization):** Briefly outline the remaining sections.

## Priority Revision Plan
| Priority | Task | Expected Impact | Effort |
|---|---|---|---|
| **P0 (Critical)** | Correct Theorem 4.2 proof to match $f(n) = 2n - 1$. | Restores theoretical credibility and validates scalability claim. | Low |
| **P0 (Critical)** | Detail the verification mechanism for malicious shares in VFL/SMPC. | Closes core security gap; justifies "Verifiable" claim. | Medium |
| **P1 (Major)** | Explain VFL training speedup over vanilla ML with overhead breakdown. | Resolves counter-intuitive empirical result; improves reproducibility. | Medium |
| **P1 (Major)** | Quantify endorsement threshold $\omega$ and report false-positive/negative rates. | Defines safety margin; strengthens robustness claims. | Low |
| **P1 (Major)** | Add variance/std and significance tests to all result tables. | Improves statistical rigor and reliability assessment. | Low |
| **P2 (Minor)** | Remove hype language and bound novelty/theoretical claims in Intro/Conclusion. | Aligns narrative with evidence; improves scientific tone. | Low |
| **P2 (Minor)** | Standardize notation in Appendix DP proof ($\Delta x$ vs $\Delta \theta_{global}$). | Enhances theoretical clarity and reproducibility. | Low |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Lightweight models achieve acceptable trajectory prediction accuracy. | SUMO/NS3, NYC data, 8000 nodes. RNN/LSTM/GRU vs Transformer/ODA. | MAE, Accuracy, FLOPs, CPU Util. | Lightweight models have higher MAE (~6.0) but significantly lower FLOPs/CPU. | Efficiency claim supported. | Accuracy gap vs Transformer not fully justified for safety threshold. |
| E2 | VFL reduces training time and scales linearly compared to vanilla ML. | 1-100 nodes, varying neighborhood sizes. | Training time (s), MAE vs n. | VFL training time lower than vanilla ML; MAE stable (~6.4) vs vanilla degradation. | Scalability claim supported. | Mechanism for VFL speedup unexplained; lacks variance reporting. |
| E3 | Secure-FLOATING is robust against malicious data injection. | Attacker ratio 0-0.5, comm range 50-300m. | Successful endorsement rate. | 75% endorsement at 50% attacker ratio. | Robustness claim supported. | Endorsement threshold $\omega$ undefined; filtering mechanism unclear. |
| E4 | Communication overhead scales linearly with network size. | Message sizes 1kb/100kb, frequencies 1s/10s/1min. | Overhead (bytes). | Small messages yield negligible overhead; linear trend observed. | Overhead claim supported. | Theoretical proof (Thm 4.2) contradicts statement. |

### Research-Theme Gap Diagnosis
The core research value (real-time, privacy-preserving trust) is empirically demonstrated but theoretically under-supported. The missing verification mechanism and undefined safety threshold $\omega$ leave the security and safety guarantees incomplete. Statistical reliability is also weak due to missing variance.

### Proposed Research Experiments (P0/P1/P2)
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| **Security/Verification** | Cryptographic commitments effectively filter malicious shares. | Add commitment scheme to SMPC; inject Byzantine nodes. | VFL without commitments. | Malicious share detection rate, aggregation integrity. | >95% detection of manipulated shares. | Medium | Validates "Verifiable" claim; closes security gap. |
| **Safety Threshold** | Threshold $\omega$ can be calibrated to sensor noise to minimize false positives. | Vary $\omega$ based on GPS noise models; measure endorsement accuracy. | Fixed arbitrary $\omega$. | False positive/negative rates, collision avoidance rate. | <5% false positive rate under normal conditions. | Low | Defines safety margin; strengthens robustness claim. |
| **Statistical Reliability** | Performance gains are statistically significant across seeds. | Run E1-E4 over 5 random seeds. | Current single-run results. | Mean $\pm$ std, p-values (paired t-test). | p < 0.05 for VFL vs vanilla ML differences. | Low | Improves empirical rigor and reproducibility. |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 4.5/10

**Rationale:** The paper addresses a highly relevant problem in CAV safety and privacy, and the empirical evaluation on realistic NYC data is a strong asset. However, the score is significantly reduced due to critical mathematical contradictions in the theoretical analysis (Theorem 4.2), a missing verification mechanism in the core VFL/SMPC protocol, and overstated novelty/theoretical claims. These issues undermine the scientific validity and reproducibility of the framework. With rigorous corrections to the proofs, explicit detailing of the security protocol, and bounded claims, the paper could reach a much higher standard.

**Post-Revision Target:** [6.5, 7.5]/10

**Path to Target:** 
1. Correct Theorem 4.2 and align all theoretical proofs with statements.
2. Integrate and detail a cryptographic verification mechanism for SMPC shares.
3. Quantify the endorsement threshold $\omega$ and report statistical variance across experiments.
4. Remove hype language and bound novelty claims to the specific V2X trajectory validation setting.