## Summary
# Final Review Report

## Summary
This paper introduces LR0.FM, a comprehensive benchmark evaluating the zero-shot classification robustness of 10 vision-language foundation models (FMs) across 66 backbones and 15 datasets under low-resolution (LR) conditions. The authors identify limitations in existing robustness metrics and propose Weighted Aggregated Robustness (WAR) to provide a more balanced evaluation. Key findings reveal that larger models and higher-quality pre-training data correlate with better LR robustness, while fine-tuning and higher input resolutions often degrade performance. Leveraging the insight that LR primarily disrupts early model layers, the authors propose LR-TK0, a lightweight strategy that adds trainable tokens to frozen transformers. LR-TK0 is trained using task-agnostic feature distillation on synthetic diffusion images and demonstrates improved zero-shot accuracy at extreme resolutions (e.g., 16x16) without altering pre-trained weights.

## Strengths
1. **Comprehensive Benchmarking**: The LR0.FM benchmark provides a large-scale, systematic evaluation of FM robustness under LR conditions, covering 10 models, 66 backbones, and 15 diverse datasets. This scale offers valuable empirical insights into how model size, pre-training data quality, and fine-tuning affect LR performance.
2. **Novel Metric Design**: The proposed Weighted Aggregated Robustness (WAR) metric addresses a real limitation in simple averaging (SAR), which can be dominated by datasets following the majority performance trend. WAR provides a more balanced evaluation by optimizing dataset weights to reflect individual dataset rankings.
3. **Effective Lightweight Method**: LR-TK0 is a simple yet effective strategy that enhances LR robustness without altering pre-trained weights. The use of task-agnostic feature distillation on synthetic diffusion images is a creative and practical approach, avoiding the need for task-specific labeled data.
4. **Insightful Analysis**: The paper provides meaningful analysis, such as the observation that LR inputs primarily disrupt early model layers and that models maintain semantically reasonable predictions even at extreme resolutions. These insights directly motivate the design of LR-TK0.

## Weaknesses
1. **Heuristic Metric Design**: The WAR metric optimization uses arbitrary coefficients (e.g., 0.95 for ImageNet/DTD vs 1.0 for others) without clear justification or ablation. Similarly, the improved relative robustness metric uses an exponential decay function with $\alpha=200$ chosen heuristically. These design choices reduce the principled nature of the proposed metrics.
2. **Methodological Ambiguity**: The LR-TK0 method description lacks clarity on the exact operation for injecting tokens (element-wise addition vs. concatenation) and dimension matching. The training paradigm mentions a "contrastive loss" but does not provide the explicit mathematical formulation or explain how the loss is aggregated across multi-scale resolution buckets.
3. **Weak Related Work Synthesis**: The related work section reads more like a literature list than a critical synthesis. It lacks explicit discussion of how LR-TK0 differs from existing parameter-efficient fine-tuning methods (e.g., VPT, adapters) and does not quantitatively define the threshold for "very LR."
4. **Missing Limitations and Future Work**: The conclusion summarizes findings but abruptly ends without acknowledging limitations (e.g., evaluation restricted to 15 datasets, reliance on synthetic diffusion images) or suggesting future directions, which is standard for high-quality papers.

## Key Issues
1. **Metric Reproducibility**: The lack of explicit loss formulation for LR-TK0 training and the heuristic choices for WAR/improved robustness metrics hinder reproducibility. Authors should provide the exact contrastive loss equation and justify or ablate the hyperparameters ($\alpha$, WAR coefficients).
2. **Novelty Positioning**: The paper claims novelty in adding tokens to frozen transformers for LR robustness, but does not sufficiently contrast this with existing prompt tuning or adapter methods. The distinction between "adding/merging" tokens versus concatenation needs precise mathematical definition.
3. **Claim-Evidence Alignment**: Strong claims like "pre-training dataset quality is more important than its size" are made without bounding them to the evaluated models/datasets. Similarly, the conclusion lacks a discussion of limitations, overstating the generalizability of the findings.

## Actionable Suggestions
1. **Clarify Method Formulation**: Explicitly define the token injection operation (e.g., element-wise addition) and confirm dimension matching. Provide the exact contrastive loss equation used in training and explain how the loss is aggregated across multi-scale resolution buckets.
2. **Justify Metric Hyperparameters**: Add a brief ablation or justification for the choice of $\alpha=200$ in the improved robustness metric and the coefficients in the WAR optimization objective. If these are fixed hyperparameters, state this clearly.
3. **Strengthen Related Work**: Add a paragraph explicitly contrasting LR-TK0 with existing prompt tuning (e.g., VPT) and adapter methods. Define the quantitative threshold for "very LR" (e.g., ≤32x32) to clarify the novelty scope.
4. **Improve Conclusion**: Add a short paragraph discussing limitations (e.g., dataset coverage, synthetic data reliance) and future work (e.g., extension to video, adaptive token pruning) to provide a balanced closing.
5. **Bound Strong Claims**: Revise claims like "pre-training dataset quality is more important than its size" to be bounded to the evaluated models/datasets, avoiding overgeneralization.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem & Domain)**: Visual-language foundation models (FMs) exhibit strong zero-shot generalization but remain vulnerable to low-resolution (LR) inputs, a common real-world challenge.
- **S2 (Significance/Gap)**: Existing robustness metrics and benchmarks inadequately capture performance degradation under extreme resolution loss, leaving a critical gap in understanding FM resilience.
- **S3 (Proposed Method)**: We introduce LR0.FM, a comprehensive benchmark across 66 backbones and 15 datasets, and propose LR-TK0, a lightweight strategy adding trainable tokens to frozen transformers via task-agnostic feature distillation.
- **S4 (Key Result)**: LR-TK0 improves zero-shot accuracy by up to X% at 16x16 resolution without altering pre-trained weights, demonstrating strong generalization across backbones.
- **S5 (Bounded Implication)**: Our analysis reveals that LR primarily disrupts early model layers, motivating multi-block token injection as a practical solution for real-world deployment.

### Introduction Outline (Complete)
- **P1 (Big Picture & Gap)**: Establish FM success in zero-shot tasks, then pivot to the underexplored challenge of LR robustness in practical scenarios (surveillance, satellite imagery).
- **P2 (Benchmark & Metric Gap)**: Introduce LR0.FM benchmark scale and identify limitations in existing robustness metrics (misleading scores near random, dataset bias), motivating WAR.
- **P3 (Key Insights)**: Summarize findings: larger models/higher-quality data improve robustness; fine-tuning/higher input resolutions degrade it; LR disrupts early layers more than deep ones.
- **P4 (Method Intuition)**: Propose LR-TK0 based on the insight that preserving semantic reasoning requires compensating for lost fine-grained details without altering pre-trained weights.
- **P5 (Evidence Preview & Contributions)**: Preview LR-TK0's effectiveness across datasets/backbones and list contributions: benchmark, WAR metric, LR-TK0 method, and insights.

## Priority Revision Plan
| Priority | Action Item | Expected Impact | Effort |
|---|---|---|---|
| **P0** | Provide explicit contrastive loss equation and multi-scale aggregation details for LR-TK0 training. | Improves reproducibility and methodological clarity. | Low |
| **P0** | Justify or ablate hyperparameters ($\alpha=200$, WAR coefficients) for proposed metrics. | Strengthens principled design of metrics. | Medium |
| **P1** | Clarify token injection operation (addition vs concatenation) and dimension matching. | Resolves ambiguity in method description. | Low |
| **P1** | Add paragraph contrasting LR-TK0 with prompt tuning/adapters and define "very LR" threshold. | Strengthens novelty positioning in Related Work. | Low |
| **P2** | Add limitations and future work paragraph to Conclusion. | Provides balanced closing and forward-looking perspective. | Low |
| **P2** | Bound strong claims (e.g., dataset quality vs size) to evaluated models/datasets. | Improves objectivity and defensibility. | Low |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Benchmark FM robustness under LR | 10 FMs, 66 backbones, 15 datasets, resolutions 16x16 to 224x224 | Top-1 Acc, SAR, WAR | Larger models/higher-quality data improve robustness; fine-tuning degrades it. | C1 (Benchmark) | Limited to 15 datasets; no variance reporting. |
| E2 | Evaluate WAR vs SAR | 66 models, Spearman correlation with individual dataset rankings | Correlation scores | WAR improves representation of outlier datasets (EuroSAT, ImageNet-A). | C3 (Metric) | Heuristic coefficients lack ablation. |
| E3 | Test LR-TK0 effectiveness | EVA, MetaCLIP, OpenCLIP; synthetic diffusion images; multi-scale training | SAR, WAR, Acc | LR-TK0 improves LR robustness with minimal HR drop (+3% params). | C2 (Method) | No comparison with matched-capacity adapters. |
| E4 | Ablate training choices | Frozen vs fine-tuned; task-agnostic vs task-oriented; multi-scale buckets | SAR-16, WAR-16 | Freezing weights and task-agnostic distillation yield best results. | C2 (Method) | Task-oriented ablation description is confusing. |

### Research-Theme Gap Diagnosis
The core research-value claims (new knowledge on LR robustness, reproducibility of LR-TK0, impact on practice) are well-supported by E1-E3. However, the lack of variance reporting and explicit loss formulation limits reproducibility. The metric design lacks principled justification, and novelty positioning against prompt tuning is weak.

### Proposed Research Experiments (P0/P1/P2)
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| C2 (Method) | LR-TK0 outperforms standard adapters/VPT under matched capacity. | Train LoRA/Adapter on same synthetic data; compare at 16x16. | VPT, LoRA, Adapter | WAR-16, Acc-16 | LR-TK0 matches or exceeds baselines. | Low | Strengthens novelty positioning. |
| C3 (Metric) | WAR coefficients are stable across different model pools. | Optimize WAR weights on 50% of models; test on remaining 50%. | SAR, fixed weights | Correlation stability | WAR maintains high correlation. | Low | Justifies metric design. |
| C1 (Benchmark) | LR robustness trends hold across seeds. | Report mean±std over 3 seeds for key benchmark results. | N/A | Acc variance | Variance < 1% | Medium | Improves statistical reliability. |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
Final Score: 6.5/10
Post-Revision Target: [7.5, 8.5]/10

**Scoring Rationale**: The paper presents a valuable and comprehensive benchmark (LR0.FM) and a practical, lightweight method (LR-TK0) for improving FM robustness under low-resolution conditions. The empirical insights are meaningful and the method shows strong performance. However, the score is moderated by heuristic metric design choices lacking justification, methodological ambiguities in token injection and loss formulation, and weak novelty positioning against existing prompt tuning methods. Addressing these issues through explicit formulations, ablations, and clearer related work synthesis would significantly strengthen the paper's rigor and impact.