## Summary
# Final Review Report

## Summary
This paper addresses the bandit learning problem in two-sided matching markets under the realistic assumption of indifferent preferences. Existing works typically assume strict preference rankings, which causes standard explore-then-Gale-Shapley strategies to fail (incurring linear regret) when preference gaps vanish. The authors propose an adaptive exploration algorithm based on arm-guided Gale-Shapley (AE-AGS) for both centralized and decentralized settings. By allowing players to adaptively explore arms that propose to them and treating statistically indistinguishable arms as equally optimal, AE-AGS avoids infinite exploration. The paper proves a stable regret bound of $O(NK \log T / \Delta^2)$, where $\Delta$ is the minimum non-zero preference gap, and demonstrates zero (centralized) or logarithmic (decentralized) regret when $\Delta=0$. Extensive experiments validate the theoretical claims, showing consistent superiority over extended baselines (C-ETC and P-ETC).

## Strengths
1. **Clear Problem Formulation and Motivation:** The paper identifies a critical gap in matching market literature—the assumption of strict preferences—and convincingly argues why indifference is a practical necessity (e.g., labor markets, school admissions). The failure mode of existing explore-then-GS strategies under indifference is well-explained.
2. **Robust Theoretical Guarantees:** The derivation of the $O(NK \log T / \Delta^2)$ regret bound for both centralized and decentralized settings is rigorous. The handling of the $\Delta=0$ edge case (zero regret in centralized, $O(\log T)$ in decentralized) is a strong theoretical contribution that highlights the algorithm's adaptivity.
3. **Elegant Algorithm Design:** The AE-AGS algorithm cleverly integrates exploration into the Gale-Shapley proposal process. By having players only explore arms that propose to them and adaptively eliminating sub-optimal arms via UCB/LCB comparisons, the method naturally balances exploration and exploitation without explicit phase separation.
4. **Comprehensive Experimental Validation:** The experiments cover varying preference gaps and market sizes, consistently demonstrating the algorithm's superiority over baselines. The inclusion of standard error bars and multiple independent runs adds credibility to the empirical claims.

## Weaknesses
1. **Lack of Quantitative Empirical Analysis:** The experimental discussion remains largely qualitative, stating that AE-AGS "consistently demonstrates good performances" without providing concrete regret deltas or percentage improvements over baselines at the end of the horizon. This reduces the impact of the empirical validation.
2. **Minor Notational and Typographical Issues:** There are a few typos and notational ambiguities that affect readability and reproducibility. For example, "Algoirthm 4" (Page 9), "there exists a player $a_{j'}$" instead of "arm $a_{j'}$" (Page 6), and unspecified tie-breaking rules in $\arg \min$ operations (Algorithm 2, Line 6).
3. **Under-Specified Randomness in Regret Definition:** The stable regret definition (Eq. 1) mentions expectation over reward randomness but does not explicitly account for algorithmic randomization (e.g., tie-breaking among indifferent arms), which is crucial in the indifference setting.
4. **Abstract and Introduction Structure:** The abstract lacks precision regarding the decentralized regret bound and the $\Delta=0$ case. The introduction's contribution statement is embedded in a dense paragraph rather than being explicitly enumerated, making it harder for readers to quickly grasp the scope.

## Key Issues
1. **Empirical Claim-Evidence Alignment:** The claim of "consistent superiority" is not backed by quantitative evidence in the text. Without explicit regret deltas or statistical significance tests, readers cannot fully assess the magnitude of the improvement over C-ETC and P-ETC.
2. **Algorithmic Reproducibility Details:** The decentralized algorithm relies on tie-breaking and $\arg \min$ operations. Without explicit randomization rules (e.g., uniform random tie-breaking), independent implementations may yield different behaviors, especially in high-indifference regimes.
3. **Theoretical Completeness in Regret Definition:** The stable regret expectation should formally encompass all sources of randomness, including the algorithm's internal tie-breaking mechanism. Omitting this creates a minor gap between the theoretical definition and the algorithmic execution under indifference.

## Actionable Suggestions
1. **Quantify Experimental Results:** In the experimental discussion (Page 19), add 1-2 sentences providing concrete regret deltas. For example: "At $T=100k$, AE-AGS reduces maximum cumulative stable regret by X% compared to C-ETC in the $\Delta=0.1$ setting." Also, explicitly mention that narrow error bars indicate stable convergence across seeds.
2. **Clarify Tie-Breaking and Randomness:** 
   - In Algorithm 2 (Line 6), specify that ties in $\arg \min_{j \in \mathcal{A}_i \setminus \mathcal{D}_i} T_{i,j}$ are broken uniformly at random.
   - In Eq. (1) (Page 5), update the expectation description to: "where the expectation is taken over the randomness of the sub-Gaussian rewards and the algorithm's internal randomization (e.g., tie-breaking)."
3. **Fix Typos and Notation:** 
   - Correct "Algoirthm 4" to "Algorithm 4" (Page 9).
   - Correct "there exists a player $a_{j'}$" to "there exists an arm $a_{j'}$" (Page 6).
   - Replace "interactive interactions" with "iterative interactions" (Page 4).
4. **Restructure Contributions:** Convert the final introduction paragraph into a bulleted or numbered list of contributions to improve scannability and emphasize the centralized/decentralized theoretical results and empirical validation separately.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem & Domain):** Two-sided matching markets are fundamental in economics, but existing bandit learning approaches assume strict preference rankings, failing when candidates exhibit comparable performance levels.
- **S2 (Significance/Challenge):** Indifference causes standard explore-then-Gale-Shapley strategies to incur linear regret, as exploration never stops when preference gaps vanish.
- **S3 (Prior Gap):** Existing algorithms either require knowledge of the minimum preference gap or suffer exponential regret under indifference.
- **S4 (Proposed Method):** We propose AE-AGS, an adaptive exploration algorithm where players only explore arms that propose to them and treat statistically indistinguishable arms as equally optimal.
- **S5 (Key Result & Implication):** We prove a stable regret of $O(NK \log T / \Delta^2)$ for both centralized and decentralized settings, with zero (centralized) or logarithmic (decentralized) regret when $\Delta=0$. Experiments demonstrate consistent superiority over baselines.

### Introduction Outline (Complete)
- **P1 (Big Picture):** Introduce two-sided matching markets and the Gale-Shapley algorithm, noting the foundational assumption of known, strict preferences.
- **P2 (Uncertainty Gap):** Explain how real-world markets involve uncertain preferences, motivating the multi-armed bandit (MAB) framework for iterative learning.
- **P3 (Bandit in Matching Markets):** Summarize prior work on stable regret in centralized and decentralized settings, highlighting the explore-then-GS paradigm.
- **P4 (Indifference Gap):** Detail why strict preference assumptions are unrealistic and how indifference breaks existing algorithms (divergent exploration budget when $\Delta \to 0$).
- **P5 (Proposed Solution & Contributions):** Introduce AE-AGS and explicitly enumerate contributions: (1) Algorithm design for centralized/decentralized settings, (2) Theoretical regret bounds including the $\Delta=0$ case, (3) Empirical validation showing logarithmic regret and stability.

## Priority Revision Plan
| Priority | Action Item | Expected Impact | Effort |
|---|---|---|---|
| **P0** | Quantify experimental results with regret deltas and variance stability analysis. | Strengthens empirical validation and claim-evidence alignment. | Low |
| **P0** | Clarify tie-breaking rules in Algorithm 2 and update regret definition (Eq. 1) to include algorithmic randomness. | Ensures theoretical completeness and reproducibility. | Low |
| **P1** | Restructure introduction contributions into an explicit enumerated list. | Improves readability and scannability for reviewers/readers. | Low |
| **P1** | Fix typos ("Algoirthm", "player $a_{j'}$") and redundant phrasing ("interactive interactions"). | Enhances professional polish and precision. | Low |
| **P2** | Add a brief note on the $O(NK)$ initialization overhead in the decentralized setting. | Contextualizes the regret bound transition. | Low |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup (data/split/protocol/baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Validate AE-AGS convergence in small markets with indifference. | N=5, K=5, Δ=0.1, T=100k. Baselines: C-ETC, P-ETC. | Cumulative Stable Regret, Market Unstability | AE-AGS shows lower regret and instability. | Centralized effectiveness | Qualitative analysis only. |
| E2 | Test sensitivity to preference gap Δ. | N=5, K=5, Δ ∈ {0.1, 0.15, 0.2, 0.25}. | Max Cumulative Regret, Unstability | Regret increases as Δ decreases. | Theoretical Δ dependency | Lacks quantitative deltas. |
| E3 | Test scalability with market size N, K. | N=K ∈ {3, 6, 9, 12}, Δ=0.1. | Max Cumulative Regret, Unstability | Regret scales with N, K. | Theoretical N, K dependency | No variance stability discussion. |

### Research-Theme Gap Diagnosis
The current experiments validate theoretical trends but lack quantitative rigor (exact regret gaps) and robustness analysis (variance across seeds). There is no explicit test of the decentralized communication overhead or the $\Delta=0$ edge case empirically.

### Proposed Research Experiments (P0/P1/P2)
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Estimated Cost/Time | Expected Paper-Quality Gain |
|---|---|---|---|---|---|---|---|
| Empirical Superiority | AE-AGS reduces regret by >X% vs baselines. | Run E1-E3, report absolute regret at T=100k. | C-ETC, P-ETC | Regret Delta (%) | Delta > 20% | Low (existing runs) | Strengthens empirical claims. |
| Variance Stability | AE-AGS has lower variance than baselines. | Report std dev across 20 seeds for E1. | C-ETC, P-ETC | Std Dev of Regret | AE-AGS std < Baseline std | Low | Demonstrates robustness. |
| Δ=0 Edge Case | Regret is 0 (centralized) or O(log T) (decentralized). | Set all μ_{i,j} identical. Run T=100k. | C-ETC, P-ETC | Cumulative Regret | Matches theoretical bound | Low | Validates edge-case theory. |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 7/10

**Rationale:** The paper addresses a meaningful and practical gap in matching market literature (indifference) with a theoretically sound and elegantly designed algorithm. The regret bounds are strong, and the decentralized extension is well-handled. The score is held back slightly due to the qualitative nature of the experimental discussion and minor notational/typographical issues that affect reproducibility and polish. With the suggested quantitative additions and clarifications, the paper would be significantly stronger.

**Post-Revision Target:** [8, 9]/10

**Justification:** Adding quantitative regret deltas, variance stability analysis, and fixing the minor theoretical/notation gaps will directly address the key weaknesses. This will elevate the empirical validation to match the high quality of the theoretical contributions, making the paper highly competitive for top-tier venues.