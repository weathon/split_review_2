## Summary
# Final Review Report

## Summary
This paper investigates the rotational equilibrium dynamics of weight vectors in deep neural networks, focusing on how weight decay and gradient updates interact to balance learning across layers. The authors derive approximate analytical expressions for the equilibrium norm and expected angular update size for AdamW, Lion, and SGD with momentum, extending prior Spherical Motion Dynamics (SMD) analysis. A key finding is that AdamW yields balanced rotation across neurons regardless of gradient magnitude, whereas Adam with L2-regularization results in imbalanced rotation, providing a mechanistic explanation for AdamW's empirical superiority. The authors also introduce Rotational Variants (RVs) of optimizers that explicitly enforce balanced rotation, eliminating the initial transient phase and simplifying training dynamics. Empirical experiments validate the theoretical predictions and demonstrate that RVs match baseline performance while offering insights into learning rate scheduling, normalization granularity, and the need for learning rate warmup.

## Strengths
1. **Theoretical Insight & Derivation:** The paper provides clear, intuitive derivations of rotational equilibrium for multiple optimizers (AdamW, Lion, SGDM), extending prior SMD analysis. The geometric model effectively separates gradient and weight decay components, making the equilibrium conditions accessible.
2. **Mechanistic Explanation for AdamW:** The finding that AdamW yields balanced rotation while Adam+L2 does not (due to gradient-magnitude dependency) is a strong, novel contribution that explains a widely observed empirical phenomenon.
3. **Empirical Validation:** The experiments are well-designed and directly validate the theoretical predictions. The use of Rotational Variants (RVs) to isolate the effect of rotation balance on the Adam vs AdamW performance gap is particularly clever and convincing.
4. **Practical Implications:** The analysis offers actionable insights for practitioners, such as the independent tuning of learning rate and weight decay to balance rotational weights versus biases/gains, and the connection between transient phases and the need for learning rate warmup.
5. **Reproducibility:** The authors provide code and detailed experimental setups in the appendix, facilitating verification and future research.

## Weaknesses
1. **Strong Random Walk Assumption:** The theoretical analysis relies on the assumption that batch gradients are dominated by noise ($g_B \approx g_N$), modeling training as a random walk. While empirically validated in Appendix G, this assumption may not hold for large batch sizes or late-stage training where the true gradient signal dominates. The main text should explicitly bound this assumption to early/mid-training or small-batch regimes.
2. **Limited Practical Utility of RVs:** The Rotational Variants (RVs) are primarily positioned as a research tool. While they match baseline performance, they do not consistently outperform AdamW. The paper could better highlight practical use cases (e.g., debugging optimization, large-batch stability) to strengthen the contribution's impact.
3. **Causal Isolation of Rotation Balance:** The experiment combining Adam+L2's update direction with AdamW's balanced rotation strongly suggests rotation balance explains the performance gap. However, the causal claim is slightly overstated; update direction geometry might also play a secondary role. Softening this claim would improve scientific rigor.
4. **Missing Practical Hypothesis on $\sqrt{\eta}$ Dependency:** The conclusion notes that $\eta_r \propto \sqrt{\eta}$ while $\eta_g \propto \eta$, raising questions about scheduling and batch scaling, but dismisses further exploration. Providing a concrete hypothesis or practical recommendation would add value.
5. **Table 1 Interpretation:** Table 1 effectively summarizes predictions but lacks an explicit caption note highlighting why the gradient-magnitude dependency in Adam+L2 is critical for the paper's main claim about imbalanced rotation.

## Key Issues
1. **Assumption Scope Clarification (Page 3 - Analysis Setup):** The random walk assumption ($g_B \approx g_N$) is central to the derivations but may not hold universally. *Action:* Explicitly bound this assumption to regimes where noise dominates (e.g., small batches, early training) and reference Appendix G for empirical validation in real settings.
2. **Causal Claim Precision (Page 8 - Adam vs AdamW):** The experiment isolating rotation balance strongly supports the hypothesis but does not fully rule out update direction geometry as a contributing factor. *Action:* Soften the causal language to acknowledge rotation balance as a *primary* driver rather than the sole explanation.
3. **Practical Takeaway Expansion (Page 7 - LR vs WD, Page 9 - Conclusion):** The $\eta_r \propto \sqrt{\eta}$ vs $\eta_g \propto \eta$ dependency is a valuable insight but lacks practical guidance. *Action:* Add explicit recommendations for independent tuning of $\eta$ and $\lambda$, and propose a hypothesis on how this affects large-batch scheduling.
4. **Table 1 Interpretability (Page 4 - Table 1):** The critical difference between AdamW and Adam+L2 (gradient-magnitude dependency) is buried in formulas. *Action:* Enhance the table caption to explicitly contrast the gradient-independent equilibrium of AdamW with the gradient-dependent equilibrium of Adam+L2.
5. **RV Positioning (Page 6 - Section 4):** RVs are framed primarily as a research tool, potentially underestimating their practical utility. *Action:* Highlight concrete use cases such as simplifying hyperparameter tuning, reducing warmup needs, or improving stability in poorly normalized architectures.

## Actionable Suggestions
1. **Refine Abstract Takeaways:** Replace "chaotic transient phase" with "initial transient phase" and explicitly state that RVs match baseline performance while simplifying dynamics, rather than implying significant accuracy gains.
2. **Strengthen Introduction Motivation:** Clarify that "balance" refers to relative angular updates rather than absolute gradient magnitudes, explicitly linking this to the scale-invariance property of normalized layers.
3. **Enhance Table 1 Caption:** Add a sentence explicitly contrasting the gradient-independent equilibrium of AdamW/SGDM/Lion with the gradient-dependent equilibrium of Adam+L2, highlighting why this causes imbalanced rotation.
4. **Bound Random Walk Assumption:** In Section 3, add a sentence acknowledging that the noise-dominated assumption is most accurate for small batches or early training, while pointing to Appendix G for empirical validation in real settings.
5. **Highlight RV Practical Utility:** In Section 4, explicitly mention practical benefits of RVs, such as simplifying hyperparameter tuning, reducing the need for learning rate warmup, and improving stability in poorly normalized architectures.
6. **Soften Causal Claims:** In the Adam vs AdamW experiment discussion, acknowledge that while rotation balance is a primary driver of AdamW's superiority, update direction geometry may also play a secondary role.
7. **Expand $\sqrt{\eta}$ Implications:** In the conclusion, propose a concrete hypothesis on how the $\eta_r \propto \sqrt{\eta}$ vs $\eta_g \propto \eta$ dependency affects large-batch training or cosine scheduling, rather than dismissing it as unexplored.
8. **Strengthen Warmup Connection:** In the discussion, state more confidently that the transient phase is a primary driver for the need for warmup, supported by the empirical evidence in Figure 8.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem/Domain):** Weight decay significantly impacts optimization dynamics by balancing gradient updates and parameter magnitude decay, forming a rotational equilibrium state.
- **S2 (Significance/Challenge):** This equilibrium stabilizes the expected angular update of weight vectors, effectively balancing the learning rate across network components, but transient phases and imbalanced rotation can hinder training.
- **S3 (Prior Gap):** Prior work has focused on SGD equilibrium, leaving the dynamics of modern optimizers like AdamW and the practical implications of rotation balance underexplored.
- **S4 (Method):** We derive approximate equilibrium expressions for AdamW, Lion, and SGD with momentum, revealing how learning rate and weight decay jointly determine an effective step size schedule.
- **S5 (Result/Implication):** By enforcing equilibrium via Rotational Variants (RVs), we eliminate transient phases and explain AdamW's superiority over Adam+L2, offering insights into normalization, scheduling, and warmup requirements.

### Introduction Outline (Complete)
- **P1 (Big Picture/Motivation):** Modern neural networks require balanced updates across diverse layers. While normalization mitigates vanishing/exploding gradients, it introduces scale-invariance, making relative angular updates more meaningful than absolute magnitudes.
- **P2 (Gap/Problem):** Imbalanced rotation across layers can cause instability or wasted compute. Standard optimizers exhibit transient phases and optimizer-dependent rotation balance (e.g., AdamW vs Adam+L2), but the underlying mechanisms and practical impacts are not fully understood.
- **P3 (Solution/Idea):** We analyze rotational equilibrium dynamics, deriving intuitive expressions for multiple optimizers. We show that AdamW yields balanced rotation unlike Adam+L2, and introduce Rotational Variants (RVs) to explicitly enforce this balance.
- **P4 (Evidence/Preview):** Empirical experiments validate our theoretical predictions, demonstrate that RVs match baseline performance while simplifying dynamics, and reveal how rotation balance explains AdamW's effectiveness, the need for warmup, and the impact of normalization granularity.
- **P5 (Contributions):** List the 4 consolidated contributions: (1) Equilibrium derivations, (2) Effective step size schedule insights, (3) AdamW vs Adam+L2 mechanistic explanation, (4) RV construction and practical implications.

## Priority Revision Plan
| Priority | Action | Expected Impact | Effort |
|---|---|---|---|
| **P0** | Bound the random walk assumption in Section 3 and explicitly reference Appendix G for empirical validation. | Improves theoretical rigor and prevents overgeneralization. | Low |
| **P0** | Enhance Table 1 caption to explicitly contrast AdamW's gradient-independent equilibrium with Adam+L2's gradient-dependent equilibrium. | Clarifies the core mechanism behind imbalanced rotation. | Low |
| **P1** | Soften causal claims in the Adam vs AdamW experiment discussion to acknowledge update direction geometry as a potential secondary factor. | Increases scientific defensibility. | Low |
| **P1** | Expand the discussion on $\eta_r \propto \sqrt{\eta}$ vs $\eta_g \propto \eta$ to include a concrete hypothesis for large-batch scheduling. | Adds practical value for practitioners. | Medium |
| **P2** | Highlight practical use cases for RVs (e.g., debugging, large-batch stability, reduced warmup needs) in Section 4. | Strengthens the contribution's impact beyond being a research tool. | Low |
| **P2** | Refine abstract wording to replace "chaotic transient phase" and explicitly state RV performance matches baselines. | Improves precision and manages reader expectations. | Low |
| **P3** | Strengthen the connection between transient phases and learning rate warmup in the conclusion, supported by Figure 8. | Makes the practical takeaway more compelling. | Low |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | RVs match baseline performance without transient phases. | CIFAR-10/100, ImageNet, IWSLT, Wikitext; ResNet, DeiT, Transformer, GPT. | Acc, BLEU, Perplexity | RV-AdamW matches AdamW zero-shot/best-shot. | RVs simplify dynamics without hurting performance. | RVs don't consistently outperform baselines. |
| E2 | AdamW yields balanced rotation; Adam+L2 does not. | Random walk setup, CIFAR-10 ResNet-18 sweep. | Angular updates per layer | Adam+L2 shows layer-wise variation; AdamW is homogeneous. | Gradient-magnitude dependency causes imbalance. | Limited to specific sweep settings. |
| E3 | Balancing rotation recovers Adam+L2 performance gap. | Special RV combining Adam+L2 direction with AdamW $\hat{\eta}_r$. | Validation Accuracy | Special RV recovers ~0.5% gap. | Rotation balance is a primary driver of AdamW superiority. | Update direction geometry not fully isolated. |
| E4 | Imbalanced rotation degrades performance. | Artificially scaling $\eta_r$ for fraction of neurons. | Validation Accuracy | Performance drops with imbalance. | Balanced rotation is beneficial. | Artificial imbalance may not reflect real dynamics. |
| E5 | RVs improve poorly normalized networks & reduce warmup need. | LayerNorm ResNet-18, ImageNet ResNet-50 large batch no warmup. | Validation Accuracy | RVs outperform baseline across LRs; stable without warmup. | RVs enforce balance; transient phase drives warmup need. | Limited to 10-epoch training for warmup exp. |

### Research-Theme Gap Diagnosis
The core research-value claims (new knowledge on equilibrium dynamics, reproducibility via code, impact on understanding AdamW/warmup) are well-supported. However, the practical impact of the $\eta_r \propto \sqrt{\eta}$ dependency on large-batch scheduling remains unexplored, and the causal isolation of rotation balance vs update direction geometry could be strengthened.

### Proposed Research Experiments (P0/P1/P2)
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| $\sqrt{\eta}$ scheduling impact | Adjusting LR schedule based on $\sqrt{\eta}$ dependency improves large-batch stability. | Train ResNet-50 on ImageNet with batch sizes 4k-16k using modified cosine schedule. | Standard AdamW, LARS. | Validation Acc, Training Stability | Improved stability/accuracy over standard AdamW. | Medium | Validates practical scheduling hypothesis. |
| Update direction geometry | AdamW's update direction geometry contributes secondarily to performance gap. | Compare RV-AdamW vs RV-Adam+L2 on diverse tasks. | AdamW, Adam+L2. | Validation Acc | Quantifies direction geometry contribution. | Low | Strengthens causal isolation. |
| Warmup necessity | RVs eliminate need for warmup in standard 90-epoch training. | Train ResNet-50 on ImageNet for 90 epochs with/without warmup using RV-SGDM. | Standard SGDM with warmup. | Validation Acc, Convergence Speed | RV-SGDM matches/exceeds warmup baseline. | High | Confirms warmup connection practically. |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 7.5/10

**Rationale:** The paper makes a strong theoretical contribution by deriving rotational equilibrium expressions for multiple optimizers and providing a compelling mechanistic explanation for AdamW's superiority over Adam+L2. The empirical validation is well-designed, particularly the experiment isolating rotation balance. The insights into learning rate scheduling, normalization granularity, and warmup requirements are valuable for both theorists and practitioners. The score is slightly reduced due to the strong random walk assumption requiring explicit bounding, the slightly overstated causal claims, and the limited practical utility positioning of the proposed RVs. With the suggested revisions to clarify assumptions, soften causal language, and expand practical implications, the paper would be highly competitive.

**Post-Revision Target:** [8.0, 9.0]/10