## Summary
# Final Review Report

## Summary

This paper addresses the challenge of sub-4 bit weight-only quantization for Large Language Models (LLMs), which is hindered by large-magnitude activation outliers that amplify rounding errors. The authors propose per-input-channel (per-IC) quantization as an alternative to the conventional per-output-channel (per-OC) approach, arguing that grouping weights along the input dimension effectively isolates outlier effects. Building on this, they introduce Adaptive Dimensions (AdaDim), a framework that dynamically selects between per-IC and per-OC quantization for each layer based on reconstruction error minimization. The method is integrated with Round-To-Nearest (RTN) and GPTQ, demonstrating significant accuracy improvements under INT3/INT4 settings across base and instruction-tuned LLMs. The paper also discusses a custom lookup-table kernel implementation and analyzes the incompatibility of per-IC quantization with AWQ.

## Strengths
1. **Clear and Intuitive Motivation**: The paper identifies a concrete structural issue—activation outliers affecting specific input channels—and proposes a logically sound solution (per-IC quantization) to isolate these effects. The intuition is well-explained and visually supported by Figure 1.
2. **Effective Adaptive Framework**: AdaDim provides a practical and computationally lightweight mechanism to adapt quantization grouping per layer. The binary search space (IC vs OC) ensures minimal overhead during the quantization process.
3. **Strong Empirical Results**: The method demonstrates significant accuracy improvements, particularly for INT3 quantization, where it notably enhances RTN and GPTQ performance. The gains on instruction-tuned models and task-specific calibration sets are particularly impressive.
4. **Comprehensive Analysis**: The paper includes valuable ablation studies (Table 2), sensitivity pattern visualizations (Figure 2), and a clear discussion of the incompatibility with AWQ, demonstrating a deep understanding of the quantization landscape.

## Weaknesses
1. **Hardware Efficiency Claims Need Validation**: While the paper claims per-IC quantization is feasible and shows latency improvements over cuBLAS, the kernel implementation is explicitly described as unoptimized. Without a direct comparison against highly optimized per-OC kernels (e.g., AWQ, OPTQ), the practical deployment advantage remains unproven.
2. **Overgeneralization of Results**: Some claims, such as "surpassing both AWQ and GPTQ," are bounded to specific settings (INT3, 7B model) but are presented in a way that could mislead readers into thinking this holds universally across all model sizes and bit-widths.
3. **Unverified Numerical Claims**: The reported "10.3% boost over vanilla RTN" in Section 4.3 cannot be directly verified from Table 4, raising concerns about calculation accuracy or missing context.
4. **Limited Discussion on Memory Overhead**: Per-IC quantization may introduce different memory access patterns or scaling factor storage requirements compared to per-OC. The paper does not explicitly analyze the memory overhead or cache efficiency implications of this grouping strategy.

## Key Issues
1. **Kernel Optimization Gap (Major)**: The current per-IC kernel is not fully optimized, and the paper lacks a latency comparison against state-of-the-art per-OC kernels. This undermines the claim of hardware efficiency and practical deployment readiness.
2. **Claim-Evidence Mismatch in Section 4.3 (Major)**: The "10.3% boost" claim does not align with the data presented in Table 4. This requires immediate verification and correction to maintain scientific rigor.
3. **Overstated Generalization (Minor)**: Claims of surpassing AWQ/GPTQ are specific to INT3/7B settings but are phrased broadly. Tighter bounding is needed to prevent reader misinterpretation.
4. **Missing Memory Overhead Analysis (Minor)**: The impact of per-IC grouping on memory access patterns, scaling factor storage, and cache efficiency is not discussed, which is critical for weight-only quantization deployment.

## Actionable Suggestions
1. **Validate and Correct Numerical Claims**: Re-calculate the improvements reported in Section 4.3 and explicitly map the "10.3% boost" to the specific model, task, and baseline in Table 4. If the number is incorrect, update it to reflect the actual maximum gain (e.g., 7.3% for WizCoder-Py-7B).
2. **Enhance Kernel Comparison**: Add a latency comparison table (Appendix D) that benchmarks the current per-IC kernel against optimized per-OC kernels like AWQ and OPTQ under identical group sizes and batch sizes. Discuss the theoretical latency bounds and optimization roadmap.
3. **Tighten Claim Bounding**: Revise phrases like "surpassing both AWQ and GPTQ" to explicitly state the conditions (e.g., "surpassing AWQ and GPTQ under INT3 w3g128 settings for the 7B model").
4. **Analyze Memory Overhead**: Add a short paragraph in Section 4.5 or Appendix discussing the memory footprint of per-IC scaling factors and any potential cache-miss penalties compared to per-OC grouping.
5. **Test Hybrid AdaDim-AWQ**: Conduct a small ablation study applying AWQ scaling to the per-OC layers selected by AdaDim, as suggested in Appendix A.2, to validate the potential for hybrid improvements.

## Storyline Options + Writing Outlines
### Abstract Outline
- **S1 (Problem)**: LLM deployment is memory-bound, making weight-only quantization essential, but sub-4 bit accuracy suffers from activation outliers.
- **S2 (Gap)**: Standard per-output-channel (per-OC) quantization spreads outlier effects across groups, limiting precision gains.
- **S3 (Method)**: We propose per-input-channel (per-IC) quantization to isolate outliers, integrated into AdaDim, an adaptive framework that selects the optimal grouping dimension per layer.
- **S4 (Result)**: AdaDim significantly boosts RTN and GPTQ accuracy under INT3/INT4 settings (e.g., +4.7% MMLU on 7B models) while maintaining hardware efficiency via a custom LUT kernel.
- **S5 (Impact)**: This approach provides a versatile, low-overhead solution for accurate low-bit LLM deployment.

### Introduction Outline
- **P1 (Context & Problem)**: Establish memory bandwidth bottleneck in autoregressive decoding and the promise/challenge of weight-only quantization due to activation outliers.
- **P2 (Prior Work Limitation)**: Explain how per-OC quantization fails to isolate outlier effects, leading to pervasive error amplification.
- **P3 (Proposed Solution)**: Introduce per-IC quantization intuition (Figure 1) and its feasibility in weight-only settings.
- **P4 (Adaptive Framework)**: Motivate AdaDim based on layer-dependent sensitivity patterns (Figure 2) and define the reconstruction error objective.
- **P5 (Contributions)**: List three concrete contributions: per-IC proposal, AdaDim framework, and empirical validation across base/instruction-tuned models with hardware efficiency discussion.

## Priority Revision Plan
| Priority | Action Item | Expected Impact | Effort |
|---|---|---|---|
| **P0** | Verify and correct the "10.3% boost" claim in Section 4.3 against Table 4 data. | Fixes factual inconsistency; restores reviewer trust. | Low |
| **P0** | Tighten claim bounding in Abstract and Section 4.2 (specify INT3/7B settings). | Prevents overgeneralization; improves scientific rigor. | Low |
| **P1** | Add latency comparison against optimized per-OC kernels (AWQ, OPTQ) in Appendix D. | Validates hardware efficiency claims; addresses major weakness. | Medium |
| **P1** | Expand Conclusion to recap key results, acknowledge kernel limitations, and outline future work. | Provides rigorous closure; improves narrative completeness. | Low |
| **P2** | Discuss memory overhead and cache efficiency implications of per-IC grouping. | Strengthens deployment feasibility analysis. | Low |
| **P2** | Conduct small ablation on hybrid AdaDim-AWQ for per-OC layers. | Validates Appendix A.2 hypothesis; potential incremental gain. | Medium |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Per-IC isolates outliers better than per-OC | LLaMA-V2 7B/13B, RTN, INT4 g128 | Wiki-2 PPL, MMLU | Per-IC improves PPL/MMLU on outlier-heavy modules | C1 | Heuristic module selection |
| E2 | Adaptive selection outperforms static heuristics | LLaMA-V2-13B, GPTQ ablation | MMLU 5-shot | AdaDim > fixed per-IC modules | C2 | Only tested on 13B |
| E3 | AdaDim boosts base model quantization | LLaMA-V2 7B/13B/33B/70B, INT3 g128 | MMLU, CSR | Significant gains over RTN/GPTQ; surpasses AWQ on 7B | C3 | Gains vary by model size |
| E4 | AdaDim improves instruction-tuned models | Vicuna, WizardLM, INT3 g128 | MMLU, CSR, GSM8k, HumanEval | Consistent improvements; task-specific calibration helps | C3 | 10.3% claim unverified |
| E5 | Per-IC kernel latency vs cuBLAS | OPT-175B FFN, INT3/4 | Latency (ms) | Faster than cuBLAS, slower than optimized per-OC | Hardware feasibility | Unoptimized kernel |

### Research-Theme Gap Diagnosis
The core research value (accurate low-bit quantization via outlier isolation) is well-supported. However, the practical deployment value is weakened by the lack of optimized kernel benchmarks and memory overhead analysis.

### Proposed Research Experiments
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| Hardware Efficiency | Optimized per-IC kernel matches per-OC latency | Implement tile-optimized per-IC LUT kernel | AWQ, OPTQ kernels | Latency (ms), Throughput (tok/s) | Latency within 5% of AWQ | Medium | Validates deployment claim |
| Memory Overhead | Per-IC scaling factors incur negligible memory cost | Measure VRAM usage for scaling factors | Per-OC baseline | Peak VRAM (MB) | <1% overhead | Low | Strengthens feasibility |
| Hybrid AdaDim-AWQ | AWQ scaling helps per-OC layers selected by AdaDim | Apply AWQ to AdaDim-selected per-OC layers | Vanilla AdaDim | MMLU, PPL | +0.5% accuracy gain | Low | Validates Appendix A.2 |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score**: 6.5/10

**Rationale**: The paper presents a clear, intuitive, and empirically effective method (AdaDim) for improving low-bit weight quantization by isolating activation outliers via per-IC grouping. The motivation is strong, and the results on INT3 quantization are impressive. However, the score is moderated by the lack of optimized kernel benchmarks (weakening the hardware efficiency claim), an unverified numerical claim in Section 4.3, and somewhat overstated generalization in the abstract and results sections. With targeted revisions to validate claims and tighten bounding, the paper has strong potential.

**Post-Revision Target**: [7.5, 8.5]/10

**Key Conditions for Target**:
1. Correct the "10.3% boost" calculation and explicitly map it to Table 4 data.
2. Provide a latency comparison against optimized per-OC kernels (AWQ/OPTQ) to substantiate efficiency claims.
3. Tighten claim bounding in the abstract and Section 4.2 to reflect specific INT3/7B settings.