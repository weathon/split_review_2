## Summary
# Final Review Report

## Summary
This paper introduces a novel EEG dataset designed to capture semantic text relevance through time-locked word-level recordings. The dataset contains 23,270 recordings from 15 participants who read Wikipedia documents relevant or irrelevant to self-selected topics. The authors present benchmark experiments using five models (EEGNet, LDA, LR, UERCM, LSTM) under cross-subject and within-subject paradigms for word and sentence relevance classification. The results demonstrate that within-subject paradigms significantly outperform cross-subject approaches, and temporal models achieve high accuracy (up to 0.97 AUC for sentence relevance). The dataset and code are openly released to advance research in psycholinguistics, information retrieval, and brain-computer interfaces. While the dataset is well-designed and addresses a clear gap in prior work, the manuscript would benefit from tighter bounding of novelty claims, more precise justification of sample size, and clearer differentiation from closely related datasets like Ye et al. (2022).

## Strengths
1. **Clear Research Gap and Motivation**: The paper effectively identifies a gap in existing neurophysiological datasets, specifically the lack of time-locked word-level EEG recordings for goal-directed, semantic relevance tasks. The motivation for using fixed-duration word presentation to minimize eye-movement confounds is scientifically sound and well-articulated.
2. **High-Quality Dataset and Open Release**: The dataset is substantial (23,270 recordings) and carefully curated from Wikipedia documents. The open release of both raw and preprocessed data, along with benchmark code, significantly enhances reproducibility and utility for the research community.
3. **Comprehensive Benchmarking**: The authors provide a thorough benchmark using five diverse models (EEGNet, LDA, LR, UERCM, LSTM) under two evaluation paradigms (cross-subject and within-subject). The results clearly demonstrate the value of within-subject fine-tuning and temporal modeling for EEG-based relevance decoding.
4. **Rigorous ERP Analysis**: The inclusion of Event-Related Potential (ERP) analysis validates the dataset against established psychophysiological literature (P300, N400, P600 components), providing strong evidence that the recorded signals genuinely reflect semantic relevance processing.

## Weaknesses
1. **Unbounded Novelty Claims**: The manuscript repeatedly uses absolute phrasing such as "which has not been done previously" and "not addressed by any currently available datasets." Given the existence of other time-locked EEG datasets (e.g., Murphy et al., 2022), these claims are risky and should be bounded to the specific task of semantic relevance for self-selected topics, using cautious phrasing like "to our knowledge."
2. **Vague Justification for Sample Size**: The discussion of the 15-participant sample size relies on a heuristic ("more important to have more samples per participant") without citing specific power analysis or inter-subject variability literature. While consistent with some prior EEG studies, a stronger methodological justification is needed to preempt reviewer concerns about generalizability.
3. **Overstated SOTA Comparison**: The claim of achieving "state-of-the-art results" compared to Eugster et al. (2014; 2016) is problematic because those studies used different stimuli, tasks, and evaluation protocols. Direct SOTA claims across non-comparable settings can be misleading and should be reframed as "competitive performance" with explicit caveats.
4. **Dense ERP Interaction Interpretation**: The interpretation of the four-way ANOVA interactions (relevance × time × position) is statistically dense and uses vague phrasing ("inferred three latent ERP potentials"). Clarifying that these interactions reflect the evolving temporal dynamics of relevance processing across scalp regions would improve readability and scientific impact.

## Key Issues
1. **Defensibility of Novelty Claims**: The absolute novelty claims risk being challenged by reviewers familiar with adjacent datasets (e.g., Murphy et al., 2022 for time-locked word EEG, or Ye et al., 2022 for relevance tasks). The manuscript must explicitly differentiate its contribution by emphasizing the unique combination of *time-locked word presentation* + *self-selected topic relevance* + *goal-directed reading paradigm*.
2. **Comparability of Benchmark Results**: The comparison with Eugster et al. (2014; 2016) lacks a clear discussion of differences in stimuli (Wikipedia snippets vs. other texts), task design (self-selected topics vs. external questions), and evaluation metrics. Without this context, the SOTA claim is scientifically weak.
3. **Sample Size and Generalizability**: While 15 participants is common in EEG studies, the homogeneous student population limits external validity. The manuscript should explicitly bound generalizability claims to the tested demographic and provide stronger methodological backing for the sample size choice.

## Actionable Suggestions
1. **Bound Novelty Claims**: Replace absolute phrases like "which has not been done previously" with "to our knowledge, this combination has not been addressed." Explicitly differentiate from Murphy et al. (2022) and Ye et al. (2022) in the Related Work section by highlighting the unique goal-directed, self-selected topic paradigm.
2. **Refine SOTA Comparison**: Change "We achieve state-of-the-art results" to "Our results demonstrate competitive performance relative to prior word relevance decoding studies." Add a sentence acknowledging differences in stimuli and task design to ensure fair comparability.
3. **Strengthen Sample Size Justification**: Cite specific literature on inter-subject variability in EEG or power analysis guidelines (e.g., Brysbaert, 2019) in the Method section. Bound generalizability claims to the tested demographic (English-fluent, right-handed students) in the Discussion.
4. **Clarify ERP Interpretation**: Replace "we inferred three latent ERP potentials" with "these interactions suggest that the neural signature of semantic relevance evolves over time and varies across scalp regions, consistent with established ERP components." This improves readability and scientific precision.
5. **Add Key Results to Abstract**: Append one sentence to the abstract summarizing the best-performing model and its AUC (e.g., "achieving up to 0.97 AUC in within-subject sentence relevance classification") to immediately convey empirical impact.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem/Domain)**: Electroencephalography (EEG) enables non-invasive, real-time measurement of brain activity during language processing, offering a direct alternative to behavioral relevance signals.
- **S2 (Significance/Challenge)**: While prior EEG datasets capture naturalistic reading or psycholinguistic tasks, they lack precise time-locked word-level alignment for goal-directed semantic relevance.
- **S3 (Gap)**: Existing datasets either rely on eye-tracking (introducing oculomotor artifacts) or artificial question-answering paradigms that do not simulate intrinsic, self-selected topic relevance.
- **S4 (Method)**: We release a novel dataset containing 23,270 time-locked (∼0.7s) word-level EEG recordings from participants reading Wikipedia documents relevant or irrelevant to self-selected topics.
- **S5 (Result/Implication)**: Benchmark experiments with five models demonstrate that within-subject paradigms achieve up to 0.97 AUC for sentence relevance, paving the way for brain-computer interfaces and relevance-aware retrieval systems.

### Introduction Outline (Complete)
- **P1 (Big Picture & Gap)**: Establish the importance of semantic relevance in language processing and information retrieval. Contrast behavioral signals (clicks, dwell time) with direct brain measurements. Highlight the gap: prior EEG datasets lack time-locked word-level alignment for goal-directed reading.
- **P2 (Novelty & Solution)**: Introduce the dataset's core novelty: time-locked word presentation minimizing eye-movement confounds, combined with self-selected topic relevance. Explicitly differentiate from Ye et al. (2022) by framing their work as an "artificial question-answering scenario" versus your "natural goal-directed reading."
- **P3 (Benchmark Preview)**: Outline the two tasks (word/sentence relevance) and evaluation paradigms (cross-subject/within-subject). Preview the key finding: within-subject fine-tuning and temporal models significantly outperform baselines.
- **P4 (Contribution Summary)**: Summarize the three contributions: (1) novel time-locked EEG dataset for semantic relevance, (2) comprehensive benchmark with five models, (3) open release of data and code to advance BCI and IR research.

## Priority Revision Plan
| Priority | Action | Expected Impact | Effort |
|---|---|---|---|
| **P0 (Critical)** | Bound novelty claims in Abstract, Intro, and Conclusion using "to our knowledge" and explicitly differentiate from Murphy et al. (2022) and Ye et al. (2022). | Prevents rejection for overstated novelty; ensures scientific defensibility. | Low |
| **P0 (Critical)** | Reframe SOTA claim vs. Eugster et al. (2014; 2016) as "competitive performance" with explicit caveats on stimuli/task differences. | Eliminates misleading comparison; improves reviewer trust. | Low |
| **P1 (High)** | Strengthen sample size justification in Method/Discussion by citing power analysis literature (e.g., Brysbaert, 2019) and bounding generalizability to tested demographic. | Addresses common reviewer concern about small N; improves external validity framing. | Medium |
| **P1 (High)** | Clarify ERP interaction interpretation by replacing "inferred three latent ERP potentials" with precise language about evolving temporal dynamics across scalp regions. | Improves readability and scientific precision of psychophysiological validation. | Low |
| **P2 (Medium)** | Add key empirical results (best model AUC) to Abstract to immediately convey dataset utility. | Enhances reader engagement and impact statement. | Low |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup (data/split/protocol/baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Word relevance classification | 15 participants, cross-subject & within-subject, 5 models (EEGNet, LDA, LR, UERCM, LSTM) | AUC, Precision, Recall | Within-subject outperforms cross-subject; LSTM achieves 0.82 AUC | Temporal models + fine-tuning improve decoding | No ablation on feature selection (s=151 vs s=7) |
| E2 | Sentence relevance classification | Same as E1, averaged EEG per sentence | AUC, Precision, Recall | LSTM achieves 0.97 AUC (within-subject) | High decodability at sentence level | No comparison to text-only baselines |
| E3 | ERP Analysis | 4-factor ANOVA (time, relevance, coronal, lateral) | F-values, p-values | Significant main effect of relevance & interactions | Dataset validates against psychophysiology | Dense interpretation of interactions |

### Research-Theme Gap Diagnosis
The core research-value claim (dataset enables robust, generalizable relevance decoding) is partially supported. The high within-subject AUC demonstrates decodability, but the lack of cross-dataset validation or out-of-domain testing limits claims about generalizability. Additionally, the absence of text-only baselines makes it unclear how much the EEG signal adds beyond semantic text features.

### Proposed Research Experiments (P0/P1/P2)
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Estimated Cost/Time | Expected Paper-Quality Gain |
|---|---|---|---|---|---|---|---|
| Generalizability | EEG relevance decoding transfers to unseen topics | Train on 80% of topics, test on 20% held-out topics | Same models, cross-subject split | AUC drop | <10% drop from full data | Low (1 day) | Validates external validity claim |
| Modality Value | EEG adds value beyond text semantics | Fuse EEG + text embeddings (e.g., BERT) vs. text-only | Text-only baseline | AUC, F1 | EEG+Text > Text-only | Medium (3 days) | Quantifies multimodal benefit |
| Robustness | Performance is stable across seeds | Repeat E1/E2 with 5 different random seeds | Same setup | Mean±std AUC | std < 0.02 | Low (2 days) | Improves statistical reliability |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
Final Score: 6.5/10
Post-Revision Target: [7.5, 8.5]/10

**Scoring Rationale**: The paper presents a high-quality, well-designed EEG dataset that addresses a clear gap in neurophysiological language processing research. The benchmark experiments are comprehensive and demonstrate strong decodability of semantic relevance. However, the current score is moderated by unbounded novelty claims, an overstated SOTA comparison with non-comparable prior work, and a weak justification for the sample size. Addressing these defensibility issues (P0 revisions) and adding minor robustness checks (P1/P2) would significantly improve the manuscript's scientific rigor and reviewer confidence, justifying the post-revision target.