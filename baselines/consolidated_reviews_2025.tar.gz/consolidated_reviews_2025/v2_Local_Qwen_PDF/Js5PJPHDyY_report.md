## Summary
# Final Review Report

## Summary
This paper revisits Gaussian Discriminant Analysis (GDA) as a training-free adaptation method for CLIP-based downstream classification. By assuming class-conditional Gaussian features with shared covariance, the authors derive a closed-form linear classifier using empirical means and a shrinkage-estimated precision matrix. This visual GDA classifier is then ensembled with the CLIP zero-shot text classifier to balance data-driven adaptation with semantic priors. The method is further extended to base-to-new generalization (via KNN data synthesis) and unsupervised learning (via EM algorithm for GMM). Extensive experiments across 17 datasets demonstrate that the proposed approach consistently outperforms training-free baselines and matches or exceeds training-required methods in few-shot, imbalanced, and out-of-distribution settings, establishing a strong, computationally efficient baseline for CLIP adaptation.

## Strengths
1. **Conceptual Simplicity and Efficiency:** The method leverages classical GDA to construct a training-free classifier, eliminating the need for gradient-based optimization. This results in negligible computational overhead (seconds vs. minutes/hours for baselines) and zero trainable parameters, making it highly suitable for resource-constrained deployment.
2. **Strong Empirical Performance:** The approach consistently outperforms existing training-free baselines and matches or exceeds training-required methods across diverse settings (few-shot, imbalanced, OOD, base-to-new, unsupervised) on 17 datasets, validating the effectiveness of statistical adaptation in CLIP feature spaces.
3. **Versatile Extensions:** The straightforward extensions to base-to-new generalization (via KNN synthesis) and unsupervised learning (via EM algorithm) demonstrate the method's adaptability to scenarios where labeled data is scarce or unavailable, without introducing complex architectural changes.
4. **Comprehensive Evaluation:** The paper provides extensive experiments covering multiple CLIP architectures (ResNet-50/101, ViT-B/32/16), diverse datasets, and detailed ablation studies on precision matrix estimation, sample size scaling, and hyperparameter sensitivity, ensuring robust validation of the proposed approach.

## Weaknesses
1. **Factual Inaccuracy in Related Work:** The manuscript incorrectly claims that Ledoit-Wolf and OAS shrinkage estimators "require additional optimization processes." These are closed-form analytical estimators. This mischaracterization weakens the motivation for selecting the empirical Bayes ridge-type (KS) estimator and undermines methodological rigor.
2. **Under-Specified Unsupervised Initialization:** The EM algorithm for unsupervised learning is highly sensitive to initialization, yet the paper only vaguely states that parameters are "initialized using the zero-shot classifier." The exact procedure (e.g., pseudo-label assignment, initial covariance computation) and convergence criteria are missing, posing a reproducibility risk.
3. **Unverified Causal Claims on Imbalanced Learning:** The improvement in few-shot/medium-shot accuracy is directly attributed to the "identical covariance assumption... transferring knowledge from many-shot classes." Without an ablation comparing GDA against per-class covariance (QDA), this causal claim remains speculative and could be confounded by regularization effects or ensemble benefits.
4. **Logit Scale Mismatch in Ensemble:** Equation (5) mixes text and visual logits linearly without addressing potential scale differences. While $\alpha$ compensates for this, the lack of temperature scaling or normalization makes the ensemble sensitive to dataset-specific logit distributions, requiring validation-based tuning that slightly detracts from the "training-free" simplicity.
5. **Pseudocode Reproducibility Issue:** The provided PyTorch pseudocode contains a shape mismatch in `torch.cov(centered_X)`. PyTorch expects `(features, samples)` input, but `centered_X` is `(N, D)`. This will cause runtime errors or incorrect covariance computation if implemented directly.

## Key Issues
1. **Mischaracterization of Shrinkage Estimators (Major):** Claiming Ledoit-Wolf and OAS require iterative optimization is factually incorrect. This must be corrected to maintain scientific accuracy and properly motivate the KS estimator choice based on empirical performance or high-dimensional theoretical properties.
2. **Reproducibility Risk in Pseudocode (Major):** The `torch.cov` shape mismatch in Algorithm 1 will break implementation. Correcting this to `torch.cov(centered_X.T)` is essential for readers to reproduce the results.
3. **Vague Unsupervised Initialization (Major):** The EM algorithm's initialization strategy lacks concrete steps. Explicitly detailing pseudo-label assignment and convergence thresholds is necessary to ensure the unsupervised variant is reproducible and stable.
4. **Over-Attribution of Imbalanced Learning Gains (Minor):** The causal link between shared covariance and few-shot improvement is asserted without isolating the mechanism. Softening the language and adding a QDA comparison would strengthen the argument.
5. **Logit Scale Mismatch in Ensemble (Minor):** Direct logit mixing ignores potential scale differences between text and visual classifiers. Discussing this limitation or introducing temperature scaling would improve the method's robustness and reduce hyperparameter sensitivity.

## Actionable Suggestions
1. **Correct Related Work Description:** Revise the "High-dimensional Covariance Estimation" paragraph to accurately describe Ledoit-Wolf and OAS as closed-form estimators. Reposition the motivation for the KS estimator by highlighting its empirical superiority in the $N < D$ regime (referencing Table 6) rather than computational complexity.
2. **Fix Pseudocode Shape Mismatch:** Update Algorithm 1 Line 21 to `cov = torch.cov(centered_X.T)` and add a comment clarifying PyTorch's expected input shape for covariance computation.
3. **Detail Unsupervised Initialization:** Expand the "Extension to Unsupervised Learning" section to explicitly list initialization steps: (1) compute zero-shot predictions, (2) assign hard pseudo-labels, (3) compute initial empirical means and pooled covariance. Specify the convergence criterion (e.g., log-likelihood threshold or max iterations).
4. **Soften Causal Claims on Imbalanced Learning:** Replace definitive causal language with "is consistent with" or "may benefit from." Add a brief ablation comparing GDA against Quadratic Discriminant Analysis (QDA) to isolate the effect of the shared covariance assumption.
5. **Address Logit Scale Mismatch:** Discuss the potential scale differences between text and visual logits in Eq. (5). Consider introducing temperature parameters $T_{text}$ and $T_{vis}$ or normalizing logits before mixing to improve robustness and reduce $\alpha$ sensitivity.
6. **Enhance Conclusion with Limitations:** Add 2-3 sentences to the conclusion acknowledging boundary conditions (e.g., performance drops in highly non-Gaussian domains) and proposing concrete future directions (e.g., adaptive covariance structures or cross-modal calibration).

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Context & Gap):** CLIP offers strong zero-shot capabilities, but efficient fine-tuning methods (e.g., prompt learning, adapters) still require gradient-based optimization, limiting deployment on resource-constrained devices.
- **S2 (Proposed Method):** We revisit Gaussian Discriminant Analysis (GDA) and adapt it for training-free CLIP classification by deriving a closed-form linear classifier from empirical class means and a shrinkage-estimated shared precision matrix.
- **S3 (Core Mechanism):** To balance data-driven visual adaptation with pretrained semantic priors, we ensemble the GDA classifier with the CLIP zero-shot text classifier via a simple logit weighting scheme.
- **S4 (Key Results):** Extensive experiments across 17 datasets show our method consistently outperforms training-free baselines and matches/exceeds training-required methods in few-shot, imbalanced, and out-of-distribution settings.
- **S5 (Extensions/Impact):** We further demonstrate the method's versatility by extending it to base-to-new generalization and unsupervised learning, establishing a strong, computationally efficient baseline for CLIP adaptation.

### Introduction Outline (Complete)
- **P1 (Background & Limitation):** Introduce CLIP's zero-shot success but explicitly state its limitations (semantic gap, prompt sensitivity, distribution mismatch) to motivate adaptation.
- **P2 (Gap in Prior Work):** Discuss efficient fine-tuning methods (CoOp, CLIP-Adapter, Tip-Adapter) and highlight their shared drawback: reliance on additional training time and computational resources, which hinders real-world deployment.
- **P3 (Proposed Solution & Intuition):** Introduce GDA as a training-free alternative. Explain the intuition: CLIP features exhibit class-conditional Gaussian structures with shared covariance, enabling closed-form classifier construction without SGD.
- **P4 (Method Overview & Ensemble):** Detail the parameter estimation (empirical means, KS precision matrix) and the ensemble strategy. Clarify how visual GDA and text zero-shot classifiers complement each other to reduce overfitting.
- **P5 (Extensions & Contributions):** Summarize the extensions to base-to-new (KNN synthesis) and unsupervised (EM algorithm) settings. List concrete contributions: (1) training-free GDA adaptation, (2) comprehensive evaluation across 17 datasets, (3) versatile extensions maintaining simplicity.

## Priority Revision Plan
| Priority | Issue | Action | Expected Impact |
|---|---|---|---|
| **P0** | Factual error on Ledoit-Wolf/OAS optimization | Correct description to closed-form; reposition KS motivation based on empirical performance (Table 6). | Restores methodological rigor and accurate related work context. |
| **P0** | Pseudocode `torch.cov` shape mismatch | Update to `torch.cov(centered_X.T)` and add shape comments. | Ensures direct reproducibility of the core algorithm. |
| **P1** | Vague unsupervised EM initialization | Detail pseudo-label assignment, initial covariance computation, and convergence criteria. | Improves reproducibility and stability of the unsupervised variant. |
| **P1** | Unverified causal claim on imbalanced learning | Soften language to "consistent with"; add QDA ablation to isolate shared covariance effect. | Strengthens mechanistic interpretation and prevents over-attribution. |
| **P2** | Logit scale mismatch in ensemble | Discuss scale differences; optionally introduce temperature scaling or normalization. | Enhances robustness and reduces hyperparameter sensitivity. |
| **P2** | Conclusion lacks limitations | Add 2-3 sentences on boundary conditions (e.g., non-Gaussian domains) and specific future work. | Improves scientific credibility and guides subsequent research. |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Few-shot classification vs training-free/training-required | 11 datasets, 1-16 shot, ResNet-50 | Accuracy | Outperforms training-free, matches training-required | C1, C2 | Lacks variance reporting across seeds |
| E2 | OOD generalization | ImageNet -> V2/Sketch/A/R, ViT-B/16 | Accuracy | Highest avg accuracy across 4 targets | C1 | No statistical significance tests |
| E3 | Imbalanced learning | ImageNet-LT, Places-LT, ResNet-101 | Acc/F1 (Many/Med/Few) | Surpasses training-required baselines | C1 | Causal mechanism unverified |
| E4 | Base-to-new generalization | 11 datasets, 16-shot base | Base/New/Harmonic Mean | Outperforms CoOp/CoCoOp/KgCoOp | C3 | Relies on KNN synthesis quality |
| E5 | Unsupervised learning | 11 datasets, EM algorithm | Accuracy | Matches UPL/POUF | C3 | Initialization details missing |
| E6 | Precision matrix ablation | EuroSAT, 6 estimators | Accuracy | KS estimator performs best | C1 | Only tested on one dataset |
| E7 | Ensemble ablation | 11 datasets, zero-shot vs linear vs ensemble | Accuracy | Ensemble consistently best | C2 | Logit scale mismatch unaddressed |

### Research-Theme Gap Diagnosis
The core research value (training-free statistical adaptation) is well-supported, but mechanistic understanding (why shared covariance helps imbalanced learning) and reproducibility details (EM initialization, pseudocode shapes) are weakly supported. Robustness evidence (variance, significance tests) is also thin relative to the strength of the conclusions.

### Proposed Research Experiments (P0/P1/P2)
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| Imbalanced mechanism | Shared covariance regularizes few-shot classes better than per-class covariance. | Compare GDA vs QDA on ImageNet-LT/Places-LT. | GDA (shared) vs QDA (per-class) | Few-shot Acc, F1 | GDA > QDA consistently | Low | Isolates causal mechanism |
| Unsupervised stability | EM initialization via zero-shot pseudo-labels ensures stable convergence. | Report EM convergence curves and variance over 3 seeds. | Current EM vs random init | Accuracy, Log-likelihood | Stable convergence, low variance | Low | Improves reproducibility |
| Robustness validation | Performance gains are statistically significant and seed-stable. | Report mean±std over 5 seeds for E1-E3. | All baselines re-run with same seeds | Accuracy ± std | Non-overlapping CIs | Medium | Strengthens empirical claims |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 6.5/10
The paper presents a conceptually simple and highly efficient training-free adaptation method for CLIP, with strong empirical performance across diverse settings. However, the score is moderated by factual inaccuracies in the related work, reproducibility risks in the pseudocode and unsupervised initialization, and unverified causal claims regarding the imbalanced learning mechanism. Addressing these issues would significantly strengthen the manuscript's scientific rigor and credibility.

**Post-Revision Target:** [7.5, 8.5]/10
If the authors correct the shrinkage estimator description, fix the pseudocode shape mismatch, detail the EM initialization, and add a QDA ablation to isolate the shared covariance effect, the paper will achieve a high level of methodological soundness and reproducibility, fully supporting its strong empirical contributions.