## Summary
# Final Review Report

## Summary

This paper introduces DORAEMON (DOmain RAndomization via Entropy MaximizatiON), a novel method for automating Domain Randomization (DR) in Reinforcement Learning to improve sim-to-real transfer. The core challenge in DR is selecting the sampling distribution of dynamics parameters: too narrow leads to poor generalization, while too wide causes policy collapse. DORAEMON addresses this by formulating a constrained optimization problem that directly maximizes the entropy of the training distribution while maintaining a target probability of policy success ($\alpha$). 

The method employs an importance sampling estimator to approximate the success rate using naturally collected training data, avoiding the need for expensive Monte-Carlo rollouts. To handle constraint violations and prevent performance collapse, a backup optimization problem is introduced to backtrack the distribution entropy within a trust region. The authors evaluate DORAEMON on six MuJoCo locomotion benchmarks and a novel 7-DoF PandaPush robotic manipulation task. Results demonstrate that DORAEMON achieves superior generalization across wider dynamics ranges compared to baselines (No-DR, Fixed-DR, LSDR, AutoDR) and successfully transfers to the real world under unknown dynamics parameters. The paper is well-structured, with clear mathematical formulations and comprehensive ablation studies in the appendix.

## Strengths
1. **Clear and Intuitive Core Mechanism:** The formulation of DORAEMON as a constrained entropy maximization problem subject to a success probability constraint is elegant and directly addresses the fundamental trade-off in Domain Randomization (diversity vs. stability). The intuition that maximizing distribution entropy encourages broader generalization is well-motivated and mathematically grounded.

2. **Sample-Efficient Implementation:** The use of an importance sampling (IS) estimator to approximate the success rate using naturally collected training episodes is a significant practical advantage. Unlike baselines like LSDR or AutoDR, which require additional Monte-Carlo rollouts or boundary evaluations, DORAEMON updates the distribution without extra environment interactions, improving data efficiency.

3. **Robust Backup Optimization:** The introduction of the backup optimization problem (Eq. 6) to backtrack the distribution entropy when the success constraint is violated is a crucial technical contribution. This mechanism effectively prevents policy collapse and maintains training stability, as demonstrated by the ablation studies in Appendix B.

4. **Comprehensive Empirical Validation:** The paper provides thorough evaluations across six MuJoCo locomotion tasks and a novel, dynamics-sensitive 7-DoF PandaPush manipulation task. The Sim2Real transfer results on real hardware under unknown center-of-mass and friction conditions strongly validate the method's practical utility.

5. **Deep Theoretical Contextualization:** Appendix B offers an insightful comparison between DORAEMON, self-paced curriculum learning, and projection-based methods (I-projection vs. M-projection). This deepens the theoretical understanding of why DORAEMON avoids the limitations of prior automated DR approaches.

## Weaknesses
1. **Missing Optimization Solver Details:** The method description does not specify the numerical optimization solver or algorithm used to solve the constrained problems in Eq. (4) and Eq. (6) (e.g., L-BFGS-B, SLSQP). This omission hinders reproducibility, as the choice of solver can significantly impact convergence stability, especially with the KL divergence trust region constraint.

2. **Overbroad Generalization Claims:** The abstract and introduction claim that DORAEMON solves tasks "across the widest range of dynamics parameters" and achieves "remarkable Sim2Real transferability." These claims are slightly promotional and should be bounded to the evaluated benchmarks and bounded search spaces to maintain scientific rigor.

3. **Hyperparameter Tuning Transparency:** While Appendix A.2 details the tuning process for key hyperparameters ($\epsilon$ for DORAEMON, $\alpha$ for LSDR, etc.), the final selected values for each environment are not explicitly reported in a table or list. This makes it difficult for readers to replicate the exact experimental setup.

4. **Bounded Support Assumption Limitation:** The method relies on bounded-support distributions (e.g., Beta) to define a well-defined maximum entropy state. This assumes known physical bounds for dynamics parameters, which may not always align with unbounded or poorly characterized real-world dynamics. This limitation is not explicitly discussed in the main text.

5. **Real-World Evaluation Protocol Clarity:** The main text mentions 30 real-world rollouts but does not explicitly detail the breakdown of physical configurations and seeds until the appendix. Clarifying this in the main text (3 configurations $\times$ 10 seeds) would improve transparency regarding the statistical significance of the Sim2Real results.

## Key Issues
1. **Reproducibility of Distribution Updates (Major):** The absence of specific optimization solver details for Eq. (4) and Eq. (6) is a critical reproducibility gap. Readers cannot determine how the constrained entropy maximization and backup optimization are numerically solved, which is essential for replicating the method's stability and performance.

2. **Claim-Evidence Alignment (Minor):** The generalization claims in the abstract and introduction ("widest range," "remarkable transferability") slightly overextend the evidence, which is bounded to specific MuJoCo tasks and a single PandaPush setup with known parameter bounds. Tightening these claims to reflect the evaluated scope would improve scientific defensibility.

3. **Hyperparameter Reporting (Minor):** The lack of a consolidated table reporting the final tuned hyperparameter values ($\epsilon$, $\alpha$, $\Delta$) for each environment and method forces readers to infer settings from figures or text, complicating direct replication of the baseline comparisons.

4. **Theoretical Framing Precision (Minor):** The statement in Appendix B that "DORAEMON does not rely on a KL-divergence objective" could be misinterpreted, as the method explicitly uses a KL-divergence constraint for the trust region. Clarifying this distinction is necessary to accurately position DORAEMON relative to I-projection and M-projection methods.

## Actionable Suggestions
1. **Specify Optimization Solvers:** In Section 4.1 (Algorithmic Implementation), add a sentence explicitly stating the numerical solver used for Eq. (4) and Eq. (6) (e.g., "We solve both optimization problems using L-BFGS-B with a convergence tolerance of $10^{-4}$"). Include any relevant solver hyperparameters to ensure full reproducibility.

2. **Bound Generalization Claims:** In the Abstract and Introduction, revise phrases like "solving the task at hand across the widest range of dynamics parameters" to "solving evaluated tasks across wider dynamics ranges than baselines under bounded search spaces." This maintains the contribution's impact while aligning with the empirical scope.

3. **Report Final Hyperparameters:** In Appendix A.2, add a compact table (e.g., Table A1) listing the final tuned values of $\epsilon$ for DORAEMON, $\alpha$ for LSDR, and $\Delta$ for AutoDR for each MuJoCo environment. This will greatly assist readers in replicating the experiments.

4. **Clarify Real-World Evaluation Protocol:** In Section 5.3 (Sim2Real Transfer), explicitly state the evaluation breakdown: "We evaluate policies over 30 real-world rollouts, corresponding to 3 distinct physical configurations (varying center of mass and surface friction) tested across 10 random seeds."

5. **Refine Theoretical Framing in Appendix B:** In the "I-projection vs. M-projection" paragraph, clarify that while DORAEMON's *primary objective* does not rely on KL-divergence minimization, it *does* employ a KL-divergence constraint for the trust region. This distinction prevents misinterpretation of the method's theoretical foundations relative to projection-based approaches.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem & Domain):** Varying dynamics parameters in simulation is a popular Domain Randomization (DR) approach for overcoming the reality gap in Reinforcement Learning (RL).
- **S2 (Significance/Challenge):** However, DR heavily hinges on the choice of the sampling distribution, as high variability regularizes behavior but can lead to overly conservative policies when randomizing excessively.
- **S3 (Prior Gap):** Existing automated DR methods either require reference distributions, bias training toward boundaries, or demand additional environment interactions, limiting their sample efficiency and scalability.
- **S4 (Proposed Method):** We introduce DORAEMON, a constrained optimization approach that directly maximizes the entropy of the training distribution while ensuring the policy maintains a target probability of success, thereby preventing performance collapse without extra rollouts.
- **S5 (Key Result & Bounded Implication):** Empirical validation on MuJoCo benchmarks and a 7-DoF robotic manipulation task demonstrates that DORAEMON yields highly adaptive policies that generalize across wider dynamics ranges than representative baselines, achieving successful zero-shot Sim2Real transfer under unknown real-world parameters.

### Introduction Outline (Complete)
- **P1 (Big Picture & Reality Gap):** Establish the importance of sim-to-real transfer in RL for robotics, highlighting the reality gap and the role of Domain Randomization (DR) in inducing robustness through dynamics variability.
- **P2 (DR Trade-off & Manual Tuning):** Explain the core challenge of DR: balancing distribution width (generalization) against policy stability. Note that current DR relies on tedious manual tuning of distribution parameters.
- **P3 (Automated DR Limitations):** Review prior automated DR methods (e.g., LSDR, AutoDR). Contrast their mechanisms (reference range optimization, boundary biasing) and highlight their limitations: reliance on extra rollouts, data inefficiency, or confinement to uniform distributions.
- **P4 (DORAEMON Proposal & Intuition):** Introduce DORAEMON's core intuition: better generalization is achieved by maximizing distribution entropy, constrained by the policy's success probability. Emphasize that this shifts complexity from tuning distributions to defining a simple success indicator.
- **P5 (Evidence & Contributions):** Preview the empirical results: superior sample efficiency, better generalization across MuJoCo tasks, and successful Sim2Real transfer on a 7-DoF PandaPush task. Explicitly list the three main contributions (entropy maximization formulation, IS estimator + backup optimization, comprehensive Sim2Sim/Sim2Real validation).

## Priority Revision Plan
| Priority | Action Item | Expected Impact | Effort |
|---|---|---|---|
| **P0 (Must)** | Specify optimization solvers for Eq. (4) and Eq. (6) in Section 4.1. | Ensures full reproducibility of the distribution update mechanism. | Low |
| **P0 (Must)** | Bound generalization claims in Abstract/Intro to evaluated benchmarks and bounded search spaces. | Improves scientific defensibility and prevents reviewer pushback on scope overreach. | Low |
| **P1 (High)** | Add a table in Appendix A.2 reporting final tuned hyperparameters ($\epsilon$, $\alpha$, $\Delta$) per environment. | Facilitates exact replication of baseline comparisons. | Low |
| **P1 (High)** | Clarify real-world evaluation protocol in Section 5.3 (3 configurations $\times$ 10 seeds = 30 rollouts). | Enhances transparency regarding Sim2Real statistical significance. | Low |
| **P2 (Medium)** | Refine theoretical framing in Appendix B to distinguish primary entropy objective from KL trust region constraint. | Prevents misinterpretation of DORAEMON's position relative to I/M-projection methods. | Low |
| **P2 (Medium)** | Explicitly mention bounded-support assumption limitation in Conclusion. | Improves scientific completeness and guides future extensions. | Low |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory (Full Coverage)

| Exp ID | Objective/Hypothesis | Setup (Data/Split/Protocol/Baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Entropy maximization improves generalization vs fixed DR | 6 MuJoCo tasks, 10 seeds, baselines: No-DR, Fixed-DR, LSDR, AutoDR | Global Success Rate, Entropy | DORAEMON achieves higher/faster convergence and wider generalization | C1, C3 | Limited to bounded search spaces |
| E2 | Curriculum effect of gradual distribution widening | MuJoCo tasks, comparing DORAEMON vs Fixed-DR (max entropy) | Global Success Rate | Gradual widening outperforms direct max-entropy sampling | C1 | Not tested on non-locomotion tasks |
| E3 | Success rate vs Entropy trade-off ($\alpha$ sensitivity) | Hopper, Walker2D, HalfCheetah, $\alpha \in \{0.5, 0.75, 0.9\}$ | In-distribution SR, Global SR | $\alpha=0.5$ balances stability and generalization best | C2 | $\alpha$ fixed across all tasks |
| E4 | Sim2Real transfer under unknown dynamics | 7-DoF PandaPush, 17D params, 3 physical configs, 10 seeds | Success Rate, Distance to Goal | 60% success rate, superior to baselines | C3 | Single manipulation task |
| E5 | Ablation of DORAEMON components (History, Asymmetric, Backup) | Hopper, Walker2D, SPDL baselines | In-distribution SR, Global SR | Backup opt crucial for constraint tracking; history+asymmetric vital | C2 | No ablation on distribution family |

### Research-Theme Gap Diagnosis
The core research-value claims (new knowledge in entropy-constrained DR, reproducibility via IS estimator, impact on practice via Sim2Real) are well-supported. However, the method's reliance on bounded-support distributions (Beta) limits its applicability to unbounded dynamics. Additionally, the generalization to tasks beyond locomotion and simple pushing is not yet validated.

### Proposed Research Experiments (P0/P1/P2)

| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Estimated Cost/Time | Expected Paper-Quality Gain |
|---|---|---|---|---|---|---|---|
| C1 (Generalization) | DORAEMON generalizes to unbounded dynamics using Gaussian parametrization | Evaluate DORAEMON (Gaussian) vs Beta on 2 new MuJoCo tasks | Fixed-DR (Gaussian), AutoDR | Global SR, Entropy | Comparable or better performance than Beta | 1-2 days GPU | Validates distribution family flexibility |
| C3 (Sim2Real) | DORAEMON transfers to a different manipulation task (e.g., sliding) | Deploy on Franka Emika sliding task with unknown friction/mass | LSDR, AutoDR, Fixed-DR | Success Rate, Distance | >50% success rate under unknown params | 3-5 days real-world | Strengthens Sim2Real practical impact |
| C2 (Stability) | Backup optimization prevents collapse in high-dimensional DR | Test on 20D+ dynamics space (e.g., quadruped) | SPDL, LSDR | In-distribution SR, Training Stability | Constraint violation rate <5% | 2-3 days GPU | Validates scalability and stability |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 7.5/10

**Rationale:** The paper presents a novel, well-motivated, and empirically validated method for automating Domain Randomization via entropy maximization. The core mechanism (constrained entropy maximization with a backup optimization) is elegant and addresses a fundamental trade-off in DR. The Sim2Real results on a 7-DoF robotic task are particularly compelling. The score is slightly reduced due to minor reproducibility gaps (missing solver details, hyperparameter values) and slightly overbroad generalization claims that need bounding. These are fixable issues that do not undermine the core scientific contribution.

**Post-Revision Target:** [8.5, 9.0]/10

**Justification:** Addressing the P0 and P1 revision items (specifying solvers, bounding claims, reporting hyperparameters, clarifying evaluation protocol) will significantly improve reproducibility and scientific defensibility. With these minor but important refinements, the paper will be highly competitive and ready for acceptance.