## Summary
# Final Review Report

## Summary

This paper introduces MolMiner, a semi-order-agnostic autoregressive transformer architecture for fragment-based molecular generation. The method decomposes molecules into symmetry-aware fragments and generates them sequentially as "molecular stories," enforcing chemical validity at each step. By incorporating 3D geometric information via distance-weighted attention and formulating next-step prediction as a single classification task, MolMiner aims to address limitations in prior hierarchical models regarding interpretability, variable molecular size, and spatial awareness. The authors evaluate the model on the RedDB dataset for multi-target inverse design (solubility, redox potential, synthetic accessibility), demonstrating improved novelty ratios compared to a modified HierVAE baseline. The work presents a coherent fragment-based generative framework with practical relevance to computational materials design, though several methodological clarifications and empirical validations are required to strengthen the claims.

## Strengths
1. **Coherent Fragment-Based Framework:** The proposal of "molecular stories" provides an intuitive and interpretable paradigm for autoregressive molecular generation. Decomposing molecules into symmetry-aware fragments aligns well with chemical intuition and simplifies the generation process into discrete, verifiable steps.

2. **Symmetry-Aware Attachment Standardization:** The development of a standardization map to handle fragment symmetries is a notable technical contribution. By resolving symmetry-equivalent attachment points, the method reduces vocabulary redundancy and stabilizes training, addressing a known limitation in prior junction-tree and hierarchical VAE approaches.

3. **Integration of 3D Geometric Information:** Incorporating pairwise Euclidean distances into the transformer attention mechanism is a practical and effective way to introduce spatial awareness into an autoregressive fragment-based model. The ablation studies confirm a measurable accuracy gain from this geometric bias.

4. **Practical Application to Multi-Target Inverse Design:** The evaluation on the RedDB dataset for aqueous redox flow batteries demonstrates the model's utility in a real-world computational materials design setting. The calibration experiments across solubility, redox potential, and synthetic accessibility provide a comprehensive view of the model's conditional generation capabilities.

## Weaknesses
1. **Overclaiming Chemical Validity Guarantees:** The abstract and introduction assert that enforcing chemical rules "guarantees" the validity of generated molecules. In fragment-based autoregressive generation, local attachment rules typically prevent obvious valence violations but do not strictly guarantee global chemical validity (e.g., steric clashes, unstable conformers, or rare valence states). This absolute language risks overclaiming without comprehensive validation.

2. **Technical Inaccuracy in Fragment Uniqueness Claim:** The method claims that the SSSR-based decomposition satisfies "Uniqueness: A molecule should always be decomposed into the same set of fragments." However, SSSR computation is mathematically non-unique for certain polycyclic structures and depends on the specific cheminformatics implementation. Asserting strict uniqueness without specifying the algorithm is factually inaccurate and threatens reproducibility.

3. **Insufficient Ablation for Core Contributions:** The conclusion attributes performance enhancements to three factors: semi-order-agnostic decoding, symmetry handling, and 3D geometry. However, only the geometry contribution is ablated (showing ~1 point accuracy gain). The relative impacts of symmetry standardization and order-agnosticism remain speculative without dedicated ablation studies, weakening the causal claims.

4. **Opaque Standardization Map Formulation:** The mathematical description of the standardization map for handling symmetries is convoluted (inverting reference maps, convoluting, taking minimums). This lacks clarity and formal definition, making it difficult for readers to verify correctness or reproduce the procedure. Connecting it to established canonical labeling techniques would improve rigor.

5. **Baseline Comparison Fairness and Novelty-Quality Trade-off:** The comparison relies on a modified HierVAE (latent-space conditioning), and it is unclear if this optimally leverages the baseline. Additionally, while MolMiner achieves higher novelty ratios, the paper does not discuss the trade-off between novelty and molecular quality/validity, leaving open the possibility that high novelty comes at the cost of chemical realism.

## Key Issues
1. **Factual Inaccuracy in SSSR Uniqueness Claim (Major):** The assertion that SSSR-based fragmentation guarantees unique decomposition is mathematically incorrect for polycyclic molecules and depends on the toolkit implementation. This undermines the reproducibility guarantee and must be qualified by specifying the exact SSSR algorithm used (e.g., RDKit) and bounding the claim to algorithmic consistency.

2. **Lack of Causal Attribution for Performance Gains (Major):** The paper attributes improved novelty to semi-order-agnostic decoding, symmetry handling, and 3D geometry, but only provides ablation evidence for geometry. Without isolating the contributions of symmetry standardization and order-agnosticism, the core mechanism-performance claim remains unsupported and speculative.

3. **Overstated Validity Guarantees (Minor):** Using absolute language like "guarantees chemical validity" without specifying the exact rules enforced or acknowledging edge cases (steric clashes, stability) risks misleading readers. The claim should be bounded to local rule enforcement and validated against post-generation checks.

4. **Opaque Symmetry Standardization Procedure (Minor):** The mathematical description of the standardization map is difficult to follow and lacks formal definition. This reduces transparency and reproducibility. Clarifying the procedure with an algorithmic summary or referencing canonical labeling techniques is necessary for methodological rigor.

## Actionable Suggestions
1. **Qualify SSSR Uniqueness Claim:** Explicitly state the SSSR implementation used (e.g., RDKit's `GetSSSR`) and revise the uniqueness claim to "algorithmic uniqueness under a fixed SSSR implementation." Acknowledge that different toolkits may yield different SSSRs for complex polycycles.

2. **Conduct Targeted Ablation Studies:** Perform ablation experiments to isolate the contributions of symmetry handling and semi-order-agnostic decoding. Report novelty ratios and calibration metrics for variants without symmetry standardization and with fixed-order decoding to validate the causal claims.

3. **Clarify Standardization Map Formulation:** Provide a concise algorithmic summary of the standardization map construction. Explicitly connect the procedure to canonical labeling techniques (e.g., Weisfeiler-Lehman invariants) to ground the method in graph theory and improve reproducibility.

4. **Bound Chemical Validity Claims:** Replace absolute language like "guarantees chemical validity" with bounded claims such as "improves chemical validity by enforcing local attachment rules." Specify which rules are enforced (valence limits, bond compatibility) and acknowledge the need for post-generation validation for complex stability checks.

5. **Report Novelty-Quality Trade-offs:** Discuss the validity and quality distribution of novel molecules generated by MolMiner compared to HierVAE. Clarify why the specific HierVAE modification was chosen and acknowledge it as a potential limitation of the baseline comparison.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem & Domain):** Deep generative models for molecular discovery face unique challenges in chemical validity, interpretability, and variable molecular size.
- **S2 (Significance/Challenge):** Existing hierarchical and diffusion-based approaches often fix molecular size a priori or lack transparent, step-wise generation processes.
- **S3 (Prior Gap):** Fragment-based models struggle with symmetry-induced vocabulary redundancy and limited integration of 3D geometric constraints.
- **S4 (Proposed Method):** We propose MolMiner, a semi-order-agnostic autoregressive transformer that generates molecules as discrete "molecular stories" using symmetry-aware fragments and geometry-aware attention.
- **S5 (Key Result/Implication):** Evaluated on multi-target inverse design for redox flow batteries, MolMiner achieves calibrated conditional generation and significantly higher novelty ratios compared to hierarchical baselines.

### Introduction Outline (Complete)
- **P1 (Big Picture & Context):** Establish the role of deep generative models in high-throughput screening for computational materials design, highlighting the shift from string-based to graph/point-set representations.
- **P2 (Concrete Gap):** Identify five specific limitations in current models: opacity of one-shot generation, fixed-size constraints, low chemical validity, lack of hierarchical coarse-graining, and missing 3D geometry integration.
- **P3 (Proposed Idea):** Introduce the "molecular story" paradigm: decomposing molecules into symmetry-aware fragments and growing them sequentially via a semi-order-agnostic autoregressive process.
- **P4 (Method Intuition):** Explain how standardization maps resolve symmetry ambiguities and how distance-weighted attention incorporates spatial structure into the transformer architecture.
- **P5 (Evidence Preview):** Preview the multi-target inverse design experiments on RedDB, emphasizing calibrated generation and improved novelty over HierVAE.
- **P6 (Contribution Summary):** List three consolidated contributions: (1) symmetry-aware fragment representation, (2) geometry-aware semi-order-agnostic architecture, (3) empirical validation on multi-target design.

## Priority Revision Plan
| Priority | Action Item | Expected Impact | Effort |
|---|---|---|---|
| **P0** | Qualify SSSR uniqueness claim and specify implementation (e.g., RDKit). | Fixes factual inaccuracy, ensures reproducibility. | Low |
| **P0** | Bound chemical validity claims to local rule enforcement. | Prevents overclaiming, improves defensibility. | Low |
| **P1** | Conduct ablation studies for symmetry handling and order-agnosticism. | Validates causal claims for core contributions. | Medium |
| **P1** | Clarify standardization map with algorithmic summary or canonical labeling reference. | Improves methodological transparency and rigor. | Medium |
| **P2** | Report novelty-quality trade-offs and baseline comparison limitations. | Strengthens empirical analysis and fairness. | Low |
| **P2** | Add learning curve plots to validate sample efficiency hypothesis. | Provides rigorous basis for convergence claims. | Medium |

**Revision Order:** Execute P0 items immediately to correct factual and claim-bounding issues. Proceed to P1 ablations to solidify the contribution narrative. Finally, address P2 items to enhance empirical depth and narrative coherence.

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Fragment-level reconstruction accuracy | RedDB train/test split, 80 epochs | Accuracy (%) | ~82% on test set | Model learns valid fragment sequences | Does not directly measure generation quality |
| E2 | Conditional generation calibration | Vary one property, fix two at mean | Prompted vs Predicted property | Well-calibrated within dataset distribution | Multi-target inverse design capability | Calibration degrades at distribution tails |
| E3 | Novelty ratio comparison | MolMiner vs modified HierVAE | % Novel molecules | MolMiner significantly higher novelty | Improved exploration over hierarchical baseline | Baseline modification may not be optimal |
| E4 | Geometry ablation | With vs without geometric attention bias | Accuracy (%) | ~1 point gain with geometry | 3D information aids structural learning | Gain not linked to conditional generation metrics |

### Research-Theme Gap Diagnosis
The core claim that MolMiner's novelty gain stems from semi-order-agnostic decoding and symmetry handling lacks direct experimental validation. The geometry ablation is isolated to reconstruction accuracy, not conditional generation quality. The sample efficiency hypothesis is speculative without learning curve analysis.

### Proposed Research Experiments
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| Symmetry handling contribution | Symmetry standardization reduces vocabulary redundancy and improves training stability. | Train MolMiner without standardization map (allow duplicate attachments). | Full MolMiner | Accuracy, Novelty Ratio | Full model outperforms ablated variant | Low | Validates C1 contribution |
| Order-agnosticism contribution | Semi-order-agnostic factorization improves generalization over fixed-order decoding. | Train with fixed BFS/DFS story unrolling. | Full MolMiner | Accuracy, Calibration | Full model shows better calibration/novelty | Low | Validates C2 contribution |
| Geometry impact on generation | Geometric bias improves conditional generation quality, not just reconstruction. | Evaluate no-geometry variant on calibration/novelty tasks. | Full MolMiner | Novelty Ratio, Calibration | Quantify geometry's role in inverse design | Medium | Links architecture to core claims |
| Sample efficiency validation | MolMiner requires more steps to converge due to story augmentation. | Plot performance vs training steps/compute. | HierVAE | Accuracy, Novelty over time | Clear learning curve separation | Medium | Rigorous efficiency comparison |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 6.0/10

**Rationale:** The paper presents a coherent and practically relevant fragment-based generative framework with clear strengths in symmetry handling and geometric integration. However, the score is moderated by factual inaccuracies in the SSSR uniqueness claim, overstatement of chemical validity guarantees, and insufficient ablation evidence to support the causal attribution of performance gains. The empirical comparison with HierVAE is promising but lacks rigorous baseline optimization and novelty-quality trade-off analysis. Addressing the P0 and P1 revision items would significantly strengthen the scientific rigor and defensibility of the claims.

**Post-Revision Target:** [7.5, 8.5]/10

**Justification:** If the authors qualify the SSSR and validity claims, provide targeted ablations for symmetry and order-agnosticism, and clarify the standardization map, the methodological rigor will align with the empirical results. The core contribution remains valuable for computational materials design, and resolving these issues would elevate the paper to a strong acceptance standard.