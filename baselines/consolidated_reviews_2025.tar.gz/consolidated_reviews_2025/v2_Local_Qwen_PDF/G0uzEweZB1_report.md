## Summary
# Final Review Report

## Summary
This paper proposes FrAug, a frequency-domain data augmentation framework for time series forecasting (TSF). Recognizing that traditional time-domain augmentations (e.g., cropping, warping) disrupt the fine-grained temporal dependencies critical for forecasting, the authors introduce frequency masking and frequency mixing. By applying Fast Fourier Transform (FFT) to the concatenated look-back and forecasting horizon sequences, FrAug manipulates periodic components while preserving the semantic alignment between input and target. Extensive experiments on eight benchmarks demonstrate that FrAug improves forecasting accuracy across multiple state-of-the-art models, particularly in data-scarce cold-start settings and under distribution shifts during test-time training. The paper provides a clear motivation, simple yet effective methods, and comprehensive empirical validation, though it requires tighter claim bounding, improved reproducibility details, and a more nuanced discussion of limitations.

## Strengths
1. **Clear and Intuitive Motivation:** The paper effectively identifies a critical gap in time-series forecasting: traditional time-domain augmentations disrupt the precise input-output temporal alignment required for regression tasks. The pivot to the frequency domain to preserve periodic dependencies is well-motivated and intuitively sound.
2. **Simple yet Effective Methodology:** FrAug (frequency masking and mixing) is conceptually simple, easy to implement, and computationally lightweight. The design of applying FFT to the concatenated look-back and horizon sequences elegantly ensures that augmentations affect both input and target jointly, preserving semantic consistency.
3. **Comprehensive Empirical Validation:** The authors evaluate FrAug across eight diverse benchmarks, six state-of-the-art forecasting models, and three distinct application scenarios (long-term forecasting, cold-start forecasting, and test-time training). The results consistently demonstrate performance improvements, particularly in data-scarce regimes.
4. **Practical Relevance:** The focus on cold-start forecasting and distribution shift mitigation addresses highly relevant real-world challenges where historical data is limited or non-stationary, enhancing the practical utility of the proposed method.

## Weaknesses
1. **Unbounded Novelty and Contribution Claims:** The paper claims to be the "first work that systematically investigates data augmentation techniques for the TSF task." This is a strong assertion that risks overlooking prior forecasting-specific DA works (e.g., Semenoglou et al., 2023; Bandara et al., 2021). Additionally, the contribution list mixes methodological novelty with empirical outcomes, diluting the conceptual impact.
2. **Missing Reproducibility and Statistical Rigor:** The experimental setup lacks critical details such as random seeds, variance reporting (mean ± std), hardware specifications, and training budgets. The claim that "FrAug achieves the best performance in 80% of cases" (Table 2) is statistically unsupported without variance or significance testing, especially given the small margins in some cells.
3. **Confounding Variables in Cold-Start Evaluation:** The comparison between 1% data + FrAug and 100% full data is confounded by data recency. The last 1% of training data is temporally closest to the test set, naturally reducing distribution shift. Attributing outperformance over full data solely to DA overlooks this recency bias, weakening the causal claim for FrAug's effectiveness.
4. **Lack of Limitations and Boundary Conditions:** The conclusion strongly reiterates benefits but omits a discussion of limitations. FrAug relies on the assumption that time series contain meaningful periodic components; its effectiveness may diminish for highly stochastic or purely trend-driven data. Ignoring these boundary conditions reduces scientific transparency.

## Key Issues
1. **Statistical Validity of Main Results (Major):** The absence of variance reporting and significance testing undermines the credibility of the "80% best performance" claim and the overall comparative analysis. Single-run evaluations are insufficient for claiming consistent superiority, especially when improvements are marginal.
2. **Causal Attribution in Cold-Start Experiments (Major):** The claim that FrAug enables 1% data to outperform full data is confounded by the recency effect. Without isolating the DA effect from the distribution alignment of recent data, the cold-start contribution is overstated.
3. **Reproducibility Gaps (Major):** Missing details on random seeds, hardware, training budgets, and baseline hyperparameters (e.g., MBB block size, ASD decay factor) prevent independent verification and fair comparison.
4. **Overclaiming Novelty (Minor/Major):** The "first work" claim requires careful bounding. Prior works have explored DA for forecasting; the novelty lies specifically in the *frequency-domain* approach for *semantic consistency*. Repositioning this claim will strengthen defensibility.
5. **Missing Limitations Discussion (Minor):** The lack of a limitations section ignores boundary conditions (e.g., non-periodic series) where FrAug may fail, reducing the paper's scientific maturity.

## Actionable Suggestions
1. **Add Variance and Significance Testing:** Report mean ± standard deviation over at least three random seeds for all main results. Include a paired significance test (e.g., t-test or bootstrap) to validate the "80% best performance" claim.
2. **Clarify Cold-Start Comparisons:** Acknowledge the data recency effect when comparing 1% vs. 100% data. Reframe the primary claim to focus on how FrAug narrows the performance gap between scarce and full data, rather than claiming consistent superiority over full-data baselines.
3. **Enhance Reproducibility Details:** Explicitly state the hardware (GPU type), training budget (epochs, learning rate schedule), and random seeds. Provide missing baseline hyperparameters (MBB block size, ASD decay factor/neighbor count) and clarify whether FrAug mask/mix rates are fixed or sampled per batch.
4. **Bound Novelty Claims:** Replace "first work that systematically investigates..." with a more precise claim, e.g., "first to systematically explore frequency-domain DA specifically for preserving forecasting semantics." Move empirical outcomes (cold-start, test-time gains) to secondary contributions or results preview.
5. **Add Limitations Section:** Append a concise paragraph to the conclusion acknowledging that FrAug relies on periodicity assumptions and may be less effective for highly stochastic or non-stationary series. Suggest future work on adaptive frequency selection or hybrid augmentation strategies.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem & Domain):** Time series forecasting (TSF) relies on modeling fine-grained temporal dependencies, but deep models often suffer from overfitting due to data scarcity or distribution shifts.
- **S2 (Significance/Challenge):** While data augmentation (DA) is standard in other domains, traditional time-domain methods (e.g., cropping, warping) disrupt the precise input-output alignment required for forecasting regression tasks.
- **S3 (Prior Gap):** Existing DA techniques lack a mechanism to preserve semantic consistency between the look-back window and forecasting horizon, limiting their applicability to TSF.
- **S4 (Proposed Method):** We propose FrAug, a frequency-domain augmentation framework that applies masking and mixing to the concatenated input-target sequence, jointly manipulating periodic components while preserving temporal alignment.
- **S5 (Key Result & Bounded Implication):** Experiments on eight benchmarks show FrAug consistently improves accuracy across state-of-the-art models, effectively mitigating overfitting in cold-start settings and enhancing robustness under distribution shifts.

### Introduction Outline (Complete)
- **P1 (Big Picture & Motivation):** Deep learning demands large datasets, but TSF faces unique data scarcity challenges (cold-start, short deployment periods) and distribution shifts. DA is a promising solution but remains underexplored for forecasting.
- **P2 (Problem Alignment & Gap):** Unlike classification or anomaly detection, TSF is a regression task requiring strict preservation of fine-grained temporal relationships. Time-domain augmentations introduce perturbations that break this alignment, degrading performance.
- **P3 (Variable Alignment & Intuition):** Forecastable behaviors are often driven by periodic events. The frequency domain naturally decouples these periodicities, offering a space where augmentations can manipulate underlying dynamics without disrupting input-output offsets.
- **P4 (Solution & Method Preview):** We introduce FrAug, which applies FFT to the concatenated look-back and horizon sequences. Frequency masking and mixing selectively alter periodic components, generating diverse yet semantically consistent training samples.
- **P5 (Evidence Preview & Contributions):** We validate FrAug across long-term forecasting, cold-start scenarios, and test-time training. Results demonstrate consistent accuracy gains, significant overfitting alleviation, and improved adaptation to distribution shifts. Contributions are reframed to highlight methodological novelty and empirical robustness.

## Priority Revision Plan
| Priority | Action Item | Expected Impact | Effort |
|---|---|---|---|
| **P0** | Add variance reporting (mean ± std over ≥3 seeds) and significance tests for main results. | Validates statistical reliability of "80% best" claim and overall comparisons. | Medium |
| **P0** | Reframe cold-start comparisons to acknowledge data recency bias; isolate DA effect. | Strengthens causal attribution and prevents reviewer pushback on confounding variables. | Low |
| **P0** | Bound novelty claims ("first work") and separate methodological contributions from empirical outcomes. | Improves defensibility and aligns contributions with actual conceptual advances. | Low |
| **P1** | Add missing reproducibility details: hardware, training budget, baseline hyperparameters (MBB block size, ASD decay). | Enables independent verification and fair comparison. | Low |
| **P1** | Append a limitations section discussing periodicity assumptions and potential failure modes. | Enhances scientific transparency and maturity. | Low |
| **P2** | Clarify FrAug mask/mix rate sampling strategy (fixed vs. per-batch) in Appendix. | Improves implementation clarity and reproducibility. | Low |
| **P2** | Polish abstract and introduction narrative flow (remove repetitions, tighten transitions). | Improves readability and engagement. | Low |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup (data/split/protocol/baselines) | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | Long-term forecasting DA comparison | ETT, Exchange, Traffic, Electricity, Weather; 6 models; 4 baselines | MSE | FrAug best in 80% cases | FrAug improves accuracy | No variance/significance reported |
| E2 | Cold-start forecasting (1% data) | Last 1% of training data; 2x/50x augmentation | MSE | FrAug narrows gap to full data; sometimes outperforms | FrAug effective under scarcity | Confounded by data recency effect |
| E3 | Test-time training under distribution shift | ETTh1/2, ILI; 20-part sequential retraining | MSE | FrAug mitigates loss spike at shift points | FrAug aids distribution adaptation | Heuristic augmentation rate unexplained |
| E4 | Short-term forecasting (Appendix) | Horizons 3, 6, 12, 24; 4 models | MSE | FrAug helps Transformers; DLinear unaffected | FrAug benefits high-capacity models | Limited to short horizons |
| E5 | Overfitting analysis (Appendix) | Train/test loss curves; visualization | MSE/Loss | FrAug flattens test loss curve | FrAug alleviates overfitting | Qualitative visualization only |

### Research-Theme Gap Diagnosis
The core research value (new knowledge on frequency-domain DA for TSF) is well-supported, but reproducibility and causal attribution gaps remain. The cold-start claim is weakened by the recency confounder, and the lack of variance reporting reduces statistical confidence. Practical impact is high, but boundary conditions (non-periodic series) are untested.

### Proposed Research Experiments (P0/P1/P2)
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| Statistical reliability | FrAug improvements are consistent across random seeds. | Run E1/E2 over 3-5 seeds; report mean±std. | Same baselines | MSE | p < 0.05 vs. strongest baseline | Low | Validates main claims |
| Cold-start causal effect | FrAug improves performance beyond recency bias. | Compare 1%+FrAug vs. 1% no-DA vs. 100% data. | 1% baseline | MSE | 1%+FrAug significantly better than 1% baseline | Low | Isolates DA effect |
| Periodicity assumption | FrAug degrades on non-periodic/stochastic series. | Test on financial/stock datasets with low autocorrelation. | Time-domain DA | MSE | FrAug gain diminishes or reverses | Medium | Clarifies limitations |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 6.5/10

**Justification:** The paper presents a clear, intuitive, and practically valuable method (FrAug) for time series forecasting data augmentation. The motivation is strong, and the empirical results across multiple benchmarks and scenarios are promising. However, the score is moderated by significant reproducibility gaps (missing variance, seeds, baseline hyperparameters), unbounded novelty claims, and a confounded cold-start evaluation that overstates the DA effect. Addressing these issues would substantially strengthen the paper's scientific rigor and defensibility.

**Post-Revision Target:** [7.5, 8.5]/10

**Justification:** If the authors add variance reporting, clarify the cold-start recency bias, bound the novelty claims, and include a limitations section, the paper will meet the standard for a strong acceptance. The core contribution is sound and impactful; the revisions primarily address presentation, statistical rigor, and causal attribution rather than fundamental methodological flaws.