## Summary
# Final Review Report

## Summary
This paper proposes Generalized Consistency Trajectory Models (GCTMs), extending Consistency Trajectory Models (CTMs) to enable one-step translation between arbitrary distributions via conditional flow matching. While CTMs are restricted to translating Gaussian noise to data, GCTMs generalize this framework to support diverse image manipulation tasks, including image-to-image translation, restoration, editing, and latent manipulation. The authors provide a theoretical foundation proving CTMs as a special case of GCTMs, elucidate the design space (couplings, Gaussian perturbation, time discretization), and demonstrate competitive performance at NFE=1 across multiple benchmarks. The work offers a unified and efficient framework for fast generative modeling, addressing the computational bottleneck of iterative diffusion methods.

## Strengths
1. **Theoretical Generalization:** The paper provides a rigorous theoretical extension of CTMs to arbitrary distributions via conditional flow matching. Proposition 1 and Proposition 2 clearly establish the equivalence between CTMs and GCTMs under specific couplings, demonstrating that GCTMs are a true generalization rather than an ad-hoc modification.
2. **Unified Design Space:** The elucidation of the GCTM design space (couplings, Gaussian perturbation, time discretization) is highly valuable. The flexible coupling mechanism elegantly supports both unsupervised (independent/OT) and supervised settings, providing a unified framework for diverse manipulation tasks.
3. **Strong Empirical Performance:** GCTMs demonstrate competitive performance at NFE=1 across unconditional generation, image-to-image translation, restoration, and editing. The ability to outperform multi-step baselines (e.g., I2SB, Palette) in speed while maintaining quality highlights the practical significance of the method.
4. **Reproducibility:** The authors provide clear algorithmic descriptions (Algorithms 1-2) and open-source code, facilitating reproducibility and future research.

## Weaknesses
1. **Vague Gap Statement in Introduction:** The introduction states a "lack of works exploring the effectiveness of CTMs" without explicitly linking this to the technical barrier (Gaussian-to-data restriction). This weakens the motivation and delays the logical bridge to GCTMs.
2. **Missing Sampling Procedure in GCTM Losses:** The training losses (Eq. 15 and 16) use expectations over $q(x_t)$ without explicitly stating the linear interpolation sampling procedure ($x_t = (1-t)x_0 + tx_1$). This omission reduces reproducibility for readers unfamiliar with standard Flow Matching training.
3. **Abstract Lacks Quantitative Anchors:** The abstract describes the method and tasks but lacks concrete quantitative results (e.g., NFE=1 competitive performance). This reduces the immediate impact for time-constrained reviewers.
4. **Generic Contribution Statements:** Contribution C3 ("Empirical verification") lists tasks but does not highlight the key empirical finding (NFE efficiency and one-to-many generation capability). A more evidence-driven statement would strengthen the perceived impact.
5. **Related Work Differentiation:** The final differentiation in the related work section is vague. It does not explicitly contrast GCTM's generalized trajectory learning with recent specific trajectory distillation methods (e.g., DDB, DDIB distillation), missing an opportunity to clarify novelty.

## Key Issues
1. **Reproducibility Risk in Loss Formulation (Major):** The GCTM training losses (Eq. 15, 16) omit the explicit data sampling procedure for $x_t$. Without stating that $x_t$ is generated via linear interpolation between $x_0$ and $x_1$, readers may be unable to reproduce the training loop correctly. This is a critical omission for a method paper.
2. **Weak Motivation-Gap Alignment (Major):** The introduction's gap statement ("lack of works exploring CTMs") does not explicitly identify the Gaussian-to-data limitation as the technical barrier. This misalignment forces readers to infer the motivation, reducing narrative coherence and impact.
3. **Vague Novelty Differentiation (Major):** The related work section fails to sharply contrast GCTM with recent trajectory distillation methods (e.g., CoDi, Consistency Diffusion Bridge). Without explicit comparison on trajectory generality and coupling flexibility, the novelty claim may be perceived as incremental.

## Actionable Suggestions
1. **Clarify GCTM Loss Sampling:** In Section 4, explicitly state that $x_t$ is sampled via linear interpolation $x_t = (1-t)x_0 + tx_1$ for $(x_0, x_1) \sim q(x_0, x_1)$. Add this sentence immediately after introducing Eq. (15) and (16) to ensure reproducibility.
2. **Strengthen Introduction Gap Statement:** Rewrite the final sentence of the introduction to explicitly link the lack of CTM exploration to the Gaussian-to-data restriction. Example: "However, current CTMs are fundamentally restricted to translating Gaussian noise to data, preventing direct application to arbitrary distribution translations such as image-to-image translation."
3. **Sharpen Related Work Differentiation:** In the related work section, explicitly contrast GCTM with recent trajectory distillation methods. State that while methods like CoDi or Consistency Diffusion Bridge distill *specific* bridge trajectories, GCTM learns a *generalized* trajectory model supporting arbitrary traversal and flexible couplings.
4. **Enhance Abstract with Metrics:** Add a concrete quantitative result to the abstract's final sentence. Example: "Empirically, GCTMs achieve competitive performance at NFE=1 across unconditional generation, image-to-image translation, restoration, and editing, outperforming multi-step baselines in speed and quality."
5. **Refine Contribution C3:** Rewrite Contribution C3 to highlight the key empirical finding. Example: "We demonstrate GCTMs across diverse tasks, achieving competitive performance at NFE=1. Flexible couplings enable GCTMs to serve as effective priors for both zero-shot inverse solvers and supervised translation tasks."

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem & Domain):** Diffusion models excel in generation and manipulation but suffer from high computational cost due to iterative sampling (tens to thousands of NFEs).
- **S2 (Significance/Challenge):** While consistency trajectory models (CTMs) reduce this to a single evaluation, they are restricted to translating Gaussian noise to data, limiting their applicability to arbitrary manipulation tasks.
- **S3 (Prior Gap):** Existing distillation methods either target terminal points or specific bridge trajectories, lacking a unified framework for generalized trajectory learning.
- **S4 (Proposed Method):** We propose Generalized CTMs (GCTMs), extending CTMs via conditional flow matching to enable one-step translation between arbitrary distributions. We elucidate the design space, showing how flexible couplings support both unsupervised and supervised settings.
- **S5 (Key Result & Implication):** Empirically, GCTMs achieve competitive performance at NFE=1 across unconditional generation, image-to-image translation, restoration, and editing, outperforming multi-step baselines in speed and quality.

### Introduction Outline (Complete)
- **P1 (Big Picture & Motivation):** DMs dominate generation/manipulation due to iterative guidance, but the high NFE cost hinders practical deployment. Distillation (PD, CM, CTM) addresses this by learning single-step mappings.
- **P2 (Gap & Limitation):** CTMs theoretically support flexible traversal and score inference, making them ideal for manipulation. However, they are fundamentally restricted to Gaussian-to-data translation, preventing direct application to tasks like image-to-image translation or restoration.
- **P3 (Solution & Intuition):** We propose GCTMs, generalizing CTMs via conditional flow matching to learn trajectories between arbitrary distributions. By proving CTMs as a special case, we establish a unified theoretical framework.
- **P4 (Design Space & Flexibility):** We clarify key design components: couplings (independent, OT, supervised) enable diverse training regimes; Gaussian perturbation facilitates one-to-many generation; and adapted time discretization ensures stability.
- **P5 (Evidence & Contributions):** We demonstrate GCTMs across five manipulation tasks, achieving competitive NFE=1 performance. Contributions: (1) Theoretical generalization of CTMs, (2) Elucidation of GCTM design space, (3) Empirical validation of fast, flexible manipulation.

## Priority Revision Plan
| Priority | Issue | Action | Expected Impact |
|---|---|---|---|
| **P0** | Reproducibility: Missing $x_t$ sampling in losses | Explicitly state linear interpolation sampling in Section 4 after Eq. (15)/(16). | Ensures correct implementation and reproducibility. |
| **P0** | Motivation: Vague gap statement | Rewrite Intro P4 to explicitly link lack of CTM exploration to Gaussian-to-data restriction. | Strengthens narrative coherence and justification for GCTMs. |
| **P1** | Novelty: Weak related work differentiation | Contrast GCTM with recent trajectory distillation methods (CoDi, CDB) in Related Work. | Clarifies novelty and positions GCTM as a generalized framework. |
| **P1** | Impact: Generic abstract/contributions | Add concrete NFE=1 metrics to Abstract and refine Contribution C3. | Increases immediate impact and memorability for reviewers. |
| **P2** | Clarity: Gaussian perturbation explanation | Link perturbation explicitly to one-to-many generation and posterior mean avoidance in Section 4.1. | Improves theoretical understanding of design choices. |

## Experiment Inventory & Research Experiment Plan
### Completed Experiment Inventory
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| E1 | OT coupling accelerates training | CIFAR10, N=4 vs N=32 | FID, Training iterations | OT coupling achieves lower FID faster | C2 (Design space) | Limited to unconditional generation |
| E2 | GCTM competitive at NFE=1 | CIFAR10 vs CTM/CM/iCM | FID | GCTM (OT) matches teacher-CTM, beats CM | C3 (Empirical) | Slightly worse than iCM |
| E3 | GCTM for I2I translation | Edges→Shoes, Night→Day, Facades (64x64) | FID, IS, LPIPS | Outperforms Pix2Pix, Palette, I2SB at NFE=1 | C3 (Empirical) | Lower resolution evaluation |
| E4 | Zero-shot restoration | FFHQ (SR, Deblur, Inpaint) | PSNR, SSIM, LPIPS | Beats DPS/CM at NFE=32 | C3 (Empirical) | CM degradation not fully analyzed |
| E5 | Supervised restoration | FFHQ vs Regression/I2SB | PSNR, SSIM, LPIPS | Best LPIPS, balanced perception-distortion | C3 (Empirical) | Regression wins PSNR/SSIM |
| E6 | Ablation: Perturbation & $\sigma_{max}$ | Edges→Shoes | FID learning curves | Perturbation crucial; $\sigma_{max}=500$ best | C2 (Design space) | Limited to one dataset |

### Research-Theme Gap Diagnosis
- **Robustness & Variance:** No multi-seed variance reporting or confidence intervals are provided, making it difficult to assess statistical reliability of small metric gains.
- **OOD Generalization:** All experiments are conducted on standard benchmarks (CIFAR10, FFHQ, Pix2Pix). Out-of-domain generalization (e.g., different corruption types or unseen translation pairs) is not tested.
- **Causal Attribution:** The ablation study shows perturbation and $\sigma_{max}$ matter, but does not isolate the contribution of the GCTM loss vs the FM loss in downstream performance.

### Proposed Research Experiments (P0/P1/P2)
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| Statistical Reliability | GCTM gains are stable across seeds | Run E2-E5 with 3 random seeds | Same baselines | Mean±Std FID/PSNR | Std < 0.5 FID | Low | Validates robustness |
| OOD Generalization | GCTM generalizes to unseen corruptions | Test zero-shot restoration on new FFHQ corruptions (e.g., motion blur) | DPS, CM | PSNR, LPIPS | Competitive PSNR | Medium | Strengthens generalization claim |
| Loss Ablation | GCTM loss contributes more than FM loss | Train with only $\mathcal{L}_{GCTM}$ vs only $\mathcal{L}_{FM}$ vs combined | Full GCTM | FID, LPIPS | Combined best | Low | Isolates mechanism contribution |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
**Final Score:** 7/10

**Rationale:** The paper presents a theoretically sound and practically significant generalization of CTMs to arbitrary distributions. The unified framework for fast image manipulation is compelling, and the empirical results at NFE=1 are competitive. However, the score is moderated by reproducibility concerns in the loss formulation, a vague gap statement in the introduction, and weak differentiation from recent trajectory distillation methods in the related work. Addressing these issues would significantly strengthen the manuscript.

**Post-Revision Target:** [8, 9]/10

**Justification:** If the authors clarify the sampling procedure, strengthen the motivation-gap alignment, and sharpen the novelty differentiation, the paper will be highly competitive. The core contribution is strong, and the empirical evidence is sufficient to support the claims with minor revisions.