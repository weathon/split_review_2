## Summary
This paper proposes a differentiable polygon-based instance segmentation framework that addresses two core challenges in contour modeling: vertex alignment and parameterization. The authors introduce PolygonAlign, a contour-length-fraction (CLF) sampling strategy that establishes consistent vertex correspondence between fixed-topology predictions and varying ground-truth polygons, enabling a simple differentiable L2 loss. They further propose an affine transformation decoupled parameterization that handles pose and scale variations while maintaining vertex alignment, serving as a robust initializer for a one-step refinement active contour model. Evaluated on MS-COCO with Sparse R-CNN, the method achieves state-of-the-art performance among contour-based approaches. Empirical upper-bound experiments demonstrate the high modeling capacity of the parameterization. The paper is well-motivated and presents a clean, effective solution to a long-standing problem in polygon segmentation. However, the manuscript requires improvements in claim bounding, geometric definition rigor, and experimental robustness (e.g., multi-seed reporting) to meet publication standards.

## Strengths
1. **Clear Problem Formulation and Motivation:** The paper effectively identifies the core bottleneck in polygon-based instance segmentation: the lack of differentiable alignment between predicted and ground-truth polygons of varying topologies. The contrast with bit-mask modeling provides a strong technical motivation for the proposed solutions.

2. **Elegant and Simple Methodology:** PolygonAlign via CLF sampling is an intuitive yet powerful mechanism that resolves vertex correspondence without complex dynamic matching. The affine transformation decoupled parameterization cleanly separates global pose/scale variations from local shape deformation, simplifying the optimization landscape.

3. **Strong Empirical Results:** The method achieves state-of-the-art performance among contour-based approaches on MS-COCO, outperforming recent sophisticated methods like E2EC and PolySnake with fewer training epochs. The upper-bound capacity experiments provide valuable insights into the representational power of the parameterization.

4. **Practical Impact:** Polygon representations offer compact storage and compatibility with vector graphics/CAD systems. By making differentiable polygon modeling practical and competitive, this work encourages further research into vectorized segmentation for downstream applications.

## Weaknesses
1. **Geometric Ambiguity in PolygonAlign:** The definition of the starting point for CLF sampling ("intersection point between the polygon and the x-axis") is ill-defined for polygons that do not intersect the x-axis or intersect it multiple times. This lack of a deterministic start-point rule threatens reproducibility and alignment consistency.

2. **Overextended Claims in Abstract and Contributions:** The abstract claims the "empirical upper-bound performance... is much higher than all existing instance segmentation methods," which is unsupported by the reported results (which only compare against contour-based methods). Contribution (iii) relies primarily on performance gains without tying them to a specific methodological insight.

3. **Insufficient Experimental Robustness:** The ablation study on the number of vertices (K) reveals a non-monotonic trend (K=50 > K=120 < K=250) but attributes this to optimization difficulty or training noise based on a single experimental run. Relying on one seed for ablations is a significant robustness risk.

4. **Lack of Rotation Constraint in Parameterization:** Equation (6) directly regresses a $2 \times 2$ rotation matrix via an MLP without enforcing orthogonality. This allows the network to learn scaling or shearing transformations, violating the "decoupled rotation" assumption and potentially destabilizing training.

5. **Missing Compute Budget Reporting:** The efficiency claim (fewer epochs than baselines) is not substantiated with explicit training time or inference speed metrics. Different methods may have varying iteration times, making epoch count alone an insufficient efficiency indicator.

## Key Issues
1. **Reproducibility Risk in Vertex Alignment (Page 4):** The CLF sampling start point is defined as the x-axis intersection, which fails for polygons entirely above/below the axis or with multiple intersections. Without a deterministic fallback rule (e.g., minimum y-coordinate), the alignment will be inconsistent during training.

2. **Validity Risk in Capacity Experiment (Page 6):** Experiment I evaluates AP on the exact same 5000 polygons used for training. Framing this as "empirical upper bound performance" without explicitly labeling it as a memorization/capacity test misleads readers about generalization limits.

3. **Optimization Stability Risk in Parameterization (Page 5):** Directly regressing the rotation matrix $R_{2 \times 2}$ without orthogonality constraints allows the MLP to learn scaling/shearing. This violates the decoupling assumption and may cause unstable gradients or degenerate shapes.

4. **Statistical Reliability Risk in Ablations (Page 9):** The non-monotonic performance trend across vertex counts (K=50 > K=120) is attributed to optimization noise based on a single experimental run. Single-seed ablations cannot reliably distinguish between methodological flaws and random fluctuations.

## Actionable Suggestions
1. **Fix PolygonAlign Start-Point Definition:** Replace the ambiguous x-axis intersection rule with a deterministic geometric rule: "Select the vertex with the minimum y-coordinate as the start point; break ties using the minimum x-coordinate. Traverse the contour counter-clockwise." Correct the mapping notation typo $S: \mathbb{R} \rightarrow \mathbb{R}^2$ to $S: [0, 1] \rightarrow \mathbb{R}^2$.

2. **Enforce Rotation Orthogonality:** Parameterize the rotation via a single angle $\phi \in \mathbb{R}$ predicted by the MLP, then construct the rotation matrix as $R(\phi) = \begin{bmatrix} \cos\phi & -\sin\phi \\ \sin\phi & \cos\phi \end{bmatrix}$. This guarantees a valid rotation and strictly decouples it from local vertex offsets.

3. **Reframe Capacity Experiment:** Explicitly label Experiment I as a "Modeling Capacity Test" rather than a generalization upper bound. Clarify that evaluating on the training set measures the parameterization's ability to fit arbitrary shapes when features are unconstrained, justifying its use in downstream tasks.

4. **Add Multi-Seed Reporting for Ablations:** Repeat the vertex count (K) ablation and affine transformation ablation over at least 3 random seeds. Report mean $\pm$ standard deviation to validate whether the K=120 performance drop is a consistent phenomenon or a statistical fluctuation.

5. **Bound Claims and Add Compute Metrics:** Revise the abstract and Contribution (iii) to bound performance claims to "contour-based methods" rather than "all existing instance segmentation methods." Add a table reporting total training time (hours) and inference speed (FPS) alongside AP to substantiate the efficiency claim.

## Storyline Options + Writing Outlines
### Abstract Outline (Complete)
- **S1 (Problem & Motivation):** Polygon-based instance segmentation offers a compact, vectorized alternative to dense bit-masks but remains challenging to optimize due to the lack of differentiable alignment between predicted and ground-truth polygons of varying topologies.
- **S2 (Specific Gap):** Prior contour methods rely on heuristic initialization, complex iterative updating, or restrictive star-convex assumptions, failing to provide a unified differentiable framework for arbitrary polygon shapes.
- **S3 (Proposed Method):** We propose PolygonAlign, a contour-length-fraction sampling strategy that establishes consistent vertex correspondence, enabling a simple differentiable L2 loss, combined with an affine transformation decoupled parameterization that handles pose and scale variations.
- **S4 (Key Result):** Evaluated on MS-COCO with Sparse R-CNN, our method achieves state-of-the-art performance among contour-based approaches while requiring significantly fewer training epochs than recent baselines.
- **S5 (Implication):** Empirical upper-bound experiments further demonstrate the high modeling capacity of our parameterization, encouraging further research into differentiable polygon representations for downstream vectorized applications.

### Introduction Outline (Complete)
- **P1 (Big Picture & Practical Stakes):** Object instance segmentation is critical for autonomous driving and robotics. Polygon representations are particularly valuable due to their compact storage, compatibility with vector graphics/CAD systems, and resolution-independent boundaries.
- **P2 (Technical Gap):** While bit-mask modeling dominates due to natural grid alignment enabling simple pixel-wise losses, polygon modeling lacks a canonical alignment mechanism. Ground-truth annotations exhibit varying vertex counts and arbitrary starting points, making direct vertex-to-vertex loss computation non-trivial.
- **P3 (Prior Work Limitations):** Existing active contour variants struggle with consistent vertex correspondence and heuristic initialization. Polar coordinate methods simplify regression but impose star-convex constraints that limit expressivity for complex shapes.
- **P4 (Proposed Solution):** We address these challenges by introducing PolygonAlign, which uses uniform contour-length-fraction sampling to establish deterministic vertex ordering, and an affine-decoupled parameterization that separates global pose/scale from local shape deformation.
- **P5 (Evidence & Contributions):** Our method achieves SOTA performance among contour-based models on MS-COCO with faster convergence. We provide three contributions: (i) PolygonAlign for differentiable vertex alignment, (ii) affine-decoupled parameterization for robust initialization, and (iii) empirical validation of high modeling capacity encouraging future polygon research.

## Priority Revision Plan
| Priority | Action Item | Expected Impact | Effort |
|---|---|---|---|
| **P0** | Fix PolygonAlign start-point definition to a deterministic geometric rule (min-y, min-x). | Eliminates reproducibility risk and alignment inconsistency during training. | Low |
| **P0** | Enforce rotation matrix orthogonality via angle parameterization $\phi$. | Guarantees valid decoupled rotation, stabilizes optimization, and prevents scaling/shearing artifacts. | Low |
| **P0** | Reframe Experiment I as a "Modeling Capacity Test" and bound abstract/contribution claims. | Removes misleading generalization claims and improves scientific defensibility. | Low |
| **P1** | Add multi-seed reporting (mean $\pm$ std) for vertex count (K) and affine transformation ablations. | Validates non-monotonic trends and strengthens statistical reliability of ablation conclusions. | Medium |
| **P1** | Report total training time and inference speed alongside AP in Table 1. | Substantiates efficiency claims beyond epoch count and provides fair compute budget comparison. | Medium |
| **P2** | Expand Introduction P1 with practical motivation for polygon modeling (storage, CAD compatibility). | Strengthens narrative engagement and grounds the research in real-world utility. | Low |
| **P2** | Add a short discussion on failure cases or limitations of CLF sampling for highly self-intersecting polygons. | Improves transparency and bounds the scope of the method's applicability. | Low |

## Experiment Inventory & Research Experiment Plan
| Exp ID | Objective/Hypothesis | Setup | Metrics | Main Outcome | Claim Supported | Current Limitation |
|---|---|---|---|---|---|---|
| Exp I | Verify modeling capacity of parameterization | 5000 MS-COCO polygons, optimize sample-specific $F_C$ jointly | AP (on training set) | AP > 81.9% for K=50,120,250 | High representational power | Evaluated on training set (memorization), not generalization |
| Exp II | Verify capacity in constrained latent space | Encoder learns $F_C$ from bit-masks, 5000 val polygons | AP (on val set) | AP ~ 82-83.8% | Constrained latent space supports high performance | Still a capacity test, not end-to-end segmentation |
| Exp III | Main MS-COCO segmentation results | Sparse R-CNN + Res-50/101, 1x/2x schedule | AP, AP50, AP75 | SOTA among contour methods (35.2 AP) | Method effectiveness | Lacks training time/FPS reporting |
| Exp IV | Ablation: Affine transformation | Res-50, 12 epochs, with/without affine | AP, APDet | +0.3 AP with affine | Affine decoupling helps | Single seed, small gain |
| Exp V | Ablation: Number of vertices K | K=50, 120, 250 | AP, Resampling Quality | Non-monotonic trend (50>120<250) | K=250 best overall | Single seed, optimization sensitivity unverified |

### Research-Theme Gap Diagnosis
The core research value lies in making differentiable polygon modeling practical and competitive. The current experiments validate effectiveness and capacity but lack robustness evidence (multi-seed variance, compute budget) and clear generalization bounds. The non-monotonic K trend highlights an unverified optimization sensitivity gap.

### Proposed Research Experiments
| Target Claim | Hypothesis | Minimal Design | Controls/Baselines | Metrics | Success Criterion | Est. Cost | Expected Gain |
|---|---|---|---|---|---|---|---|
| Optimization Stability | Non-monotonic K trend is a statistical fluctuation, not a methodological flaw. | Repeat Exp V over 3 random seeds. | Same setup, different seeds. | Mean $\pm$ Std AP | Variance explains K=120 drop. | Low (1-2 days) | Validates ablation reliability. |
| Efficiency Validation | Fewer epochs translate to lower total training time. | Report training hours and FPS for Ours vs E2EC/PolySnake. | Matched hardware/batch size. | Hours, FPS | Ours is faster or comparable. | Low (logging) | Substantiates efficiency claim. |
| Generalization Bound | Polygon modeling generalizes well to unseen categories. | Evaluate on a held-out subset of MS-COCO categories. | Same backbone, train on 60 classes. | AP on held-out | AP drop < 5% | Medium | Proves robust generalization. |

## Novelty Verification & Related-Work Matrix
External literature search was not started in this run; novelty/comparison conclusions are deferred to manual verification.

## References
External literature search was not started in this run; no external references are listed.

## Scores
Final Score: 6.5/10

The paper presents a well-motivated and elegant solution to differentiable polygon modeling, achieving strong empirical results among contour-based methods. The core ideas (PolygonAlign and affine-decoupled parameterization) are novel and practically valuable. However, the score is moderated by geometric ambiguities in the alignment definition, lack of rotation constraints in the parameterization, overextended claims in the abstract/contributions, and insufficient experimental robustness (single-seed ablations). These issues are fixable and do not invalidate the core contribution, but they currently limit scientific defensibility and reproducibility.

Post-Revision Target: [7.5, 8.5]/10

If the authors address the P0/P1 revision items (deterministic start-point rule, rotation orthogonality, claim bounding, and multi-seed ablation reporting), the manuscript will achieve high scientific rigor and clearly demonstrate its practical impact, warranting a strong acceptance score.